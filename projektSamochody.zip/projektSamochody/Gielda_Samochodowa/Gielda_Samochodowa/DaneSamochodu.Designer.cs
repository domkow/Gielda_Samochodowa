﻿namespace Gielda_Samochodowa
{
    partial class DaneSamochodu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbKhTransakcji = new System.Windows.Forms.Label();
            this.txtCzyKhOstatniejTransakcji = new System.Windows.Forms.TextBox();
            this.txtIdMarka = new System.Windows.Forms.TextBox();
            this.lbMarkaId = new System.Windows.Forms.Label();
            this.lboxKolor = new System.Windows.Forms.ListBox();
            this.lboxMarka = new System.Windows.Forms.ListBox();
            this.lboxSilnik = new System.Windows.Forms.ListBox();
            this.lbTyp = new System.Windows.Forms.Label();
            this.txtTypZalogowanego = new System.Windows.Forms.TextBox();
            this.txtIdAuta = new System.Windows.Forms.TextBox();
            this.lbAutoId = new System.Windows.Forms.Label();
            this.txtIdWlasciciel = new System.Windows.Forms.TextBox();
            this.lbWlascicielId = new System.Windows.Forms.Label();
            this.txtAktualnyStatus = new System.Windows.Forms.TextBox();
            this.txtCenaWyjsciowa = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtIdTransakcja = new System.Windows.Forms.TextBox();
            this.lbTransakcjaId = new System.Windows.Forms.Label();
            this.txtIdKtoWycenil = new System.Windows.Forms.TextBox();
            this.lbIdWyceniajacego = new System.Windows.Forms.Label();
            this.btnRezygnacja = new System.Windows.Forms.Button();
            this.btnSprzedaj = new System.Windows.Forms.Button();
            this.btnZaakceptuj = new System.Windows.Forms.Button();
            this.btnCena = new System.Windows.Forms.Button();
            this.lbCena = new System.Windows.Forms.Label();
            this.txtCena = new System.Windows.Forms.TextBox();
            this.lbKolorId = new System.Windows.Forms.Label();
            this.lbSilnikId = new System.Windows.Forms.Label();
            this.txtIdKolor = new System.Windows.Forms.TextBox();
            this.textZalogowany = new System.Windows.Forms.TextBox();
            this.txtIdSilnik = new System.Windows.Forms.TextBox();
            this.rtxKomunikaty = new System.Windows.Forms.RichTextBox();
            this.btnZamknijDaneAuta = new System.Windows.Forms.Button();
            this.btnDodajAuto = new System.Windows.Forms.Button();
            this.btnPrzebieg = new System.Windows.Forms.Button();
            this.btnRok = new System.Windows.Forms.Button();
            this.btnWyczyscDaneAuta = new System.Windows.Forms.Button();
            this.btnSilnik = new System.Windows.Forms.Button();
            this.btnMarka = new System.Windows.Forms.Button();
            this.btnKolor = new System.Windows.Forms.Button();
            this.btnRejestracja = new System.Windows.Forms.Button();
            this.lbRejestracja = new System.Windows.Forms.Label();
            this.txtRejestracja = new System.Windows.Forms.TextBox();
            this.lbKolor = new System.Windows.Forms.Label();
            this.txtKolor = new System.Windows.Forms.TextBox();
            this.lbPrzebieg = new System.Windows.Forms.Label();
            this.txtPrzebieg = new System.Windows.Forms.TextBox();
            this.lbRok = new System.Windows.Forms.Label();
            this.txtRok = new System.Windows.Forms.TextBox();
            this.lbWlasciciel = new System.Windows.Forms.Label();
            this.txtWlasciciel = new System.Windows.Forms.TextBox();
            this.lbSilnik = new System.Windows.Forms.Label();
            this.txtSilnik = new System.Windows.Forms.TextBox();
            this.lbMarka = new System.Windows.Forms.Label();
            this.txtMarka = new System.Windows.Forms.TextBox();
            this.grbxDaneAuta = new System.Windows.Forms.GroupBox();
            this.txtAdministracja = new System.Windows.Forms.TextBox();
            this.lbAdministracja = new System.Windows.Forms.Label();
            this.lbCenaNieWlasciciela = new System.Windows.Forms.Label();
            this.lbZalogowanyId = new System.Windows.Forms.Label();
            this.lbMojaCena = new System.Windows.Forms.Label();
            this.txtOstatniaCenaWlasciciela = new System.Windows.Forms.TextBox();
            this.txtMojaCena = new System.Windows.Forms.TextBox();
            this.txtOstatniaCenaNieWlasciciela = new System.Windows.Forms.TextBox();
            this.lbCenaWlasciciela = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.txtOferent = new System.Windows.Forms.TextBox();
            this.lbOferent = new System.Windows.Forms.Label();
            this.lbDodajMarke = new System.Windows.Forms.Label();
            this.txtDodajMarke = new System.Windows.Forms.TextBox();
            this.lbDodajSilnik = new System.Windows.Forms.Label();
            this.txtDodajSilnik = new System.Windows.Forms.TextBox();
            this.lbDodajKolor = new System.Windows.Forms.Label();
            this.txtDodajKolor = new System.Windows.Forms.TextBox();
            this.btnDodajMarke = new System.Windows.Forms.Button();
            this.btnDodajSilnik = new System.Windows.Forms.Button();
            this.btnDodajKolor = new System.Windows.Forms.Button();
            this.btnPoprawjKolor = new System.Windows.Forms.Button();
            this.btnPoprawSilnik = new System.Windows.Forms.Button();
            this.btnPoprawMarke = new System.Windows.Forms.Button();
            this.grbxDaneAuta.SuspendLayout();
            this.SuspendLayout();
            // 
            // lbKhTransakcji
            // 
            this.lbKhTransakcji.AccessibleName = "lbKhTransakcji";
            this.lbKhTransakcji.AutoSize = true;
            this.lbKhTransakcji.Location = new System.Drawing.Point(908, 587);
            this.lbKhTransakcji.Name = "lbKhTransakcji";
            this.lbKhTransakcji.Size = new System.Drawing.Size(87, 17);
            this.lbKhTransakcji.TabIndex = 71;
            this.lbKhTransakcji.Text = "kh transakcji";
            // 
            // txtCzyKhOstatniejTransakcji
            // 
            this.txtCzyKhOstatniejTransakcji.AccessibleDescription = "txtCzyKhOstatniejTransakcj";
            this.txtCzyKhOstatniejTransakcji.Location = new System.Drawing.Point(911, 607);
            this.txtCzyKhOstatniejTransakcji.Name = "txtCzyKhOstatniejTransakcji";
            this.txtCzyKhOstatniejTransakcji.Size = new System.Drawing.Size(80, 22);
            this.txtCzyKhOstatniejTransakcji.TabIndex = 70;
            // 
            // txtIdMarka
            // 
            this.txtIdMarka.AccessibleDescription = "txtIdMarka";
            this.txtIdMarka.Location = new System.Drawing.Point(565, 607);
            this.txtIdMarka.Name = "txtIdMarka";
            this.txtIdMarka.Size = new System.Drawing.Size(59, 22);
            this.txtIdMarka.TabIndex = 57;
            // 
            // lbMarkaId
            // 
            this.lbMarkaId.AccessibleName = "lbMarkaId";
            this.lbMarkaId.AutoSize = true;
            this.lbMarkaId.Location = new System.Drawing.Point(562, 587);
            this.lbMarkaId.Name = "lbMarkaId";
            this.lbMarkaId.Size = new System.Drawing.Size(62, 17);
            this.lbMarkaId.TabIndex = 58;
            this.lbMarkaId.Text = "id marka";
            // 
            // lboxKolor
            // 
            this.lboxKolor.AccessibleName = "lboxKolor";
            this.lboxKolor.BackColor = System.Drawing.SystemColors.Window;
            this.lboxKolor.FormattingEnabled = true;
            this.lboxKolor.ItemHeight = 16;
            this.lboxKolor.Location = new System.Drawing.Point(346, 33);
            this.lboxKolor.Name = "lboxKolor";
            this.lboxKolor.Size = new System.Drawing.Size(162, 324);
            this.lboxKolor.TabIndex = 2;
            this.lboxKolor.SelectedIndexChanged += new System.EventHandler(this.lboxKolor_SelectedIndexChanged);
            // 
            // lboxMarka
            // 
            this.lboxMarka.AccessibleName = "lboxMarka";
            this.lboxMarka.BackColor = System.Drawing.SystemColors.Window;
            this.lboxMarka.FormattingEnabled = true;
            this.lboxMarka.ItemHeight = 16;
            this.lboxMarka.Location = new System.Drawing.Point(15, 33);
            this.lboxMarka.Name = "lboxMarka";
            this.lboxMarka.Size = new System.Drawing.Size(159, 324);
            this.lboxMarka.TabIndex = 0;
            this.lboxMarka.SelectedIndexChanged += new System.EventHandler(this.lboxMarka_SelectedIndexChanged);
            // 
            // lboxSilnik
            // 
            this.lboxSilnik.AccessibleName = "lboxSilnik";
            this.lboxSilnik.BackColor = System.Drawing.SystemColors.Window;
            this.lboxSilnik.FormattingEnabled = true;
            this.lboxSilnik.ItemHeight = 16;
            this.lboxSilnik.Location = new System.Drawing.Point(180, 33);
            this.lboxSilnik.Name = "lboxSilnik";
            this.lboxSilnik.Size = new System.Drawing.Size(160, 324);
            this.lboxSilnik.TabIndex = 1;
            this.lboxSilnik.SelectedIndexChanged += new System.EventHandler(this.lboxSilnik_SelectedIndexChanged);
            // 
            // lbTyp
            // 
            this.lbTyp.AccessibleName = "lbTyp";
            this.lbTyp.AutoSize = true;
            this.lbTyp.Location = new System.Drawing.Point(1001, 587);
            this.lbTyp.Name = "lbTyp";
            this.lbTyp.Size = new System.Drawing.Size(27, 17);
            this.lbTyp.TabIndex = 69;
            this.lbTyp.Text = "typ";
            // 
            // txtTypZalogowanego
            // 
            this.txtTypZalogowanego.AccessibleDescription = "txtTypZalogowanego";
            this.txtTypZalogowanego.Location = new System.Drawing.Point(997, 607);
            this.txtTypZalogowanego.Name = "txtTypZalogowanego";
            this.txtTypZalogowanego.Size = new System.Drawing.Size(61, 22);
            this.txtTypZalogowanego.TabIndex = 68;
            // 
            // txtIdAuta
            // 
            this.txtIdAuta.AccessibleDescription = "txtIdAuta";
            this.txtIdAuta.Location = new System.Drawing.Point(753, 607);
            this.txtIdAuta.Name = "txtIdAuta";
            this.txtIdAuta.Size = new System.Drawing.Size(54, 22);
            this.txtIdAuta.TabIndex = 53;
            // 
            // lbAutoId
            // 
            this.lbAutoId.AccessibleName = "lbAutoId";
            this.lbAutoId.AutoSize = true;
            this.lbAutoId.Location = new System.Drawing.Point(756, 587);
            this.lbAutoId.Name = "lbAutoId";
            this.lbAutoId.Size = new System.Drawing.Size(51, 17);
            this.lbAutoId.TabIndex = 54;
            this.lbAutoId.Text = "id auta";
            // 
            // txtIdWlasciciel
            // 
            this.txtIdWlasciciel.AccessibleDescription = "txtIdWlasciciel";
            this.txtIdWlasciciel.Location = new System.Drawing.Point(813, 607);
            this.txtIdWlasciciel.Name = "txtIdWlasciciel";
            this.txtIdWlasciciel.Size = new System.Drawing.Size(89, 22);
            this.txtIdWlasciciel.TabIndex = 55;
            // 
            // lbWlascicielId
            // 
            this.lbWlascicielId.AccessibleName = "lbWlascicielId";
            this.lbWlascicielId.AutoSize = true;
            this.lbWlascicielId.Location = new System.Drawing.Point(813, 587);
            this.lbWlascicielId.Name = "lbWlascicielId";
            this.lbWlascicielId.Size = new System.Drawing.Size(89, 17);
            this.lbWlascicielId.TabIndex = 56;
            this.lbWlascicielId.Text = "id właściciela";
            // 
            // txtAktualnyStatus
            // 
            this.txtAktualnyStatus.AccessibleDescription = "txtAktualnyStatus";
            this.txtAktualnyStatus.Location = new System.Drawing.Point(12, 39);
            this.txtAktualnyStatus.Name = "txtAktualnyStatus";
            this.txtAktualnyStatus.Size = new System.Drawing.Size(297, 22);
            this.txtAktualnyStatus.TabIndex = 164;
            // 
            // txtCenaWyjsciowa
            // 
            this.txtCenaWyjsciowa.AccessibleDescription = "txtCenaWyjsciowa";
            this.txtCenaWyjsciowa.Location = new System.Drawing.Point(12, 489);
            this.txtCenaWyjsciowa.Name = "txtCenaWyjsciowa";
            this.txtCenaWyjsciowa.Size = new System.Drawing.Size(297, 22);
            this.txtCenaWyjsciowa.TabIndex = 163;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(12, 469);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(182, 17);
            this.label6.TabIndex = 162;
            this.label6.Text = "ostatnia cena przed zmianą";
            // 
            // txtIdTransakcja
            // 
            this.txtIdTransakcja.AccessibleDescription = "txtIdTransakcja";
            this.txtIdTransakcja.Location = new System.Drawing.Point(756, 661);
            this.txtIdTransakcja.Name = "txtIdTransakcja";
            this.txtIdTransakcja.Size = new System.Drawing.Size(85, 22);
            this.txtIdTransakcja.TabIndex = 160;
            // 
            // lbTransakcjaId
            // 
            this.lbTransakcjaId.AccessibleName = "lbTransakcjaId";
            this.lbTransakcjaId.AutoSize = true;
            this.lbTransakcjaId.Location = new System.Drawing.Point(756, 643);
            this.lbTransakcjaId.Name = "lbTransakcjaId";
            this.lbTransakcjaId.Size = new System.Drawing.Size(88, 17);
            this.lbTransakcjaId.TabIndex = 161;
            this.lbTransakcjaId.Text = "id transakcja";
            // 
            // txtIdKtoWycenil
            // 
            this.txtIdKtoWycenil.AccessibleDescription = "txtIdKtoWycenil";
            this.txtIdKtoWycenil.Location = new System.Drawing.Point(853, 661);
            this.txtIdKtoWycenil.Name = "txtIdKtoWycenil";
            this.txtIdKtoWycenil.Size = new System.Drawing.Size(92, 22);
            this.txtIdKtoWycenil.TabIndex = 158;
            // 
            // lbIdWyceniajacego
            // 
            this.lbIdWyceniajacego.AccessibleName = "lbIdWyceniajacego";
            this.lbIdWyceniajacego.AutoSize = true;
            this.lbIdWyceniajacego.Location = new System.Drawing.Point(850, 643);
            this.lbIdWyceniajacego.Name = "lbIdWyceniajacego";
            this.lbIdWyceniajacego.Size = new System.Drawing.Size(95, 17);
            this.lbIdWyceniajacego.TabIndex = 159;
            this.lbIdWyceniajacego.Text = "id kto_wycenil";
            // 
            // btnRezygnacja
            // 
            this.btnRezygnacja.AccessibleName = "btnRezygnacja";
            this.btnRezygnacja.BackColor = System.Drawing.Color.CornflowerBlue;
            this.btnRezygnacja.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnRezygnacja.Location = new System.Drawing.Point(346, 589);
            this.btnRezygnacja.Name = "btnRezygnacja";
            this.btnRezygnacja.Size = new System.Drawing.Size(142, 23);
            this.btnRezygnacja.TabIndex = 157;
            this.btnRezygnacja.Text = "rezygnuję";
            this.btnRezygnacja.UseVisualStyleBackColor = false;
            this.btnRezygnacja.Click += new System.EventHandler(this.btnRezygnacja_Click);
            // 
            // btnSprzedaj
            // 
            this.btnSprzedaj.AccessibleName = "btnSprzedaj";
            this.btnSprzedaj.BackColor = System.Drawing.Color.CornflowerBlue;
            this.btnSprzedaj.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnSprzedaj.Location = new System.Drawing.Point(346, 489);
            this.btnSprzedaj.Name = "btnSprzedaj";
            this.btnSprzedaj.Size = new System.Drawing.Size(142, 23);
            this.btnSprzedaj.TabIndex = 156;
            this.btnSprzedaj.Text = "sprzedaję";
            this.btnSprzedaj.UseVisualStyleBackColor = false;
            this.btnSprzedaj.Click += new System.EventHandler(this.btnSprzedaj_Click);
            // 
            // btnZaakceptuj
            // 
            this.btnZaakceptuj.AccessibleName = "btnZaakceptuj";
            this.btnZaakceptuj.BackColor = System.Drawing.Color.CornflowerBlue;
            this.btnZaakceptuj.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnZaakceptuj.Location = new System.Drawing.Point(346, 539);
            this.btnZaakceptuj.Name = "btnZaakceptuj";
            this.btnZaakceptuj.Size = new System.Drawing.Size(142, 23);
            this.btnZaakceptuj.TabIndex = 155;
            this.btnZaakceptuj.Text = "kupuję";
            this.btnZaakceptuj.UseVisualStyleBackColor = false;
            this.btnZaakceptuj.Click += new System.EventHandler(this.btnZaakceptuj_Click);
            // 
            // btnCena
            // 
            this.btnCena.AccessibleName = "btnCena";
            this.btnCena.BackColor = System.Drawing.Color.DarkTurquoise;
            this.btnCena.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnCena.Location = new System.Drawing.Point(346, 438);
            this.btnCena.Name = "btnCena";
            this.btnCena.Size = new System.Drawing.Size(142, 23);
            this.btnCena.TabIndex = 154;
            this.btnCena.Text = "zatwierdź";
            this.btnCena.UseVisualStyleBackColor = false;
            this.btnCena.Click += new System.EventHandler(this.btnCena_Click);
            // 
            // lbCena
            // 
            this.lbCena.AccessibleName = "lbCena";
            this.lbCena.AutoSize = true;
            this.lbCena.Location = new System.Drawing.Point(12, 419);
            this.lbCena.Name = "lbCena";
            this.lbCena.Size = new System.Drawing.Size(109, 17);
            this.lbCena.TabIndex = 153;
            this.lbCena.Text = "oferowana cena";
            // 
            // txtCena
            // 
            this.txtCena.AccessibleDescription = "txtCena";
            this.txtCena.Location = new System.Drawing.Point(12, 439);
            this.txtCena.Name = "txtCena";
            this.txtCena.Size = new System.Drawing.Size(297, 22);
            this.txtCena.TabIndex = 152;
            // 
            // lbKolorId
            // 
            this.lbKolorId.AccessibleName = "lbKolorId";
            this.lbKolorId.AutoSize = true;
            this.lbKolorId.Location = new System.Drawing.Point(696, 587);
            this.lbKolorId.Name = "lbKolorId";
            this.lbKolorId.Size = new System.Drawing.Size(54, 17);
            this.lbKolorId.TabIndex = 151;
            this.lbKolorId.Text = "id kolor";
            // 
            // lbSilnikId
            // 
            this.lbSilnikId.AccessibleName = "lbSilnikId";
            this.lbSilnikId.AutoSize = true;
            this.lbSilnikId.Location = new System.Drawing.Point(630, 587);
            this.lbSilnikId.Name = "lbSilnikId";
            this.lbSilnikId.Size = new System.Drawing.Size(54, 17);
            this.lbSilnikId.TabIndex = 150;
            this.lbSilnikId.Text = "id silnik";
            // 
            // txtIdKolor
            // 
            this.txtIdKolor.AccessibleDescription = "txtIdKolor";
            this.txtIdKolor.Location = new System.Drawing.Point(696, 607);
            this.txtIdKolor.Name = "txtIdKolor";
            this.txtIdKolor.Size = new System.Drawing.Size(51, 22);
            this.txtIdKolor.TabIndex = 149;
            // 
            // textZalogowany
            // 
            this.textZalogowany.AccessibleDescription = "textZalogowany";
            this.textZalogowany.Location = new System.Drawing.Point(648, 661);
            this.textZalogowany.Name = "textZalogowany";
            this.textZalogowany.Size = new System.Drawing.Size(102, 22);
            this.textZalogowany.TabIndex = 146;
            // 
            // txtIdSilnik
            // 
            this.txtIdSilnik.AccessibleDescription = "txtIdSilnik";
            this.txtIdSilnik.Location = new System.Drawing.Point(633, 607);
            this.txtIdSilnik.Name = "txtIdSilnik";
            this.txtIdSilnik.Size = new System.Drawing.Size(51, 22);
            this.txtIdSilnik.TabIndex = 148;
            // 
            // rtxKomunikaty
            // 
            this.rtxKomunikaty.AccessibleName = "rtxKomunikaty";
            this.rtxKomunikaty.Location = new System.Drawing.Point(539, 20);
            this.rtxKomunikaty.Name = "rtxKomunikaty";
            this.rtxKomunikaty.Size = new System.Drawing.Size(493, 22);
            this.rtxKomunikaty.TabIndex = 147;
            this.rtxKomunikaty.Text = "";
            // 
            // btnZamknijDaneAuta
            // 
            this.btnZamknijDaneAuta.AccessibleName = "btnZamknijDaneAuta";
            this.btnZamknijDaneAuta.BackColor = System.Drawing.Color.DarkTurquoise;
            this.btnZamknijDaneAuta.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnZamknijDaneAuta.Location = new System.Drawing.Point(870, 706);
            this.btnZamknijDaneAuta.Name = "btnZamknijDaneAuta";
            this.btnZamknijDaneAuta.Size = new System.Drawing.Size(142, 23);
            this.btnZamknijDaneAuta.TabIndex = 145;
            this.btnZamknijDaneAuta.Text = "zamknij";
            this.btnZamknijDaneAuta.UseVisualStyleBackColor = false;
            this.btnZamknijDaneAuta.Click += new System.EventHandler(this.btnZamknijDaneAuta_Click);
            // 
            // btnDodajAuto
            // 
            this.btnDodajAuto.AccessibleName = "btnDodajAuto";
            this.btnDodajAuto.BackColor = System.Drawing.Color.CornflowerBlue;
            this.btnDodajAuto.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnDodajAuto.Location = new System.Drawing.Point(346, 39);
            this.btnDodajAuto.Name = "btnDodajAuto";
            this.btnDodajAuto.Size = new System.Drawing.Size(142, 23);
            this.btnDodajAuto.TabIndex = 144;
            this.btnDodajAuto.Text = "dodaj samochód";
            this.btnDodajAuto.UseVisualStyleBackColor = false;
            this.btnDodajAuto.Click += new System.EventHandler(this.btnDodajAuto_Click);
            // 
            // btnPrzebieg
            // 
            this.btnPrzebieg.AccessibleName = "btnPrzebieg";
            this.btnPrzebieg.BackColor = System.Drawing.Color.DarkTurquoise;
            this.btnPrzebieg.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnPrzebieg.Location = new System.Drawing.Point(346, 289);
            this.btnPrzebieg.Name = "btnPrzebieg";
            this.btnPrzebieg.Size = new System.Drawing.Size(142, 23);
            this.btnPrzebieg.TabIndex = 143;
            this.btnPrzebieg.Text = "zatwierdź";
            this.btnPrzebieg.UseVisualStyleBackColor = false;
            this.btnPrzebieg.Click += new System.EventHandler(this.btnPrzebieg_Click);
            // 
            // btnRok
            // 
            this.btnRok.AccessibleName = "btnRok";
            this.btnRok.BackColor = System.Drawing.Color.DarkTurquoise;
            this.btnRok.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnRok.Location = new System.Drawing.Point(346, 238);
            this.btnRok.Name = "btnRok";
            this.btnRok.Size = new System.Drawing.Size(142, 23);
            this.btnRok.TabIndex = 142;
            this.btnRok.Text = "zatwierdź";
            this.btnRok.UseVisualStyleBackColor = false;
            this.btnRok.Click += new System.EventHandler(this.btnRok_Click);
            // 
            // btnWyczyscDaneAuta
            // 
            this.btnWyczyscDaneAuta.AccessibleName = "btnWyczyscDaneAuta";
            this.btnWyczyscDaneAuta.BackColor = System.Drawing.Color.DarkTurquoise;
            this.btnWyczyscDaneAuta.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnWyczyscDaneAuta.Location = new System.Drawing.Point(539, 706);
            this.btnWyczyscDaneAuta.Name = "btnWyczyscDaneAuta";
            this.btnWyczyscDaneAuta.Size = new System.Drawing.Size(142, 23);
            this.btnWyczyscDaneAuta.TabIndex = 141;
            this.btnWyczyscDaneAuta.Text = "wyczyść";
            this.btnWyczyscDaneAuta.UseVisualStyleBackColor = false;
            this.btnWyczyscDaneAuta.Click += new System.EventHandler(this.btnWyczyscDaneAuta_Click);
            // 
            // btnSilnik
            // 
            this.btnSilnik.AccessibleName = "btnSilnik";
            this.btnSilnik.BackColor = System.Drawing.Color.DarkTurquoise;
            this.btnSilnik.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnSilnik.Location = new System.Drawing.Point(346, 139);
            this.btnSilnik.Name = "btnSilnik";
            this.btnSilnik.Size = new System.Drawing.Size(142, 23);
            this.btnSilnik.TabIndex = 140;
            this.btnSilnik.Text = "zatwierdź";
            this.btnSilnik.UseVisualStyleBackColor = false;
            this.btnSilnik.Click += new System.EventHandler(this.btnSilnik_Click);
            // 
            // btnMarka
            // 
            this.btnMarka.AccessibleName = "btnMarka";
            this.btnMarka.BackColor = System.Drawing.Color.DarkTurquoise;
            this.btnMarka.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnMarka.Location = new System.Drawing.Point(346, 89);
            this.btnMarka.Name = "btnMarka";
            this.btnMarka.Size = new System.Drawing.Size(142, 23);
            this.btnMarka.TabIndex = 139;
            this.btnMarka.Text = "zatwierdź";
            this.btnMarka.UseVisualStyleBackColor = false;
            this.btnMarka.Click += new System.EventHandler(this.btnMarka_Click);
            // 
            // btnKolor
            // 
            this.btnKolor.AccessibleName = "btnKolor";
            this.btnKolor.BackColor = System.Drawing.Color.DarkTurquoise;
            this.btnKolor.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnKolor.Location = new System.Drawing.Point(346, 339);
            this.btnKolor.Name = "btnKolor";
            this.btnKolor.Size = new System.Drawing.Size(142, 23);
            this.btnKolor.TabIndex = 138;
            this.btnKolor.Text = "zatwierdź";
            this.btnKolor.UseVisualStyleBackColor = false;
            this.btnKolor.Click += new System.EventHandler(this.btnKolor_Click);
            // 
            // btnRejestracja
            // 
            this.btnRejestracja.AccessibleName = "btnRejestracja";
            this.btnRejestracja.BackColor = System.Drawing.Color.DarkTurquoise;
            this.btnRejestracja.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnRejestracja.Location = new System.Drawing.Point(346, 389);
            this.btnRejestracja.Name = "btnRejestracja";
            this.btnRejestracja.Size = new System.Drawing.Size(142, 23);
            this.btnRejestracja.TabIndex = 137;
            this.btnRejestracja.Text = "zatwierdź";
            this.btnRejestracja.UseVisualStyleBackColor = false;
            this.btnRejestracja.Click += new System.EventHandler(this.btnRejestracja_Click);
            // 
            // lbRejestracja
            // 
            this.lbRejestracja.AutoSize = true;
            this.lbRejestracja.Location = new System.Drawing.Point(12, 369);
            this.lbRejestracja.Name = "lbRejestracja";
            this.lbRejestracja.Size = new System.Drawing.Size(132, 17);
            this.lbRejestracja.TabIndex = 136;
            this.lbRejestracja.Text = "numer rejestracyjny";
            // 
            // txtRejestracja
            // 
            this.txtRejestracja.AccessibleDescription = "txtRejestracja";
            this.txtRejestracja.Location = new System.Drawing.Point(12, 389);
            this.txtRejestracja.Name = "txtRejestracja";
            this.txtRejestracja.Size = new System.Drawing.Size(297, 22);
            this.txtRejestracja.TabIndex = 135;
            // 
            // lbKolor
            // 
            this.lbKolor.AutoSize = true;
            this.lbKolor.Location = new System.Drawing.Point(12, 319);
            this.lbKolor.Name = "lbKolor";
            this.lbKolor.Size = new System.Drawing.Size(39, 17);
            this.lbKolor.TabIndex = 134;
            this.lbKolor.Text = "kolor";
            // 
            // txtKolor
            // 
            this.txtKolor.AccessibleDescription = "txtKolor";
            this.txtKolor.Location = new System.Drawing.Point(12, 339);
            this.txtKolor.Name = "txtKolor";
            this.txtKolor.Size = new System.Drawing.Size(297, 22);
            this.txtKolor.TabIndex = 133;
            // 
            // lbPrzebieg
            // 
            this.lbPrzebieg.AutoSize = true;
            this.lbPrzebieg.Location = new System.Drawing.Point(9, 269);
            this.lbPrzebieg.Name = "lbPrzebieg";
            this.lbPrzebieg.Size = new System.Drawing.Size(63, 17);
            this.lbPrzebieg.TabIndex = 132;
            this.lbPrzebieg.Text = "przebieg";
            // 
            // txtPrzebieg
            // 
            this.txtPrzebieg.AccessibleDescription = "txtPrzebieg";
            this.txtPrzebieg.Location = new System.Drawing.Point(12, 289);
            this.txtPrzebieg.Name = "txtPrzebieg";
            this.txtPrzebieg.Size = new System.Drawing.Size(297, 22);
            this.txtPrzebieg.TabIndex = 131;
            // 
            // lbRok
            // 
            this.lbRok.AutoSize = true;
            this.lbRok.Location = new System.Drawing.Point(12, 219);
            this.lbRok.Name = "lbRok";
            this.lbRok.Size = new System.Drawing.Size(89, 17);
            this.lbRok.TabIndex = 130;
            this.lbRok.Text = "rok produkcji";
            // 
            // txtRok
            // 
            this.txtRok.AccessibleDescription = "txtRok";
            this.txtRok.Location = new System.Drawing.Point(12, 239);
            this.txtRok.Name = "txtRok";
            this.txtRok.Size = new System.Drawing.Size(297, 22);
            this.txtRok.TabIndex = 129;
            // 
            // lbWlasciciel
            // 
            this.lbWlasciciel.AutoSize = true;
            this.lbWlasciciel.Location = new System.Drawing.Point(12, 169);
            this.lbWlasciciel.Name = "lbWlasciciel";
            this.lbWlasciciel.Size = new System.Drawing.Size(66, 17);
            this.lbWlasciciel.TabIndex = 128;
            this.lbWlasciciel.Text = "wlasciciel";
            // 
            // txtWlasciciel
            // 
            this.txtWlasciciel.AccessibleDescription = "txtWlasciciel";
            this.txtWlasciciel.Location = new System.Drawing.Point(12, 189);
            this.txtWlasciciel.Name = "txtWlasciciel";
            this.txtWlasciciel.Size = new System.Drawing.Size(297, 22);
            this.txtWlasciciel.TabIndex = 127;
            // 
            // lbSilnik
            // 
            this.lbSilnik.AutoSize = true;
            this.lbSilnik.Location = new System.Drawing.Point(12, 119);
            this.lbSilnik.Name = "lbSilnik";
            this.lbSilnik.Size = new System.Drawing.Size(39, 17);
            this.lbSilnik.TabIndex = 126;
            this.lbSilnik.Text = "silnik";
            // 
            // txtSilnik
            // 
            this.txtSilnik.AccessibleDescription = "txtSilnik";
            this.txtSilnik.Location = new System.Drawing.Point(12, 139);
            this.txtSilnik.Name = "txtSilnik";
            this.txtSilnik.Size = new System.Drawing.Size(297, 22);
            this.txtSilnik.TabIndex = 125;
            // 
            // lbMarka
            // 
            this.lbMarka.AutoSize = true;
            this.lbMarka.Location = new System.Drawing.Point(12, 71);
            this.lbMarka.Name = "lbMarka";
            this.lbMarka.Size = new System.Drawing.Size(47, 17);
            this.lbMarka.TabIndex = 124;
            this.lbMarka.Text = "marka";
            // 
            // txtMarka
            // 
            this.txtMarka.AccessibleDescription = "txtMarka";
            this.txtMarka.Location = new System.Drawing.Point(12, 89);
            this.txtMarka.Name = "txtMarka";
            this.txtMarka.Size = new System.Drawing.Size(297, 22);
            this.txtMarka.TabIndex = 123;
            // 
            // grbxDaneAuta
            // 
            this.grbxDaneAuta.AccessibleName = "grbxDaneAuta";
            this.grbxDaneAuta.Controls.Add(this.lboxKolor);
            this.grbxDaneAuta.Controls.Add(this.lboxMarka);
            this.grbxDaneAuta.Controls.Add(this.lboxSilnik);
            this.grbxDaneAuta.Location = new System.Drawing.Point(524, 64);
            this.grbxDaneAuta.Name = "grbxDaneAuta";
            this.grbxDaneAuta.Size = new System.Drawing.Size(534, 381);
            this.grbxDaneAuta.TabIndex = 122;
            this.grbxDaneAuta.TabStop = false;
            this.grbxDaneAuta.Text = "wybierz dane samochodu";
            // 
            // txtAdministracja
            // 
            this.txtAdministracja.AccessibleDescription = "txtAdministracja";
            this.txtAdministracja.Location = new System.Drawing.Point(565, 661);
            this.txtAdministracja.Name = "txtAdministracja";
            this.txtAdministracja.Size = new System.Drawing.Size(77, 22);
            this.txtAdministracja.TabIndex = 147;
            // 
            // lbAdministracja
            // 
            this.lbAdministracja.AccessibleName = "lbAdministracja";
            this.lbAdministracja.AutoSize = true;
            this.lbAdministracja.Location = new System.Drawing.Point(556, 643);
            this.lbAdministracja.Name = "lbAdministracja";
            this.lbAdministracja.Size = new System.Drawing.Size(91, 17);
            this.lbAdministracja.TabIndex = 152;
            this.lbAdministracja.Text = "administracja";
            // 
            // lbCenaNieWlasciciela
            // 
            this.lbCenaNieWlasciciela.AccessibleName = "lbCenaNieWlasciciela";
            this.lbCenaNieWlasciciela.AutoSize = true;
            this.lbCenaNieWlasciciela.Location = new System.Drawing.Point(12, 519);
            this.lbCenaNieWlasciciela.Name = "lbCenaNieWlasciciela";
            this.lbCenaNieWlasciciela.Size = new System.Drawing.Size(186, 17);
            this.lbCenaNieWlasciciela.TabIndex = 165;
            this.lbCenaNieWlasciciela.Text = "ostatnia cena nie właściciela";
            // 
            // lbZalogowanyId
            // 
            this.lbZalogowanyId.AccessibleName = "lbZalogowanyId";
            this.lbZalogowanyId.AutoSize = true;
            this.lbZalogowanyId.Location = new System.Drawing.Point(645, 641);
            this.lbZalogowanyId.Name = "lbZalogowanyId";
            this.lbZalogowanyId.Size = new System.Drawing.Size(82, 17);
            this.lbZalogowanyId.TabIndex = 162;
            this.lbZalogowanyId.Text = "zalogowany";
            // 
            // lbMojaCena
            // 
            this.lbMojaCena.AccessibleName = "lbMojaCena";
            this.lbMojaCena.AutoSize = true;
            this.lbMojaCena.Location = new System.Drawing.Point(12, 672);
            this.lbMojaCena.Name = "lbMojaCena";
            this.lbMojaCena.Size = new System.Drawing.Size(127, 17);
            this.lbMojaCena.TabIndex = 166;
            this.lbMojaCena.Text = "moja ostatnia cena";
            // 
            // txtOstatniaCenaWlasciciela
            // 
            this.txtOstatniaCenaWlasciciela.AccessibleDescription = "txtOstatniaCenaWlasciciela";
            this.txtOstatniaCenaWlasciciela.Location = new System.Drawing.Point(12, 639);
            this.txtOstatniaCenaWlasciciela.Name = "txtOstatniaCenaWlasciciela";
            this.txtOstatniaCenaWlasciciela.Size = new System.Drawing.Size(297, 22);
            this.txtOstatniaCenaWlasciciela.TabIndex = 167;
            // 
            // txtMojaCena
            // 
            this.txtMojaCena.AccessibleDescription = "txtMojaCena";
            this.txtMojaCena.Location = new System.Drawing.Point(12, 689);
            this.txtMojaCena.Name = "txtMojaCena";
            this.txtMojaCena.Size = new System.Drawing.Size(297, 22);
            this.txtMojaCena.TabIndex = 168;
            // 
            // txtOstatniaCenaNieWlasciciela
            // 
            this.txtOstatniaCenaNieWlasciciela.AccessibleDescription = "txtOstatniaCenaNieWlasciciela";
            this.txtOstatniaCenaNieWlasciciela.Location = new System.Drawing.Point(12, 539);
            this.txtOstatniaCenaNieWlasciciela.Name = "txtOstatniaCenaNieWlasciciela";
            this.txtOstatniaCenaNieWlasciciela.Size = new System.Drawing.Size(297, 22);
            this.txtOstatniaCenaNieWlasciciela.TabIndex = 169;
            // 
            // lbCenaWlasciciela
            // 
            this.lbCenaWlasciciela.AccessibleName = "lbCenaWlasciciela";
            this.lbCenaWlasciciela.AutoSize = true;
            this.lbCenaWlasciciela.Location = new System.Drawing.Point(12, 622);
            this.lbCenaWlasciciela.Name = "lbCenaWlasciciela";
            this.lbCenaWlasciciela.Size = new System.Drawing.Size(163, 17);
            this.lbCenaWlasciciela.TabIndex = 170;
            this.lbCenaWlasciciela.Text = "ostatnia cena właściciela";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(12, 21);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(103, 17);
            this.label15.TabIndex = 171;
            this.label15.Text = "aktualny status";
            // 
            // txtOferent
            // 
            this.txtOferent.AccessibleDescription = "txtOferent";
            this.txtOferent.Location = new System.Drawing.Point(12, 589);
            this.txtOferent.Name = "txtOferent";
            this.txtOferent.Size = new System.Drawing.Size(297, 22);
            this.txtOferent.TabIndex = 173;
            // 
            // lbOferent
            // 
            this.lbOferent.AccessibleName = "lbOferent";
            this.lbOferent.AutoSize = true;
            this.lbOferent.Location = new System.Drawing.Point(12, 569);
            this.lbOferent.Name = "lbOferent";
            this.lbOferent.Size = new System.Drawing.Size(150, 17);
            this.lbOferent.TabIndex = 172;
            this.lbOferent.Text = "kto zaoferował tą cenę";
            // 
            // lbDodajMarke
            // 
            this.lbDodajMarke.AccessibleName = "lbDodajMarke";
            this.lbDodajMarke.AutoSize = true;
            this.lbDodajMarke.Location = new System.Drawing.Point(536, 457);
            this.lbDodajMarke.Name = "lbDodajMarke";
            this.lbDodajMarke.Size = new System.Drawing.Size(47, 17);
            this.lbDodajMarke.TabIndex = 175;
            this.lbDodajMarke.Text = "marka";
            // 
            // txtDodajMarke
            // 
            this.txtDodajMarke.AccessibleDescription = "txtDodajMarke";
            this.txtDodajMarke.Location = new System.Drawing.Point(539, 477);
            this.txtDodajMarke.Name = "txtDodajMarke";
            this.txtDodajMarke.Size = new System.Drawing.Size(159, 22);
            this.txtDodajMarke.TabIndex = 174;
            // 
            // lbDodajSilnik
            // 
            this.lbDodajSilnik.AccessibleName = "lbDodajSilnik";
            this.lbDodajSilnik.AutoSize = true;
            this.lbDodajSilnik.Location = new System.Drawing.Point(711, 457);
            this.lbDodajSilnik.Name = "lbDodajSilnik";
            this.lbDodajSilnik.Size = new System.Drawing.Size(39, 17);
            this.lbDodajSilnik.TabIndex = 177;
            this.lbDodajSilnik.Text = "silnik";
            // 
            // txtDodajSilnik
            // 
            this.txtDodajSilnik.AccessibleDescription = "txtDodajSilnik";
            this.txtDodajSilnik.Location = new System.Drawing.Point(704, 477);
            this.txtDodajSilnik.Name = "txtDodajSilnik";
            this.txtDodajSilnik.Size = new System.Drawing.Size(160, 22);
            this.txtDodajSilnik.TabIndex = 176;
            // 
            // lbDodajKolor
            // 
            this.lbDodajKolor.AccessibleName = "lbDodajKolor";
            this.lbDodajKolor.AutoSize = true;
            this.lbDodajKolor.Location = new System.Drawing.Point(867, 457);
            this.lbDodajKolor.Name = "lbDodajKolor";
            this.lbDodajKolor.Size = new System.Drawing.Size(39, 17);
            this.lbDodajKolor.TabIndex = 179;
            this.lbDodajKolor.Text = "kolor";
            // 
            // txtDodajKolor
            // 
            this.txtDodajKolor.AccessibleDescription = "txtDodajKolor";
            this.txtDodajKolor.Location = new System.Drawing.Point(870, 477);
            this.txtDodajKolor.Name = "txtDodajKolor";
            this.txtDodajKolor.Size = new System.Drawing.Size(162, 22);
            this.txtDodajKolor.TabIndex = 178;
            // 
            // btnDodajMarke
            // 
            this.btnDodajMarke.AccessibleName = "btnDodajMarke";
            this.btnDodajMarke.BackColor = System.Drawing.Color.DarkTurquoise;
            this.btnDodajMarke.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnDodajMarke.Location = new System.Drawing.Point(539, 510);
            this.btnDodajMarke.Name = "btnDodajMarke";
            this.btnDodajMarke.Size = new System.Drawing.Size(159, 23);
            this.btnDodajMarke.TabIndex = 180;
            this.btnDodajMarke.Text = "dodaj markę";
            this.btnDodajMarke.UseVisualStyleBackColor = false;
            this.btnDodajMarke.Click += new System.EventHandler(this.btnDodajMarke_Click);
            // 
            // btnDodajSilnik
            // 
            this.btnDodajSilnik.AccessibleName = "btnDodajSilnik";
            this.btnDodajSilnik.BackColor = System.Drawing.Color.DarkTurquoise;
            this.btnDodajSilnik.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnDodajSilnik.Location = new System.Drawing.Point(704, 510);
            this.btnDodajSilnik.Name = "btnDodajSilnik";
            this.btnDodajSilnik.Size = new System.Drawing.Size(160, 23);
            this.btnDodajSilnik.TabIndex = 181;
            this.btnDodajSilnik.Text = "dodaj silnik";
            this.btnDodajSilnik.UseVisualStyleBackColor = false;
            this.btnDodajSilnik.Click += new System.EventHandler(this.btnDodajSilnik_Click);
            // 
            // btnDodajKolor
            // 
            this.btnDodajKolor.AccessibleName = "btnDodajKolor";
            this.btnDodajKolor.BackColor = System.Drawing.Color.DarkTurquoise;
            this.btnDodajKolor.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnDodajKolor.Location = new System.Drawing.Point(870, 510);
            this.btnDodajKolor.Name = "btnDodajKolor";
            this.btnDodajKolor.Size = new System.Drawing.Size(162, 23);
            this.btnDodajKolor.TabIndex = 182;
            this.btnDodajKolor.Text = "dodaj kolor";
            this.btnDodajKolor.UseVisualStyleBackColor = false;
            this.btnDodajKolor.Click += new System.EventHandler(this.btnDodajKolor_Click);
            // 
            // btnPoprawjKolor
            // 
            this.btnPoprawjKolor.AccessibleName = "btnPoprawjKolor";
            this.btnPoprawjKolor.BackColor = System.Drawing.Color.DarkTurquoise;
            this.btnPoprawjKolor.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnPoprawjKolor.Location = new System.Drawing.Point(870, 539);
            this.btnPoprawjKolor.Name = "btnPoprawjKolor";
            this.btnPoprawjKolor.Size = new System.Drawing.Size(162, 23);
            this.btnPoprawjKolor.TabIndex = 185;
            this.btnPoprawjKolor.Text = "popraw kolor";
            this.btnPoprawjKolor.UseVisualStyleBackColor = false;
            this.btnPoprawjKolor.Click += new System.EventHandler(this.btnPoprawjKolor_Click);
            // 
            // btnPoprawSilnik
            // 
            this.btnPoprawSilnik.AccessibleName = "btnPoprawSilnik";
            this.btnPoprawSilnik.BackColor = System.Drawing.Color.DarkTurquoise;
            this.btnPoprawSilnik.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnPoprawSilnik.Location = new System.Drawing.Point(704, 539);
            this.btnPoprawSilnik.Name = "btnPoprawSilnik";
            this.btnPoprawSilnik.Size = new System.Drawing.Size(160, 23);
            this.btnPoprawSilnik.TabIndex = 184;
            this.btnPoprawSilnik.Text = "popraw silnik";
            this.btnPoprawSilnik.UseVisualStyleBackColor = false;
            this.btnPoprawSilnik.Click += new System.EventHandler(this.btnPoprawSilnik_Click);
            // 
            // btnPoprawMarke
            // 
            this.btnPoprawMarke.AccessibleName = "btnPoprawMarke";
            this.btnPoprawMarke.BackColor = System.Drawing.Color.DarkTurquoise;
            this.btnPoprawMarke.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnPoprawMarke.Location = new System.Drawing.Point(539, 539);
            this.btnPoprawMarke.Name = "btnPoprawMarke";
            this.btnPoprawMarke.Size = new System.Drawing.Size(159, 23);
            this.btnPoprawMarke.TabIndex = 183;
            this.btnPoprawMarke.Text = "popraw markę";
            this.btnPoprawMarke.UseVisualStyleBackColor = false;
            this.btnPoprawMarke.Click += new System.EventHandler(this.btnPoprawMarke_Click);
            // 
            // DaneSamochodu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(1072, 754);
            this.Controls.Add(this.btnPoprawjKolor);
            this.Controls.Add(this.btnPoprawSilnik);
            this.Controls.Add(this.btnPoprawMarke);
            this.Controls.Add(this.btnDodajKolor);
            this.Controls.Add(this.btnDodajSilnik);
            this.Controls.Add(this.btnDodajMarke);
            this.Controls.Add(this.lbDodajKolor);
            this.Controls.Add(this.txtDodajKolor);
            this.Controls.Add(this.lbDodajSilnik);
            this.Controls.Add(this.txtDodajSilnik);
            this.Controls.Add(this.lbDodajMarke);
            this.Controls.Add(this.txtDodajMarke);
            this.Controls.Add(this.txtOferent);
            this.Controls.Add(this.lbOferent);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.lbCenaWlasciciela);
            this.Controls.Add(this.txtOstatniaCenaNieWlasciciela);
            this.Controls.Add(this.txtMojaCena);
            this.Controls.Add(this.txtOstatniaCenaWlasciciela);
            this.Controls.Add(this.lbMojaCena);
            this.Controls.Add(this.lbZalogowanyId);
            this.Controls.Add(this.lbCenaNieWlasciciela);
            this.Controls.Add(this.lbAdministracja);
            this.Controls.Add(this.txtAktualnyStatus);
            this.Controls.Add(this.txtAdministracja);
            this.Controls.Add(this.txtCenaWyjsciowa);
            this.Controls.Add(this.lbKhTransakcji);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.txtIdKtoWycenil);
            this.Controls.Add(this.btnRezygnacja);
            this.Controls.Add(this.txtIdTransakcja);
            this.Controls.Add(this.btnSprzedaj);
            this.Controls.Add(this.lbIdWyceniajacego);
            this.Controls.Add(this.btnZaakceptuj);
            this.Controls.Add(this.txtCzyKhOstatniejTransakcji);
            this.Controls.Add(this.btnCena);
            this.Controls.Add(this.lbTransakcjaId);
            this.Controls.Add(this.lbCena);
            this.Controls.Add(this.txtIdMarka);
            this.Controls.Add(this.txtCena);
            this.Controls.Add(this.lbMarkaId);
            this.Controls.Add(this.rtxKomunikaty);
            this.Controls.Add(this.textZalogowany);
            this.Controls.Add(this.btnZamknijDaneAuta);
            this.Controls.Add(this.btnDodajAuto);
            this.Controls.Add(this.btnPrzebieg);
            this.Controls.Add(this.btnRok);
            this.Controls.Add(this.lbTyp);
            this.Controls.Add(this.btnWyczyscDaneAuta);
            this.Controls.Add(this.txtTypZalogowanego);
            this.Controls.Add(this.btnSilnik);
            this.Controls.Add(this.txtIdAuta);
            this.Controls.Add(this.btnMarka);
            this.Controls.Add(this.lbAutoId);
            this.Controls.Add(this.btnKolor);
            this.Controls.Add(this.txtIdWlasciciel);
            this.Controls.Add(this.btnRejestracja);
            this.Controls.Add(this.lbWlascicielId);
            this.Controls.Add(this.lbRejestracja);
            this.Controls.Add(this.lbSilnikId);
            this.Controls.Add(this.txtRejestracja);
            this.Controls.Add(this.txtIdKolor);
            this.Controls.Add(this.lbKolor);
            this.Controls.Add(this.lbKolorId);
            this.Controls.Add(this.txtIdSilnik);
            this.Controls.Add(this.txtKolor);
            this.Controls.Add(this.lbPrzebieg);
            this.Controls.Add(this.txtPrzebieg);
            this.Controls.Add(this.lbRok);
            this.Controls.Add(this.txtRok);
            this.Controls.Add(this.lbWlasciciel);
            this.Controls.Add(this.txtWlasciciel);
            this.Controls.Add(this.lbSilnik);
            this.Controls.Add(this.txtSilnik);
            this.Controls.Add(this.lbMarka);
            this.Controls.Add(this.txtMarka);
            this.Controls.Add(this.grbxDaneAuta);
            this.Name = "DaneSamochodu";
            this.Text = "DaneSamochodu";
            this.Load += new System.EventHandler(this.DaneSamochodu_Load);
            this.grbxDaneAuta.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbKhTransakcji;
        private System.Windows.Forms.TextBox txtCzyKhOstatniejTransakcji;
        private System.Windows.Forms.TextBox txtIdMarka;
        private System.Windows.Forms.Label lbMarkaId;
        private System.Windows.Forms.ListBox lboxKolor;
        private System.Windows.Forms.ListBox lboxMarka;
        private System.Windows.Forms.ListBox lboxSilnik;
        private System.Windows.Forms.Label lbTyp;
        private System.Windows.Forms.TextBox txtTypZalogowanego;
        private System.Windows.Forms.TextBox txtIdAuta;
        private System.Windows.Forms.Label lbAutoId;
        private System.Windows.Forms.TextBox txtIdWlasciciel;
        private System.Windows.Forms.Label lbWlascicielId;
        private System.Windows.Forms.TextBox txtAktualnyStatus;
        private System.Windows.Forms.TextBox txtCenaWyjsciowa;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtIdTransakcja;
        private System.Windows.Forms.Label lbTransakcjaId;
        private System.Windows.Forms.TextBox txtIdKtoWycenil;
        private System.Windows.Forms.Label lbIdWyceniajacego;
        private System.Windows.Forms.Button btnRezygnacja;
        private System.Windows.Forms.Button btnSprzedaj;
        private System.Windows.Forms.Button btnZaakceptuj;
        private System.Windows.Forms.Button btnCena;
        private System.Windows.Forms.Label lbCena;
        private System.Windows.Forms.TextBox txtCena;
        private System.Windows.Forms.Label lbKolorId;
        private System.Windows.Forms.Label lbSilnikId;
        private System.Windows.Forms.TextBox txtIdKolor;
        private System.Windows.Forms.TextBox textZalogowany;
        private System.Windows.Forms.TextBox txtIdSilnik;
        private System.Windows.Forms.RichTextBox rtxKomunikaty;
        private System.Windows.Forms.Button btnZamknijDaneAuta;
        private System.Windows.Forms.Button btnDodajAuto;
        private System.Windows.Forms.Button btnPrzebieg;
        private System.Windows.Forms.Button btnRok;
        private System.Windows.Forms.Button btnWyczyscDaneAuta;
        private System.Windows.Forms.Button btnSilnik;
        private System.Windows.Forms.Button btnMarka;
        private System.Windows.Forms.Button btnKolor;
        private System.Windows.Forms.Button btnRejestracja;
        private System.Windows.Forms.Label lbRejestracja;
        private System.Windows.Forms.TextBox txtRejestracja;
        private System.Windows.Forms.Label lbKolor;
        private System.Windows.Forms.TextBox txtKolor;
        private System.Windows.Forms.Label lbPrzebieg;
        private System.Windows.Forms.TextBox txtPrzebieg;
        private System.Windows.Forms.Label lbRok;
        private System.Windows.Forms.TextBox txtRok;
        private System.Windows.Forms.Label lbWlasciciel;
        private System.Windows.Forms.TextBox txtWlasciciel;
        private System.Windows.Forms.Label lbSilnik;
        private System.Windows.Forms.TextBox txtSilnik;
        private System.Windows.Forms.Label lbMarka;
        private System.Windows.Forms.TextBox txtMarka;
        private System.Windows.Forms.GroupBox grbxDaneAuta;
        private System.Windows.Forms.TextBox txtAdministracja;
        private System.Windows.Forms.Label lbAdministracja;
        private System.Windows.Forms.Label lbCenaNieWlasciciela;
        private System.Windows.Forms.Label lbZalogowanyId;
        private System.Windows.Forms.Label lbMojaCena;
        private System.Windows.Forms.TextBox txtOstatniaCenaWlasciciela;
        private System.Windows.Forms.TextBox txtMojaCena;
        private System.Windows.Forms.TextBox txtOstatniaCenaNieWlasciciela;
        private System.Windows.Forms.Label lbCenaWlasciciela;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox txtOferent;
        private System.Windows.Forms.Label lbOferent;
        private System.Windows.Forms.Label lbDodajMarke;
        private System.Windows.Forms.TextBox txtDodajMarke;
        private System.Windows.Forms.Label lbDodajSilnik;
        private System.Windows.Forms.TextBox txtDodajSilnik;
        private System.Windows.Forms.Label lbDodajKolor;
        private System.Windows.Forms.TextBox txtDodajKolor;
        private System.Windows.Forms.Button btnDodajMarke;
        private System.Windows.Forms.Button btnDodajSilnik;
        private System.Windows.Forms.Button btnDodajKolor;
        private System.Windows.Forms.Button btnPoprawjKolor;
        private System.Windows.Forms.Button btnPoprawSilnik;
        private System.Windows.Forms.Button btnPoprawMarke;
    }
}