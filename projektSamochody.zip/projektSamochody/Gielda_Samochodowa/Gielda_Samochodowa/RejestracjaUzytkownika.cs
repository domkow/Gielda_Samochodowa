﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Gielda_Samochodowa
{
    public partial class RejestracjaUzytkownika : Form
    {
        public RejestracjaUzytkownika()
        {
            InitializeComponent();
        }

        private void RejestracjaUzytkownika_Load(object sender, EventArgs e)
        {

        }

        DBSamochodyEntities baza = new DBSamochodyEntities();


        private void RejestracjaKontrahenta_Load(object sender, EventArgs e)
        {

        }

        public int definiuj_swoj_typ(string typ)
        {

            int moj_typ = 0;
            Typ_Obiektu wybrany_typ_kontrahenta = new Typ_Obiektu();
            var wybrany_typ = baza.Typ_Obiektu.Where(znajdz => znajdz.nazwa == typ);
            foreach (Typ_Obiektu wiersz in wybrany_typ)
            {
                moj_typ = wiersz.id;
            }
            return moj_typ;
        }


        public void rejestracja_kontrahenta(string typ)
        {

            Kontrahenci kontrahent = new Kontrahenci
            {
                typ = definiuj_swoj_typ(typ),
                nazwa = txtUzytkownik.Text.Trim(),
                haslo = mtxHaslo.Text
            };

            rtxKomunikatRejestracji.Text = "";
            if (kontrahent.nazwa == "" || kontrahent.haslo == "")
            {
                rtxKomunikatRejestracji.Text = "Wpisz w pola tekstowe dane rejestrowanego klienta i kliknij w zarejestruj";
                //txtTestHasla.Text = kontrahent.haslo;
            }
            else
            {
                if (mtxPowtorzHaslo.Text != mtxHaslo.Text)
                {
                    rtxKomunikatRejestracji.Text = "Potwierdzane haslo jest inne niz wprowadzone";
                }
                else
                {
                    try

                    {
                        baza.Kontrahenci.Add(kontrahent);
                        baza.SaveChanges();
                        rtxKomunikatRejestracji.Text = "utworzono nowe konto dla " + typ + "a " + txtUzytkownik.Text +
                            "Aby uzupełnić pozostałe dane wróć do strony logowania i zaloguj się na to konto";

                        mtxHaslo.Text = "";
                        mtxPowtorzHaslo.Text = "";
                        txtUzytkownik.Text = "";

                    }


                    catch (DataException problem)
                    {

                        rtxKomunikatRejestracji.Text = "Takie konto już istnieje w serwisie. Zrestartuj aplikację i wprowadź inne dane";
                        problem.GetBaseException();
                        problem.InnerException.Data.Clear();
                        problem.Data.Clear();

                        System.Data.SqlClient.SqlConnection.ClearAllPools();
                        mtxHaslo.Text = "";
                        mtxPowtorzHaslo.Text = "";
                        txtUzytkownik.Text = "";
                        // mtxHasloPowtorz.Show();
                        mtxHaslo.Show();
                        //lbLogin.Show();

                    }
                    catch (Exception ex)
                    {
                        rtxKomunikatRejestracji.Text = ex.ToString();
                        ex.Data.Clear();

                        mtxHaslo.Text = "";
                        mtxPowtorzHaslo.Text = "";
                        txtUzytkownik.Text = "";
                        // mtxHasloPowtorz.Show();
                        mtxHaslo.Show();
                        //lbLogin.Show();

                    }
                }

            }

        }

        private void btnRejestracjaKlienta_Click(object sender, EventArgs e)
        {
            rejestracja_kontrahenta("klient");
        }

        private void btnRejestracjaDealera_Click(object sender, EventArgs e)
        {
            rejestracja_kontrahenta("dealer");
        }

        private void btnZamknij_Click(object sender, EventArgs e)
        {
            Close();
        }
    }

}
