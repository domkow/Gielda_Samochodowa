﻿namespace Gielda_Samochodowa
{
    partial class FormDaneKontrahenta
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbUprawnienia = new System.Windows.Forms.Label();
            this.txtUprawnienia = new System.Windows.Forms.TextBox();
            this.lbKhId = new System.Windows.Forms.Label();
            this.btnPoprawMiasto = new System.Windows.Forms.Button();
            this.btnPoprawSkype = new System.Windows.Forms.Button();
            this.btnPoprawFirma = new System.Windows.Forms.Button();
            this.btnPoprawImie = new System.Windows.Forms.Button();
            this.btnPoprawEmail = new System.Windows.Forms.Button();
            this.btnPoprawKod = new System.Windows.Forms.Button();
            this.btnPoprawWWW = new System.Windows.Forms.Button();
            this.btnPoprawAdres = new System.Windows.Forms.Button();
            this.btnPoprawTelefon = new System.Windows.Forms.Button();
            this.btnPoprawNazwisko = new System.Windows.Forms.Button();
            this.numPriorityNazwisko = new System.Windows.Forms.NumericUpDown();
            this.numPriorityImie = new System.Windows.Forms.NumericUpDown();
            this.numPriorityFirma = new System.Windows.Forms.NumericUpDown();
            this.numPrioritySkype = new System.Windows.Forms.NumericUpDown();
            this.numPriorityMiasto = new System.Windows.Forms.NumericUpDown();
            this.numPriorityKod = new System.Windows.Forms.NumericUpDown();
            this.numPriorityEmail = new System.Windows.Forms.NumericUpDown();
            this.numPriorityWWW = new System.Windows.Forms.NumericUpDown();
            this.numPriorityTelefon = new System.Windows.Forms.NumericUpDown();
            this.numPriorityAdres = new System.Windows.Forms.NumericUpDown();
            this.rtxKomunikatDane = new System.Windows.Forms.RichTextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtId = new System.Windows.Forms.TextBox();
            this.btnZamknijDaneKh = new System.Windows.Forms.Button();
            this.btnPokazDaneKh = new System.Windows.Forms.Button();
            this.btnWyczyscDaneKh = new System.Windows.Forms.Button();
            this.btnZapiszDaneKh = new System.Windows.Forms.Button();
            this.lbWWW = new System.Windows.Forms.Label();
            this.txtWWW = new System.Windows.Forms.TextBox();
            this.lbSkype = new System.Windows.Forms.Label();
            this.txtSkype = new System.Windows.Forms.TextBox();
            this.lbMiasto = new System.Windows.Forms.Label();
            this.txtMiasto = new System.Windows.Forms.TextBox();
            this.lbKod = new System.Windows.Forms.Label();
            this.txtKod = new System.Windows.Forms.TextBox();
            this.lbFirma = new System.Windows.Forms.Label();
            this.txtFirma = new System.Windows.Forms.TextBox();
            this.lbImie = new System.Windows.Forms.Label();
            this.txtImie = new System.Windows.Forms.TextBox();
            this.lbNazwisko = new System.Windows.Forms.Label();
            this.txtNazwa = new System.Windows.Forms.TextBox();
            this.lbEmail = new System.Windows.Forms.Label();
            this.txtEmail = new System.Windows.Forms.TextBox();
            this.lbAdres = new System.Windows.Forms.Label();
            this.txtAdres = new System.Windows.Forms.TextBox();
            this.lbTelefon = new System.Windows.Forms.Label();
            this.txtTelefon = new System.Windows.Forms.TextBox();
            this.txtAdministracja = new System.Windows.Forms.TextBox();
            this.lbAdministracja = new System.Windows.Forms.Label();
            this.lbLogin = new System.Windows.Forms.Label();
            this.txtLogin = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.numPriorityNazwisko)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numPriorityImie)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numPriorityFirma)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numPrioritySkype)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numPriorityMiasto)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numPriorityKod)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numPriorityEmail)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numPriorityWWW)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numPriorityTelefon)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numPriorityAdres)).BeginInit();
            this.SuspendLayout();
            // 
            // lbUprawnienia
            // 
            this.lbUprawnienia.AccessibleName = "lbUprawnienia";
            this.lbUprawnienia.AutoSize = true;
            this.lbUprawnienia.Location = new System.Drawing.Point(510, 8);
            this.lbUprawnienia.Name = "lbUprawnienia";
            this.lbUprawnienia.Size = new System.Drawing.Size(84, 17);
            this.lbUprawnienia.TabIndex = 193;
            this.lbUprawnienia.Text = "uprawnienia";
            // 
            // txtUprawnienia
            // 
            this.txtUprawnienia.AcceptsReturn = true;
            this.txtUprawnienia.AccessibleDescription = "txtUprawnienia";
            this.txtUprawnienia.Location = new System.Drawing.Point(513, 28);
            this.txtUprawnienia.Name = "txtUprawnienia";
            this.txtUprawnienia.Size = new System.Drawing.Size(100, 22);
            this.txtUprawnienia.TabIndex = 192;
            // 
            // lbKhId
            // 
            this.lbKhId.AccessibleName = "lbKhId";
            this.lbKhId.AutoSize = true;
            this.lbKhId.Location = new System.Drawing.Point(455, 8);
            this.lbKhId.Name = "lbKhId";
            this.lbKhId.Size = new System.Drawing.Size(38, 17);
            this.lbKhId.TabIndex = 191;
            this.lbKhId.Text = "id kh";
            // 
            // btnPoprawMiasto
            // 
            this.btnPoprawMiasto.AccessibleName = "btnPoprawMiasto";
            this.btnPoprawMiasto.BackColor = System.Drawing.Color.DarkTurquoise;
            this.btnPoprawMiasto.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnPoprawMiasto.Location = new System.Drawing.Point(841, 256);
            this.btnPoprawMiasto.Name = "btnPoprawMiasto";
            this.btnPoprawMiasto.Size = new System.Drawing.Size(169, 23);
            this.btnPoprawMiasto.TabIndex = 190;
            this.btnPoprawMiasto.Text = "popraw";
            this.btnPoprawMiasto.UseVisualStyleBackColor = false;
            this.btnPoprawMiasto.Click += new System.EventHandler(this.btnPoprawMiasto_Click);
            // 
            // btnPoprawSkype
            // 
            this.btnPoprawSkype.AccessibleName = "btnPoprawSkype";
            this.btnPoprawSkype.BackColor = System.Drawing.Color.DarkTurquoise;
            this.btnPoprawSkype.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnPoprawSkype.Location = new System.Drawing.Point(488, 429);
            this.btnPoprawSkype.Name = "btnPoprawSkype";
            this.btnPoprawSkype.Size = new System.Drawing.Size(169, 23);
            this.btnPoprawSkype.TabIndex = 189;
            this.btnPoprawSkype.Text = "popraw";
            this.btnPoprawSkype.UseVisualStyleBackColor = false;
            this.btnPoprawSkype.Click += new System.EventHandler(this.btnPoprawSkype_Click);
            // 
            // btnPoprawFirma
            // 
            this.btnPoprawFirma.AccessibleName = "btnPoprawFirma";
            this.btnPoprawFirma.BackColor = System.Drawing.Color.DarkTurquoise;
            this.btnPoprawFirma.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnPoprawFirma.Location = new System.Drawing.Point(485, 256);
            this.btnPoprawFirma.Name = "btnPoprawFirma";
            this.btnPoprawFirma.Size = new System.Drawing.Size(169, 23);
            this.btnPoprawFirma.TabIndex = 188;
            this.btnPoprawFirma.Text = "popraw";
            this.btnPoprawFirma.UseVisualStyleBackColor = false;
            this.btnPoprawFirma.Click += new System.EventHandler(this.btnPoprawFirma_Click);
            // 
            // btnPoprawImie
            // 
            this.btnPoprawImie.AccessibleName = "btnPoprawImie";
            this.btnPoprawImie.BackColor = System.Drawing.Color.DarkTurquoise;
            this.btnPoprawImie.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnPoprawImie.Location = new System.Drawing.Point(488, 163);
            this.btnPoprawImie.Name = "btnPoprawImie";
            this.btnPoprawImie.Size = new System.Drawing.Size(169, 23);
            this.btnPoprawImie.TabIndex = 187;
            this.btnPoprawImie.Text = "popraw";
            this.btnPoprawImie.UseVisualStyleBackColor = false;
            this.btnPoprawImie.Click += new System.EventHandler(this.btnPoprawImie_Click);
            // 
            // btnPoprawEmail
            // 
            this.btnPoprawEmail.AccessibleName = "btnPoprawEmail";
            this.btnPoprawEmail.BackColor = System.Drawing.Color.DarkTurquoise;
            this.btnPoprawEmail.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnPoprawEmail.Location = new System.Drawing.Point(125, 256);
            this.btnPoprawEmail.Name = "btnPoprawEmail";
            this.btnPoprawEmail.Size = new System.Drawing.Size(169, 23);
            this.btnPoprawEmail.TabIndex = 186;
            this.btnPoprawEmail.Text = "popraw";
            this.btnPoprawEmail.UseVisualStyleBackColor = false;
            this.btnPoprawEmail.Click += new System.EventHandler(this.btnPoprawEmail_Click);
            // 
            // btnPoprawKod
            // 
            this.btnPoprawKod.AccessibleName = "btnPoprawKod";
            this.btnPoprawKod.BackColor = System.Drawing.Color.DarkTurquoise;
            this.btnPoprawKod.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnPoprawKod.Location = new System.Drawing.Point(488, 348);
            this.btnPoprawKod.Name = "btnPoprawKod";
            this.btnPoprawKod.Size = new System.Drawing.Size(169, 23);
            this.btnPoprawKod.TabIndex = 185;
            this.btnPoprawKod.Text = "popraw";
            this.btnPoprawKod.UseVisualStyleBackColor = false;
            this.btnPoprawKod.Click += new System.EventHandler(this.btnPoprawKod_Click);
            // 
            // btnPoprawWWW
            // 
            this.btnPoprawWWW.AccessibleName = "btnPoprawWWW";
            this.btnPoprawWWW.BackColor = System.Drawing.Color.DarkTurquoise;
            this.btnPoprawWWW.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnPoprawWWW.Location = new System.Drawing.Point(125, 429);
            this.btnPoprawWWW.Name = "btnPoprawWWW";
            this.btnPoprawWWW.Size = new System.Drawing.Size(169, 23);
            this.btnPoprawWWW.TabIndex = 184;
            this.btnPoprawWWW.Text = "popraw";
            this.btnPoprawWWW.UseVisualStyleBackColor = false;
            this.btnPoprawWWW.Click += new System.EventHandler(this.btnPoprawWWW_Click);
            // 
            // btnPoprawAdres
            // 
            this.btnPoprawAdres.AccessibleName = "btnPoprawAdres";
            this.btnPoprawAdres.BackColor = System.Drawing.Color.DarkTurquoise;
            this.btnPoprawAdres.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnPoprawAdres.Location = new System.Drawing.Point(122, 348);
            this.btnPoprawAdres.Name = "btnPoprawAdres";
            this.btnPoprawAdres.Size = new System.Drawing.Size(169, 23);
            this.btnPoprawAdres.TabIndex = 183;
            this.btnPoprawAdres.Text = "popraw";
            this.btnPoprawAdres.UseVisualStyleBackColor = false;
            this.btnPoprawAdres.Click += new System.EventHandler(this.btnPoprawAdres_Click);
            // 
            // btnPoprawTelefon
            // 
            this.btnPoprawTelefon.AccessibleName = "btnPoprawTelefon";
            this.btnPoprawTelefon.BackColor = System.Drawing.Color.DarkTurquoise;
            this.btnPoprawTelefon.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnPoprawTelefon.Location = new System.Drawing.Point(844, 163);
            this.btnPoprawTelefon.Name = "btnPoprawTelefon";
            this.btnPoprawTelefon.Size = new System.Drawing.Size(169, 23);
            this.btnPoprawTelefon.TabIndex = 182;
            this.btnPoprawTelefon.Text = "popraw";
            this.btnPoprawTelefon.UseVisualStyleBackColor = false;
            this.btnPoprawTelefon.Click += new System.EventHandler(this.btnPoprawTelefon_Click);
            // 
            // btnPoprawNazwisko
            // 
            this.btnPoprawNazwisko.AccessibleName = "btnPoprawNazwisko";
            this.btnPoprawNazwisko.BackColor = System.Drawing.Color.DarkTurquoise;
            this.btnPoprawNazwisko.FlatAppearance.BorderColor = System.Drawing.Color.Teal;
            this.btnPoprawNazwisko.FlatAppearance.BorderSize = 2;
            this.btnPoprawNazwisko.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnPoprawNazwisko.Location = new System.Drawing.Point(125, 163);
            this.btnPoprawNazwisko.Name = "btnPoprawNazwisko";
            this.btnPoprawNazwisko.Size = new System.Drawing.Size(169, 23);
            this.btnPoprawNazwisko.TabIndex = 181;
            this.btnPoprawNazwisko.Text = "popraw";
            this.btnPoprawNazwisko.UseVisualStyleBackColor = false;
            this.btnPoprawNazwisko.Click += new System.EventHandler(this.btnPoprawNazwisko_Click);
            // 
            // numPriorityNazwisko
            // 
            this.numPriorityNazwisko.AccessibleName = "numPriorityNazwisko";
            this.numPriorityNazwisko.Location = new System.Drawing.Point(24, 163);
            this.numPriorityNazwisko.Name = "numPriorityNazwisko";
            this.numPriorityNazwisko.Size = new System.Drawing.Size(68, 22);
            this.numPriorityNazwisko.TabIndex = 180;
            this.numPriorityNazwisko.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // numPriorityImie
            // 
            this.numPriorityImie.AccessibleName = "numPriorityImie";
            this.numPriorityImie.Location = new System.Drawing.Point(387, 163);
            this.numPriorityImie.Name = "numPriorityImie";
            this.numPriorityImie.Size = new System.Drawing.Size(68, 22);
            this.numPriorityImie.TabIndex = 179;
            this.numPriorityImie.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // numPriorityFirma
            // 
            this.numPriorityFirma.AccessibleName = "numPriorityFirma";
            this.numPriorityFirma.Location = new System.Drawing.Point(387, 255);
            this.numPriorityFirma.Name = "numPriorityFirma";
            this.numPriorityFirma.Size = new System.Drawing.Size(68, 22);
            this.numPriorityFirma.TabIndex = 178;
            this.numPriorityFirma.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // numPrioritySkype
            // 
            this.numPrioritySkype.AccessibleName = "numPrioritySkype";
            this.numPrioritySkype.Location = new System.Drawing.Point(387, 430);
            this.numPrioritySkype.Name = "numPrioritySkype";
            this.numPrioritySkype.Size = new System.Drawing.Size(68, 22);
            this.numPrioritySkype.TabIndex = 177;
            this.numPrioritySkype.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // numPriorityMiasto
            // 
            this.numPriorityMiasto.AccessibleName = "numPriorityMiasto";
            this.numPriorityMiasto.Location = new System.Drawing.Point(743, 255);
            this.numPriorityMiasto.Name = "numPriorityMiasto";
            this.numPriorityMiasto.Size = new System.Drawing.Size(68, 22);
            this.numPriorityMiasto.TabIndex = 176;
            this.numPriorityMiasto.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // numPriorityKod
            // 
            this.numPriorityKod.AccessibleName = "numPriorityKod";
            this.numPriorityKod.Location = new System.Drawing.Point(387, 348);
            this.numPriorityKod.Name = "numPriorityKod";
            this.numPriorityKod.Size = new System.Drawing.Size(68, 22);
            this.numPriorityKod.TabIndex = 175;
            this.numPriorityKod.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // numPriorityEmail
            // 
            this.numPriorityEmail.AccessibleName = "numPriorityEmail";
            this.numPriorityEmail.Location = new System.Drawing.Point(24, 255);
            this.numPriorityEmail.Name = "numPriorityEmail";
            this.numPriorityEmail.Size = new System.Drawing.Size(68, 22);
            this.numPriorityEmail.TabIndex = 174;
            this.numPriorityEmail.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // numPriorityWWW
            // 
            this.numPriorityWWW.AccessibleName = "numPriorityWWW";
            this.numPriorityWWW.Location = new System.Drawing.Point(24, 432);
            this.numPriorityWWW.Name = "numPriorityWWW";
            this.numPriorityWWW.Size = new System.Drawing.Size(68, 22);
            this.numPriorityWWW.TabIndex = 173;
            this.numPriorityWWW.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // numPriorityTelefon
            // 
            this.numPriorityTelefon.AccessibleName = "numPriorityTelefon";
            this.numPriorityTelefon.Location = new System.Drawing.Point(740, 163);
            this.numPriorityTelefon.Name = "numPriorityTelefon";
            this.numPriorityTelefon.Size = new System.Drawing.Size(68, 22);
            this.numPriorityTelefon.TabIndex = 172;
            this.numPriorityTelefon.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // numPriorityAdres
            // 
            this.numPriorityAdres.AccessibleName = "numPriorityAdres";
            this.numPriorityAdres.Location = new System.Drawing.Point(24, 348);
            this.numPriorityAdres.Name = "numPriorityAdres";
            this.numPriorityAdres.Size = new System.Drawing.Size(68, 22);
            this.numPriorityAdres.TabIndex = 171;
            this.numPriorityAdres.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // rtxKomunikatDane
            // 
            this.rtxKomunikatDane.AccessibleName = "rtxKomunikatDane";
            this.rtxKomunikatDane.Location = new System.Drawing.Point(740, 33);
            this.rtxKomunikatDane.Name = "rtxKomunikatDane";
            this.rtxKomunikatDane.Size = new System.Drawing.Size(273, 47);
            this.rtxKomunikatDane.TabIndex = 170;
            this.rtxKomunikatDane.Text = "";
            // 
            // label1
            // 
            this.label1.AccessibleName = "lbNazwisko";
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(24, 432);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(0, 17);
            this.label1.TabIndex = 169;
            // 
            // txtId
            // 
            this.txtId.AcceptsReturn = true;
            this.txtId.AccessibleDescription = "txtId";
            this.txtId.Location = new System.Drawing.Point(458, 28);
            this.txtId.Name = "txtId";
            this.txtId.Size = new System.Drawing.Size(49, 22);
            this.txtId.TabIndex = 168;
            this.txtId.TextChanged += new System.EventHandler(this.txtId_TextChanged);
            // 
            // btnZamknijDaneKh
            // 
            this.btnZamknijDaneKh.AccessibleName = "btnZamknijDaneKh";
            this.btnZamknijDaneKh.BackColor = System.Drawing.Color.DarkTurquoise;
            this.btnZamknijDaneKh.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnZamknijDaneKh.Location = new System.Drawing.Point(883, 429);
            this.btnZamknijDaneKh.Name = "btnZamknijDaneKh";
            this.btnZamknijDaneKh.Size = new System.Drawing.Size(130, 23);
            this.btnZamknijDaneKh.TabIndex = 167;
            this.btnZamknijDaneKh.Text = "zamknij";
            this.btnZamknijDaneKh.UseVisualStyleBackColor = false;
            this.btnZamknijDaneKh.Click += new System.EventHandler(this.btnZamknijDaneKh_Click_1);
            // 
            // btnPokazDaneKh
            // 
            this.btnPokazDaneKh.AccessibleName = "btnPokazDaneKh";
            this.btnPokazDaneKh.BackColor = System.Drawing.Color.DarkTurquoise;
            this.btnPokazDaneKh.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnPokazDaneKh.Location = new System.Drawing.Point(746, 348);
            this.btnPokazDaneKh.Name = "btnPokazDaneKh";
            this.btnPokazDaneKh.Size = new System.Drawing.Size(130, 23);
            this.btnPokazDaneKh.TabIndex = 166;
            this.btnPokazDaneKh.Text = "pokaż";
            this.btnPokazDaneKh.UseVisualStyleBackColor = false;
            this.btnPokazDaneKh.Click += new System.EventHandler(this.btnPokazDaneKh_Click);
            // 
            // btnWyczyscDaneKh
            // 
            this.btnWyczyscDaneKh.AccessibleName = "btnWyczyscDaneKh";
            this.btnWyczyscDaneKh.BackColor = System.Drawing.Color.DarkTurquoise;
            this.btnWyczyscDaneKh.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnWyczyscDaneKh.Location = new System.Drawing.Point(883, 348);
            this.btnWyczyscDaneKh.Name = "btnWyczyscDaneKh";
            this.btnWyczyscDaneKh.Size = new System.Drawing.Size(130, 23);
            this.btnWyczyscDaneKh.TabIndex = 165;
            this.btnWyczyscDaneKh.Text = "wyczyść";
            this.btnWyczyscDaneKh.UseVisualStyleBackColor = false;
            this.btnWyczyscDaneKh.Click += new System.EventHandler(this.btnWyczyscDaneKh_Click);
            // 
            // btnZapiszDaneKh
            // 
            this.btnZapiszDaneKh.AccessibleName = "btnZapiszDaneKh";
            this.btnZapiszDaneKh.BackColor = System.Drawing.Color.DarkTurquoise;
            this.btnZapiszDaneKh.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnZapiszDaneKh.Location = new System.Drawing.Point(746, 429);
            this.btnZapiszDaneKh.Name = "btnZapiszDaneKh";
            this.btnZapiszDaneKh.Size = new System.Drawing.Size(130, 23);
            this.btnZapiszDaneKh.TabIndex = 164;
            this.btnZapiszDaneKh.Text = "zapisz";
            this.btnZapiszDaneKh.UseVisualStyleBackColor = false;
            this.btnZapiszDaneKh.Click += new System.EventHandler(this.btnZapiszDaneKh_Click_1);
            // 
            // lbWWW
            // 
            this.lbWWW.AccessibleName = "lbWWW";
            this.lbWWW.AutoSize = true;
            this.lbWWW.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.lbWWW.Location = new System.Drawing.Point(24, 382);
            this.lbWWW.Name = "lbWWW";
            this.lbWWW.Size = new System.Drawing.Size(79, 17);
            this.lbWWW.TabIndex = 163;
            this.lbWWW.Text = "strona www";
            // 
            // txtWWW
            // 
            this.txtWWW.AccessibleDescription = "txtWWW";
            this.txtWWW.Location = new System.Drawing.Point(24, 402);
            this.txtWWW.Name = "txtWWW";
            this.txtWWW.Size = new System.Drawing.Size(270, 22);
            this.txtWWW.TabIndex = 162;
            this.txtWWW.Tag = "7";
            // 
            // lbSkype
            // 
            this.lbSkype.AccessibleName = "lbSkype";
            this.lbSkype.AutoSize = true;
            this.lbSkype.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.lbSkype.Location = new System.Drawing.Point(387, 382);
            this.lbSkype.Name = "lbSkype";
            this.lbSkype.Size = new System.Drawing.Size(45, 17);
            this.lbSkype.TabIndex = 161;
            this.lbSkype.Text = "skype";
            // 
            // txtSkype
            // 
            this.txtSkype.AccessibleDescription = "txtSkype";
            this.txtSkype.Location = new System.Drawing.Point(387, 402);
            this.txtSkype.Name = "txtSkype";
            this.txtSkype.Size = new System.Drawing.Size(270, 22);
            this.txtSkype.TabIndex = 160;
            this.txtSkype.Tag = "6";
            // 
            // lbMiasto
            // 
            this.lbMiasto.AccessibleName = "lbMiasto";
            this.lbMiasto.AutoSize = true;
            this.lbMiasto.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.lbMiasto.Location = new System.Drawing.Point(743, 207);
            this.lbMiasto.Name = "lbMiasto";
            this.lbMiasto.Size = new System.Drawing.Size(49, 17);
            this.lbMiasto.TabIndex = 159;
            this.lbMiasto.Text = "miasto";
            // 
            // txtMiasto
            // 
            this.txtMiasto.AccessibleDescription = "txtMiasto";
            this.txtMiasto.Location = new System.Drawing.Point(743, 228);
            this.txtMiasto.Name = "txtMiasto";
            this.txtMiasto.Size = new System.Drawing.Size(270, 22);
            this.txtMiasto.TabIndex = 158;
            this.txtMiasto.Tag = "2";
            // 
            // lbKod
            // 
            this.lbKod.AccessibleName = "lbKod";
            this.lbKod.AutoSize = true;
            this.lbKod.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.lbKod.Location = new System.Drawing.Point(387, 300);
            this.lbKod.Name = "lbKod";
            this.lbKod.Size = new System.Drawing.Size(93, 17);
            this.lbKod.TabIndex = 157;
            this.lbKod.Text = "kod pocztowy";
            // 
            // txtKod
            // 
            this.txtKod.AccessibleDescription = "txtKod";
            this.txtKod.Location = new System.Drawing.Point(387, 320);
            this.txtKod.Name = "txtKod";
            this.txtKod.Size = new System.Drawing.Size(270, 22);
            this.txtKod.TabIndex = 156;
            this.txtKod.Tag = "3";
            // 
            // lbFirma
            // 
            this.lbFirma.AccessibleName = "lbFirma";
            this.lbFirma.AutoSize = true;
            this.lbFirma.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.lbFirma.Location = new System.Drawing.Point(384, 207);
            this.lbFirma.Name = "lbFirma";
            this.lbFirma.Size = new System.Drawing.Size(39, 17);
            this.lbFirma.TabIndex = 155;
            this.lbFirma.Text = "firma";
            // 
            // txtFirma
            // 
            this.txtFirma.AccessibleDescription = "txtFirma";
            this.txtFirma.Location = new System.Drawing.Point(384, 228);
            this.txtFirma.Name = "txtFirma";
            this.txtFirma.Size = new System.Drawing.Size(270, 22);
            this.txtFirma.TabIndex = 154;
            this.txtFirma.Tag = "10";
            // 
            // lbImie
            // 
            this.lbImie.AutoSize = true;
            this.lbImie.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.lbImie.Location = new System.Drawing.Point(387, 115);
            this.lbImie.Name = "lbImie";
            this.lbImie.Size = new System.Drawing.Size(33, 17);
            this.lbImie.TabIndex = 153;
            this.lbImie.Text = "imię";
            // 
            // txtImie
            // 
            this.txtImie.AccessibleDescription = "txtImie";
            this.txtImie.Location = new System.Drawing.Point(387, 135);
            this.txtImie.Name = "txtImie";
            this.txtImie.Size = new System.Drawing.Size(270, 22);
            this.txtImie.TabIndex = 152;
            this.txtImie.Tag = "8";
            // 
            // lbNazwisko
            // 
            this.lbNazwisko.AccessibleName = "lbNazwisko";
            this.lbNazwisko.AutoSize = true;
            this.lbNazwisko.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.lbNazwisko.Location = new System.Drawing.Point(24, 115);
            this.lbNazwisko.Name = "lbNazwisko";
            this.lbNazwisko.Size = new System.Drawing.Size(65, 17);
            this.lbNazwisko.TabIndex = 151;
            this.lbNazwisko.Text = "nazwisko";
            // 
            // txtNazwa
            // 
            this.txtNazwa.AccessibleDescription = "txtNazwa";
            this.txtNazwa.Location = new System.Drawing.Point(24, 135);
            this.txtNazwa.Name = "txtNazwa";
            this.txtNazwa.Size = new System.Drawing.Size(270, 22);
            this.txtNazwa.TabIndex = 150;
            this.txtNazwa.Tag = "9";
            // 
            // lbEmail
            // 
            this.lbEmail.AutoSize = true;
            this.lbEmail.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.lbEmail.Location = new System.Drawing.Point(24, 207);
            this.lbEmail.Name = "lbEmail";
            this.lbEmail.Size = new System.Drawing.Size(41, 17);
            this.lbEmail.TabIndex = 149;
            this.lbEmail.Text = "email";
            // 
            // txtEmail
            // 
            this.txtEmail.AccessibleDescription = "txtEmail";
            this.txtEmail.Location = new System.Drawing.Point(24, 228);
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Size = new System.Drawing.Size(270, 22);
            this.txtEmail.TabIndex = 148;
            this.txtEmail.Tag = "5";
            // 
            // lbAdres
            // 
            this.lbAdres.AutoSize = true;
            this.lbAdres.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.lbAdres.Location = new System.Drawing.Point(24, 300);
            this.lbAdres.Name = "lbAdres";
            this.lbAdres.Size = new System.Drawing.Size(44, 17);
            this.lbAdres.TabIndex = 147;
            this.lbAdres.Text = "adres";
            // 
            // txtAdres
            // 
            this.txtAdres.AccessibleDescription = "txtAdres";
            this.txtAdres.Location = new System.Drawing.Point(24, 320);
            this.txtAdres.Name = "txtAdres";
            this.txtAdres.Size = new System.Drawing.Size(270, 22);
            this.txtAdres.TabIndex = 146;
            this.txtAdres.Tag = "1";
            // 
            // lbTelefon
            // 
            this.lbTelefon.AutoSize = true;
            this.lbTelefon.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.lbTelefon.Location = new System.Drawing.Point(740, 115);
            this.lbTelefon.Name = "lbTelefon";
            this.lbTelefon.Size = new System.Drawing.Size(51, 17);
            this.lbTelefon.TabIndex = 145;
            this.lbTelefon.Text = "telefon";
            // 
            // txtTelefon
            // 
            this.txtTelefon.AccessibleDescription = "txtTelefon";
            this.txtTelefon.Location = new System.Drawing.Point(740, 135);
            this.txtTelefon.Name = "txtTelefon";
            this.txtTelefon.Size = new System.Drawing.Size(270, 22);
            this.txtTelefon.TabIndex = 144;
            this.txtTelefon.Tag = "4";
            // 
            // txtAdministracja
            // 
            this.txtAdministracja.AcceptsReturn = true;
            this.txtAdministracja.AccessibleDescription = "txtAdministracja";
            this.txtAdministracja.Location = new System.Drawing.Point(315, 28);
            this.txtAdministracja.Name = "txtAdministracja";
            this.txtAdministracja.Size = new System.Drawing.Size(128, 22);
            this.txtAdministracja.TabIndex = 194;
            // 
            // lbAdministracja
            // 
            this.lbAdministracja.AccessibleName = "lbAdministracja";
            this.lbAdministracja.AutoSize = true;
            this.lbAdministracja.Location = new System.Drawing.Point(312, 9);
            this.lbAdministracja.Name = "lbAdministracja";
            this.lbAdministracja.Size = new System.Drawing.Size(91, 17);
            this.lbAdministracja.TabIndex = 195;
            this.lbAdministracja.Text = "administracja";
            // 
            // lbLogin
            // 
            this.lbLogin.AccessibleName = "lbLogin";
            this.lbLogin.AutoSize = true;
            this.lbLogin.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.lbLogin.Location = new System.Drawing.Point(21, 9);
            this.lbLogin.Name = "lbLogin";
            this.lbLogin.Size = new System.Drawing.Size(128, 17);
            this.lbLogin.TabIndex = 197;
            this.lbLogin.Text = "nazwa użytkownika";
            // 
            // txtLogin
            // 
            this.txtLogin.AccessibleDescription = "txtLogin";
            this.txtLogin.Location = new System.Drawing.Point(24, 33);
            this.txtLogin.Name = "txtLogin";
            this.txtLogin.Size = new System.Drawing.Size(270, 22);
            this.txtLogin.TabIndex = 196;
            this.txtLogin.Tag = "8";
            // 
            // FormDaneKontrahenta
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.PowderBlue;
            this.ClientSize = new System.Drawing.Size(1072, 553);
            this.Controls.Add(this.lbLogin);
            this.Controls.Add(this.txtLogin);
            this.Controls.Add(this.lbAdministracja);
            this.Controls.Add(this.txtAdministracja);
            this.Controls.Add(this.lbUprawnienia);
            this.Controls.Add(this.txtUprawnienia);
            this.Controls.Add(this.lbKhId);
            this.Controls.Add(this.btnPoprawMiasto);
            this.Controls.Add(this.btnPoprawSkype);
            this.Controls.Add(this.btnPoprawFirma);
            this.Controls.Add(this.btnPoprawImie);
            this.Controls.Add(this.btnPoprawEmail);
            this.Controls.Add(this.btnPoprawKod);
            this.Controls.Add(this.btnPoprawWWW);
            this.Controls.Add(this.btnPoprawAdres);
            this.Controls.Add(this.btnPoprawTelefon);
            this.Controls.Add(this.btnPoprawNazwisko);
            this.Controls.Add(this.numPriorityNazwisko);
            this.Controls.Add(this.numPriorityImie);
            this.Controls.Add(this.numPriorityFirma);
            this.Controls.Add(this.numPrioritySkype);
            this.Controls.Add(this.numPriorityMiasto);
            this.Controls.Add(this.numPriorityKod);
            this.Controls.Add(this.numPriorityEmail);
            this.Controls.Add(this.numPriorityWWW);
            this.Controls.Add(this.numPriorityTelefon);
            this.Controls.Add(this.numPriorityAdres);
            this.Controls.Add(this.rtxKomunikatDane);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtId);
            this.Controls.Add(this.btnZamknijDaneKh);
            this.Controls.Add(this.btnPokazDaneKh);
            this.Controls.Add(this.btnWyczyscDaneKh);
            this.Controls.Add(this.btnZapiszDaneKh);
            this.Controls.Add(this.lbWWW);
            this.Controls.Add(this.txtWWW);
            this.Controls.Add(this.lbSkype);
            this.Controls.Add(this.txtSkype);
            this.Controls.Add(this.lbMiasto);
            this.Controls.Add(this.txtMiasto);
            this.Controls.Add(this.lbKod);
            this.Controls.Add(this.txtKod);
            this.Controls.Add(this.lbFirma);
            this.Controls.Add(this.txtFirma);
            this.Controls.Add(this.lbImie);
            this.Controls.Add(this.txtImie);
            this.Controls.Add(this.lbNazwisko);
            this.Controls.Add(this.txtNazwa);
            this.Controls.Add(this.lbEmail);
            this.Controls.Add(this.txtEmail);
            this.Controls.Add(this.lbAdres);
            this.Controls.Add(this.txtAdres);
            this.Controls.Add(this.lbTelefon);
            this.Controls.Add(this.txtTelefon);
            this.Name = "FormDaneKontrahenta";
            this.Text = "FormDaneKontrahenta";
            this.Load += new System.EventHandler(this.FormDaneKontrahenta_Load);
            ((System.ComponentModel.ISupportInitialize)(this.numPriorityNazwisko)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numPriorityImie)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numPriorityFirma)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numPrioritySkype)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numPriorityMiasto)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numPriorityKod)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numPriorityEmail)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numPriorityWWW)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numPriorityTelefon)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numPriorityAdres)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbUprawnienia;
        private System.Windows.Forms.TextBox txtUprawnienia;
        private System.Windows.Forms.Label lbKhId;
        private System.Windows.Forms.Button btnPoprawMiasto;
        private System.Windows.Forms.Button btnPoprawSkype;
        private System.Windows.Forms.Button btnPoprawFirma;
        private System.Windows.Forms.Button btnPoprawImie;
        private System.Windows.Forms.Button btnPoprawEmail;
        private System.Windows.Forms.Button btnPoprawKod;
        private System.Windows.Forms.Button btnPoprawWWW;
        private System.Windows.Forms.Button btnPoprawAdres;
        private System.Windows.Forms.Button btnPoprawTelefon;
        private System.Windows.Forms.Button btnPoprawNazwisko;
        private System.Windows.Forms.NumericUpDown numPriorityNazwisko;
        private System.Windows.Forms.NumericUpDown numPriorityImie;
        private System.Windows.Forms.NumericUpDown numPriorityFirma;
        private System.Windows.Forms.NumericUpDown numPrioritySkype;
        private System.Windows.Forms.NumericUpDown numPriorityMiasto;
        private System.Windows.Forms.NumericUpDown numPriorityKod;
        private System.Windows.Forms.NumericUpDown numPriorityEmail;
        private System.Windows.Forms.NumericUpDown numPriorityWWW;
        private System.Windows.Forms.NumericUpDown numPriorityTelefon;
        private System.Windows.Forms.NumericUpDown numPriorityAdres;
        private System.Windows.Forms.RichTextBox rtxKomunikatDane;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtId;
        private System.Windows.Forms.Button btnZamknijDaneKh;
        private System.Windows.Forms.Button btnPokazDaneKh;
        private System.Windows.Forms.Button btnWyczyscDaneKh;
        private System.Windows.Forms.Button btnZapiszDaneKh;
        private System.Windows.Forms.Label lbWWW;
        private System.Windows.Forms.TextBox txtWWW;
        private System.Windows.Forms.Label lbSkype;
        private System.Windows.Forms.TextBox txtSkype;
        private System.Windows.Forms.Label lbMiasto;
        private System.Windows.Forms.TextBox txtMiasto;
        private System.Windows.Forms.Label lbKod;
        private System.Windows.Forms.TextBox txtKod;
        private System.Windows.Forms.Label lbFirma;
        private System.Windows.Forms.TextBox txtFirma;
        private System.Windows.Forms.Label lbImie;
        private System.Windows.Forms.TextBox txtImie;
        private System.Windows.Forms.Label lbNazwisko;
        private System.Windows.Forms.TextBox txtNazwa;
        private System.Windows.Forms.Label lbEmail;
        private System.Windows.Forms.TextBox txtEmail;
        private System.Windows.Forms.Label lbAdres;
        private System.Windows.Forms.TextBox txtAdres;
        private System.Windows.Forms.Label lbTelefon;
        private System.Windows.Forms.TextBox txtTelefon;
        private System.Windows.Forms.TextBox txtAdministracja;
        private System.Windows.Forms.Label lbAdministracja;
        private System.Windows.Forms.Label lbLogin;
        private System.Windows.Forms.TextBox txtLogin;
    }
}