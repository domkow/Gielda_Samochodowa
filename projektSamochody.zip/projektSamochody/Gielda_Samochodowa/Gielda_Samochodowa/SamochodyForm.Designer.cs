﻿namespace Gielda_Samochodowa
{
    partial class SamochodyForm
    {
        /// <summary>
        /// Wymagana zmienna projektanta.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Wyczyść wszystkie używane zasoby.
        /// </summary>
        /// <param name="disposing">prawda, jeżeli zarządzane zasoby powinny zostać zlikwidowane; Fałsz w przeciwnym wypadku.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Kod generowany przez Projektanta formularzy systemu Windows

        /// <summary>
        /// Metoda wymagana do obsługi projektanta — nie należy modyfikować
        /// jej zawartości w edytorze kodu.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label lbLogin;
            System.Windows.Forms.Label lbAdmin;
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.label8 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.txtPrzebiegDo = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtRokDo = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtCena = new System.Windows.Forms.TextBox();
            this.lboxSprzedaz = new System.Windows.Forms.ListBox();
            this.btnListaAut = new System.Windows.Forms.Button();
            this.btnSzukajAuta = new System.Windows.Forms.Button();
            this.btnDodajAuto = new System.Windows.Forms.Button();
            this.btnDaneAuta = new System.Windows.Forms.Button();
            this.txtCenaMin = new System.Windows.Forms.TextBox();
            this.Kontrahenci = new System.Windows.Forms.TabPage();
            this.dgvKontrahenci = new System.Windows.Forms.DataGridView();
            this.txtTelefon = new System.Windows.Forms.TextBox();
            this.lbTelefon = new System.Windows.Forms.Label();
            this.lbSkype = new System.Windows.Forms.Label();
            this.txtSkype = new System.Windows.Forms.TextBox();
            this.lbImie = new System.Windows.Forms.Label();
            this.txtImie = new System.Windows.Forms.TextBox();
            this.lbKod = new System.Windows.Forms.Label();
            this.txtKod = new System.Windows.Forms.TextBox();
            this.lbwww = new System.Windows.Forms.Label();
            this.txtWWW = new System.Windows.Forms.TextBox();
            this.lbEmail = new System.Windows.Forms.Label();
            this.txtEmail = new System.Windows.Forms.TextBox();
            this.lbNazwisko = new System.Windows.Forms.Label();
            this.txtNazwisko = new System.Windows.Forms.TextBox();
            this.lbMiasto = new System.Windows.Forms.Label();
            this.txtMiasto = new System.Windows.Forms.TextBox();
            this.lbFirma = new System.Windows.Forms.Label();
            this.txtFirma = new System.Windows.Forms.TextBox();
            this.btnZnajdzDealera = new System.Windows.Forms.Button();
            this.lboxKontrahenci = new System.Windows.Forms.ListBox();
            this.btnPokazKontrahentow = new System.Windows.Forms.Button();
            this.btnUzupelnijDaneKH = new System.Windows.Forms.Button();
            this.txt_wybrany_kh_dlugosc = new System.Windows.Forms.TextBox();
            this.txt_wybrany_kh_id = new System.Windows.Forms.TextBox();
            this.txt_wybrany_kh = new System.Windows.Forms.TextBox();
            this.Sprzedaz = new System.Windows.Forms.TabPage();
            this.dgvSprzedaz = new System.Windows.Forms.DataGridView();
            this.btnSzczegolySprzedazy = new System.Windows.Forms.Button();
            this.btnPokazSprzedaz = new System.Windows.Forms.Button();
            this.lbKopiujHaslo = new System.Windows.Forms.Label();
            this.lbRejestracja = new System.Windows.Forms.Label();
            this.lbWybranaRejestracja = new System.Windows.Forms.Label();
            this.txtWybranaRejestracja = new System.Windows.Forms.TextBox();
            this.txtZalogowanyNazwa = new System.Windows.Forms.TextBox();
            this.lbZalogowany = new System.Windows.Forms.Label();
            this.rtxKomunikat = new System.Windows.Forms.RichTextBox();
            this.txtRejestracja = new System.Windows.Forms.TextBox();
            this.lbKolor = new System.Windows.Forms.Label();
            this.txtKolor = new System.Windows.Forms.TextBox();
            this.lbPrzebieg = new System.Windows.Forms.Label();
            this.txtPrzebieg = new System.Windows.Forms.TextBox();
            this.txtDlugoscRejestracji = new System.Windows.Forms.TextBox();
            this.lbIdAuta = new System.Windows.Forms.Label();
            this.mtxHasloPowtorz = new System.Windows.Forms.MaskedTextBox();
            this.lbRok = new System.Windows.Forms.Label();
            this.txtRok = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.lbDlugoscRejestracji = new System.Windows.Forms.Label();
            this.txtIdWybranegoAuta = new System.Windows.Forms.TextBox();
            this.txtWlasciciel = new System.Windows.Forms.TextBox();
            this.tcKontrahentTowar = new System.Windows.Forms.TabControl();
            this.Samochody = new System.Windows.Forms.TabPage();
            this.dgvListaAut = new System.Windows.Forms.DataGridView();
            this.id = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.najwyzsza_cena = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.najnizsza_cena = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ostatnia_cena = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lbSilnik = new System.Windows.Forms.Label();
            this.txtSilnik = new System.Windows.Forms.TextBox();
            this.lbMarka = new System.Windows.Forms.Label();
            this.txtMarka = new System.Windows.Forms.TextBox();
            this.lboxSamochody = new System.Windows.Forms.ListBox();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.dgvMojeTransakcje = new System.Windows.Forms.DataGridView();
            this.btnSzczegolyTransakcji = new System.Windows.Forms.Button();
            this.btnPokazMojeTransakcje = new System.Windows.Forms.Button();
            this.lboxMojeTransakcje = new System.Windows.Forms.ListBox();
            this.txtUzytkownik = new System.Windows.Forms.TextBox();
            this.btnWyLogowanie = new System.Windows.Forms.Button();
            this.btnLogowanie = new System.Windows.Forms.Button();
            this.lbHaslo = new System.Windows.Forms.Label();
            this.mtxHaslo = new System.Windows.Forms.MaskedTextBox();
            this.btnZarejestruj = new System.Windows.Forms.Button();
            this.btnZamknij = new System.Windows.Forms.Button();
            this.btnWylogujAdmina = new System.Windows.Forms.Button();
            this.txtAdmin = new System.Windows.Forms.TextBox();
            this.lbAdminHaslo = new System.Windows.Forms.Label();
            this.mtxAdmin = new System.Windows.Forms.MaskedTextBox();
            this.btnZarządzaj = new System.Windows.Forms.Button();
            this.lbWybranyKh = new System.Windows.Forms.Label();
            this.lbWybranyKhId = new System.Windows.Forms.Label();
            this.lbWybranyKhDlugosc = new System.Windows.Forms.Label();
            this.txtZnak = new System.Windows.Forms.TextBox();
            this.lbZnak = new System.Windows.Forms.Label();
            this.txtKomunikat = new System.Windows.Forms.TextBox();
            this.lbNazwa = new System.Windows.Forms.Label();
            this.txtNazwa = new System.Windows.Forms.TextBox();
            this.rejestracjaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.właścicielDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.rokprodukcjiDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.przebiegDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.markaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.silnikDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.kolorDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.listaautBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.idDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nazwaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nazwiskoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.imieDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.firmaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.telefonDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.emailDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.adresDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.kodDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.miastoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.skypeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.wwwDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.rejestrkontrahentowBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.idDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.rejestracjaDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.właścicielobecnyDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.właścicielpoprzedniDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.rokprodukcjiDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.przebiegDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.markaDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.silnikDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.kolorDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cenawywoławczaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cenasprzedażyDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.obecnystatusDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sprzedaneautaBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.ostatniatransakcjaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.idautoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.idkontrahentDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.kontrahentDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.rejestracjaDataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cenaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.markaDataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.silnikDataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.kolorDataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.idaktualnegostatusuDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.obecnystatusDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.kontrahentaktualnegostatusuDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ostatnistatuskontrahentaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.transakcjekontrahenciautaBindingSource2 = new System.Windows.Forms.BindingSource(this.components);
            this.listawszystkichautBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.sprzedaneautaBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.transakcjekontrahenciautaBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.transakcjekontrahenciautaBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            lbLogin = new System.Windows.Forms.Label();
            lbAdmin = new System.Windows.Forms.Label();
            this.Kontrahenci.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvKontrahenci)).BeginInit();
            this.Sprzedaz.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSprzedaz)).BeginInit();
            this.tcKontrahentTowar.SuspendLayout();
            this.Samochody.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvListaAut)).BeginInit();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvMojeTransakcje)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.listaautBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rejestrkontrahentowBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sprzedaneautaBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.transakcjekontrahenciautaBindingSource2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.listawszystkichautBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sprzedaneautaBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.transakcjekontrahenciautaBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.transakcjekontrahenciautaBindingSource1)).BeginInit();
            this.SuspendLayout();
            // 
            // lbLogin
            // 
            lbLogin.AccessibleName = "lbLogin";
            lbLogin.AutoSize = true;
            lbLogin.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F);
            lbLogin.Location = new System.Drawing.Point(1272, 188);
            lbLogin.Margin = new System.Windows.Forms.Padding(0);
            lbLogin.Name = "lbLogin";
            lbLogin.Size = new System.Drawing.Size(128, 17);
            lbLogin.TabIndex = 43;
            lbLogin.Text = "nazwa użytkownika";
            // 
            // lbAdmin
            // 
            lbAdmin.AccessibleName = "lbAdmin";
            lbAdmin.AutoSize = true;
            lbAdmin.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F);
            lbAdmin.Location = new System.Drawing.Point(1258, 355);
            lbAdmin.Margin = new System.Windows.Forms.Padding(0);
            lbAdmin.Name = "lbAdmin";
            lbAdmin.Size = new System.Drawing.Size(142, 17);
            lbAdmin.TabIndex = 47;
            lbAdmin.Text = "nazwa administratora";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(568, 420);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(39, 17);
            this.label8.TabIndex = 47;
            this.label8.Text = "cena";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(735, 375);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(63, 17);
            this.label4.TabIndex = 45;
            this.label4.Text = "przebieg";
            // 
            // txtPrzebiegDo
            // 
            this.txtPrzebiegDo.AccessibleDescription = "txtPrzebiegDo";
            this.txtPrzebiegDo.Location = new System.Drawing.Point(738, 395);
            this.txtPrzebiegDo.Name = "txtPrzebiegDo";
            this.txtPrzebiegDo.Size = new System.Drawing.Size(129, 22);
            this.txtPrzebiegDo.TabIndex = 44;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(735, 329);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(89, 17);
            this.label3.TabIndex = 43;
            this.label3.Text = "rok produkcji";
            // 
            // txtRokDo
            // 
            this.txtRokDo.AccessibleDescription = "txtRokDo";
            this.txtRokDo.AccessibleRole = System.Windows.Forms.AccessibleRole.WhiteSpace;
            this.txtRokDo.Location = new System.Drawing.Point(738, 349);
            this.txtRokDo.Name = "txtRokDo";
            this.txtRokDo.Size = new System.Drawing.Size(129, 22);
            this.txtRokDo.TabIndex = 42;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(745, 419);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(39, 17);
            this.label7.TabIndex = 41;
            this.label7.Text = "cena";
            // 
            // txtCena
            // 
            this.txtCena.AccessibleDescription = "txtCena";
            this.txtCena.Location = new System.Drawing.Point(738, 440);
            this.txtCena.Name = "txtCena";
            this.txtCena.Size = new System.Drawing.Size(129, 22);
            this.txtCena.TabIndex = 17;
            // 
            // lboxSprzedaz
            // 
            this.lboxSprzedaz.AccessibleName = "lboxSprzedaz";
            this.lboxSprzedaz.ColumnWidth = 10;
            this.lboxSprzedaz.FormattingEnabled = true;
            this.lboxSprzedaz.HorizontalExtent = 100;
            this.lboxSprzedaz.HorizontalScrollbar = true;
            this.lboxSprzedaz.ItemHeight = 16;
            this.lboxSprzedaz.Location = new System.Drawing.Point(19, 21);
            this.lboxSprzedaz.Name = "lboxSprzedaz";
            this.lboxSprzedaz.ScrollAlwaysVisible = true;
            this.lboxSprzedaz.Size = new System.Drawing.Size(1071, 452);
            this.lboxSprzedaz.TabIndex = 0;
            this.lboxSprzedaz.SelectedIndexChanged += new System.EventHandler(this.lboxSprzedaz_SelectedIndexChanged);
            // 
            // btnListaAut
            // 
            this.btnListaAut.AccessibleName = "btnListaAut";
            this.btnListaAut.BackColor = System.Drawing.Color.Aqua;
            this.btnListaAut.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnListaAut.Location = new System.Drawing.Point(36, 394);
            this.btnListaAut.Name = "btnListaAut";
            this.btnListaAut.Size = new System.Drawing.Size(129, 23);
            this.btnListaAut.TabIndex = 2;
            this.btnListaAut.Text = "pokaż listę aut";
            this.btnListaAut.UseVisualStyleBackColor = false;
            this.btnListaAut.Click += new System.EventHandler(this.btnListaAut_Click);
            // 
            // btnSzukajAuta
            // 
            this.btnSzukajAuta.AccessibleName = "btnSzukajAuta";
            this.btnSzukajAuta.BackColor = System.Drawing.Color.Aqua;
            this.btnSzukajAuta.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnSzukajAuta.Location = new System.Drawing.Point(36, 350);
            this.btnSzukajAuta.Name = "btnSzukajAuta";
            this.btnSzukajAuta.Size = new System.Drawing.Size(129, 23);
            this.btnSzukajAuta.TabIndex = 31;
            this.btnSzukajAuta.Text = "znajdź auto";
            this.btnSzukajAuta.UseVisualStyleBackColor = false;
            this.btnSzukajAuta.Click += new System.EventHandler(this.btnSzukajAuta_Click);
            // 
            // btnDodajAuto
            // 
            this.btnDodajAuto.AccessibleName = "btnDodajAuto";
            this.btnDodajAuto.BackColor = System.Drawing.Color.Aqua;
            this.btnDodajAuto.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnDodajAuto.Location = new System.Drawing.Point(36, 438);
            this.btnDodajAuto.Name = "btnDodajAuto";
            this.btnDodajAuto.Size = new System.Drawing.Size(129, 23);
            this.btnDodajAuto.TabIndex = 4;
            this.btnDodajAuto.Text = "dodaj auto";
            this.btnDodajAuto.UseVisualStyleBackColor = false;
            this.btnDodajAuto.Click += new System.EventHandler(this.btnDodajAuto_Click);
            // 
            // btnDaneAuta
            // 
            this.btnDaneAuta.AccessibleName = "btnDaneAuta";
            this.btnDaneAuta.BackColor = System.Drawing.Color.Aqua;
            this.btnDaneAuta.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnDaneAuta.Location = new System.Drawing.Point(36, 482);
            this.btnDaneAuta.Name = "btnDaneAuta";
            this.btnDaneAuta.Size = new System.Drawing.Size(129, 23);
            this.btnDaneAuta.TabIndex = 29;
            this.btnDaneAuta.Text = "dane auta";
            this.btnDaneAuta.UseVisualStyleBackColor = false;
            this.btnDaneAuta.Click += new System.EventHandler(this.btnDaneAuta_Click);
            // 
            // txtCenaMin
            // 
            this.txtCenaMin.AccessibleDescription = "txtCenaMin";
            this.txtCenaMin.Location = new System.Drawing.Point(571, 439);
            this.txtCenaMin.Name = "txtCenaMin";
            this.txtCenaMin.Size = new System.Drawing.Size(129, 22);
            this.txtCenaMin.TabIndex = 46;
            // 
            // Kontrahenci
            // 
            this.Kontrahenci.AccessibleDescription = "Kontrahenci";
            this.Kontrahenci.AccessibleName = "Kontrahenci";
            this.Kontrahenci.BackColor = System.Drawing.Color.MediumAquamarine;
            this.Kontrahenci.Controls.Add(this.lbNazwa);
            this.Kontrahenci.Controls.Add(this.txtNazwa);
            this.Kontrahenci.Controls.Add(this.dgvKontrahenci);
            this.Kontrahenci.Controls.Add(this.txtTelefon);
            this.Kontrahenci.Controls.Add(this.lbTelefon);
            this.Kontrahenci.Controls.Add(this.lbSkype);
            this.Kontrahenci.Controls.Add(this.txtSkype);
            this.Kontrahenci.Controls.Add(this.lbImie);
            this.Kontrahenci.Controls.Add(this.txtImie);
            this.Kontrahenci.Controls.Add(this.lbKod);
            this.Kontrahenci.Controls.Add(this.txtKod);
            this.Kontrahenci.Controls.Add(this.lbwww);
            this.Kontrahenci.Controls.Add(this.txtWWW);
            this.Kontrahenci.Controls.Add(this.lbEmail);
            this.Kontrahenci.Controls.Add(this.txtEmail);
            this.Kontrahenci.Controls.Add(this.lbNazwisko);
            this.Kontrahenci.Controls.Add(this.txtNazwisko);
            this.Kontrahenci.Controls.Add(this.lbMiasto);
            this.Kontrahenci.Controls.Add(this.txtMiasto);
            this.Kontrahenci.Controls.Add(this.lbFirma);
            this.Kontrahenci.Controls.Add(this.txtFirma);
            this.Kontrahenci.Controls.Add(this.btnZnajdzDealera);
            this.Kontrahenci.Controls.Add(this.lboxKontrahenci);
            this.Kontrahenci.Controls.Add(this.btnPokazKontrahentow);
            this.Kontrahenci.Controls.Add(this.btnUzupelnijDaneKH);
            this.Kontrahenci.Location = new System.Drawing.Point(25, 4);
            this.Kontrahenci.Name = "Kontrahenci";
            this.Kontrahenci.Padding = new System.Windows.Forms.Padding(3);
            this.Kontrahenci.Size = new System.Drawing.Size(1156, 537);
            this.Kontrahenci.TabIndex = 0;
            this.Kontrahenci.Tag = "Kontrahenci";
            this.Kontrahenci.Text = "Kontrahenci";
            // 
            // dgvKontrahenci
            // 
            this.dgvKontrahenci.AccessibleName = "dgvKontrahenci";
            this.dgvKontrahenci.AutoGenerateColumns = false;
            this.dgvKontrahenci.BackgroundColor = System.Drawing.Color.Thistle;
            this.dgvKontrahenci.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvKontrahenci.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idDataGridViewTextBoxColumn,
            this.nazwaDataGridViewTextBoxColumn,
            this.nazwiskoDataGridViewTextBoxColumn,
            this.imieDataGridViewTextBoxColumn,
            this.firmaDataGridViewTextBoxColumn,
            this.telefonDataGridViewTextBoxColumn,
            this.emailDataGridViewTextBoxColumn,
            this.adresDataGridViewTextBoxColumn,
            this.kodDataGridViewTextBoxColumn,
            this.miastoDataGridViewTextBoxColumn,
            this.skypeDataGridViewTextBoxColumn,
            this.wwwDataGridViewTextBoxColumn});
            this.dgvKontrahenci.DataSource = this.rejestrkontrahentowBindingSource;
            this.dgvKontrahenci.Location = new System.Drawing.Point(16, 17);
            this.dgvKontrahenci.Name = "dgvKontrahenci";
            this.dgvKontrahenci.RowHeadersVisible = false;
            this.dgvKontrahenci.RowTemplate.Height = 24;
            this.dgvKontrahenci.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvKontrahenci.Size = new System.Drawing.Size(1108, 356);
            this.dgvKontrahenci.TabIndex = 74;
            // 
            // txtTelefon
            // 
            this.txtTelefon.AccessibleDescription = "txtTelefon";
            this.txtTelefon.Location = new System.Drawing.Point(783, 449);
            this.txtTelefon.Name = "txtTelefon";
            this.txtTelefon.Size = new System.Drawing.Size(129, 22);
            this.txtTelefon.TabIndex = 73;
            // 
            // lbTelefon
            // 
            this.lbTelefon.AccessibleName = "lbTelefon";
            this.lbTelefon.AutoSize = true;
            this.lbTelefon.Location = new System.Drawing.Point(780, 428);
            this.lbTelefon.Name = "lbTelefon";
            this.lbTelefon.Size = new System.Drawing.Size(51, 17);
            this.lbTelefon.TabIndex = 72;
            this.lbTelefon.Text = "telefon";
            // 
            // lbSkype
            // 
            this.lbSkype.AccessibleName = "lbSkype";
            this.lbSkype.AutoSize = true;
            this.lbSkype.Location = new System.Drawing.Point(462, 477);
            this.lbSkype.Name = "lbSkype";
            this.lbSkype.Size = new System.Drawing.Size(45, 17);
            this.lbSkype.TabIndex = 69;
            this.lbSkype.Text = "skype";
            // 
            // txtSkype
            // 
            this.txtSkype.AccessibleDescription = "txtSkype";
            this.txtSkype.Location = new System.Drawing.Point(461, 497);
            this.txtSkype.Name = "txtSkype";
            this.txtSkype.Size = new System.Drawing.Size(129, 22);
            this.txtSkype.TabIndex = 68;
            // 
            // lbImie
            // 
            this.lbImie.AccessibleName = "lbImie";
            this.lbImie.AutoSize = true;
            this.lbImie.Location = new System.Drawing.Point(262, 428);
            this.lbImie.Name = "lbImie";
            this.lbImie.Size = new System.Drawing.Size(33, 17);
            this.lbImie.TabIndex = 62;
            this.lbImie.Text = "imie";
            // 
            // txtImie
            // 
            this.txtImie.AccessibleDescription = "txtImie";
            this.txtImie.Location = new System.Drawing.Point(265, 448);
            this.txtImie.Name = "txtImie";
            this.txtImie.Size = new System.Drawing.Size(129, 22);
            this.txtImie.TabIndex = 61;
            // 
            // lbKod
            // 
            this.lbKod.AutoSize = true;
            this.lbKod.Location = new System.Drawing.Point(264, 477);
            this.lbKod.Name = "lbKod";
            this.lbKod.Size = new System.Drawing.Size(31, 17);
            this.lbKod.TabIndex = 60;
            this.lbKod.Text = "kod";
            // 
            // txtKod
            // 
            this.txtKod.AccessibleDescription = "txtKod";
            this.txtKod.Location = new System.Drawing.Point(266, 497);
            this.txtKod.Name = "txtKod";
            this.txtKod.Size = new System.Drawing.Size(129, 22);
            this.txtKod.TabIndex = 59;
            // 
            // lbwww
            // 
            this.lbwww.AccessibleName = "lbwww";
            this.lbwww.AutoSize = true;
            this.lbwww.Location = new System.Drawing.Point(627, 428);
            this.lbwww.Name = "lbwww";
            this.lbwww.Size = new System.Drawing.Size(35, 17);
            this.lbwww.TabIndex = 58;
            this.lbwww.Text = "www";
            // 
            // txtWWW
            // 
            this.txtWWW.AccessibleDescription = "txtWWW";
            this.txtWWW.Location = new System.Drawing.Point(630, 448);
            this.txtWWW.Name = "txtWWW";
            this.txtWWW.Size = new System.Drawing.Size(129, 22);
            this.txtWWW.TabIndex = 57;
            // 
            // lbEmail
            // 
            this.lbEmail.AccessibleName = "lbEmail";
            this.lbEmail.AutoSize = true;
            this.lbEmail.Location = new System.Drawing.Point(780, 382);
            this.lbEmail.Name = "lbEmail";
            this.lbEmail.Size = new System.Drawing.Size(41, 17);
            this.lbEmail.TabIndex = 56;
            this.lbEmail.Text = "email";
            // 
            // txtEmail
            // 
            this.txtEmail.AccessibleDescription = "txtEmail";
            this.txtEmail.Location = new System.Drawing.Point(783, 402);
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Size = new System.Drawing.Size(129, 22);
            this.txtEmail.TabIndex = 55;
            // 
            // lbNazwisko
            // 
            this.lbNazwisko.AccessibleName = "lbNazwisko";
            this.lbNazwisko.AutoSize = true;
            this.lbNazwisko.Location = new System.Drawing.Point(262, 383);
            this.lbNazwisko.Name = "lbNazwisko";
            this.lbNazwisko.Size = new System.Drawing.Size(65, 17);
            this.lbNazwisko.TabIndex = 54;
            this.lbNazwisko.Text = "nazwisko";
            // 
            // txtNazwisko
            // 
            this.txtNazwisko.AccessibleDescription = "txtNazwisko";
            this.txtNazwisko.Location = new System.Drawing.Point(265, 403);
            this.txtNazwisko.Name = "txtNazwisko";
            this.txtNazwisko.Size = new System.Drawing.Size(129, 22);
            this.txtNazwisko.TabIndex = 53;
            // 
            // lbMiasto
            // 
            this.lbMiasto.AccessibleName = "lbMiasto";
            this.lbMiasto.AutoSize = true;
            this.lbMiasto.Location = new System.Drawing.Point(458, 426);
            this.lbMiasto.Name = "lbMiasto";
            this.lbMiasto.Size = new System.Drawing.Size(49, 17);
            this.lbMiasto.TabIndex = 52;
            this.lbMiasto.Text = "miasto";
            // 
            // txtMiasto
            // 
            this.txtMiasto.AccessibleDescription = "txtMiasto";
            this.txtMiasto.Location = new System.Drawing.Point(461, 446);
            this.txtMiasto.Name = "txtMiasto";
            this.txtMiasto.Size = new System.Drawing.Size(129, 22);
            this.txtMiasto.TabIndex = 50;
            // 
            // lbFirma
            // 
            this.lbFirma.AccessibleName = "lbFirma";
            this.lbFirma.AutoSize = true;
            this.lbFirma.Location = new System.Drawing.Point(458, 382);
            this.lbFirma.Name = "lbFirma";
            this.lbFirma.Size = new System.Drawing.Size(39, 17);
            this.lbFirma.TabIndex = 49;
            this.lbFirma.Text = "firma";
            // 
            // txtFirma
            // 
            this.txtFirma.AccessibleDescription = "txtFirma";
            this.txtFirma.Location = new System.Drawing.Point(461, 402);
            this.txtFirma.Name = "txtFirma";
            this.txtFirma.Size = new System.Drawing.Size(129, 22);
            this.txtFirma.TabIndex = 48;
            // 
            // btnZnajdzDealera
            // 
            this.btnZnajdzDealera.AccessibleName = "btnZnajdzDealera";
            this.btnZnajdzDealera.BackColor = System.Drawing.Color.Aqua;
            this.btnZnajdzDealera.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnZnajdzDealera.Location = new System.Drawing.Point(30, 413);
            this.btnZnajdzDealera.Name = "btnZnajdzDealera";
            this.btnZnajdzDealera.Size = new System.Drawing.Size(172, 23);
            this.btnZnajdzDealera.TabIndex = 9;
            this.btnZnajdzDealera.Text = "znajdź dealera";
            this.btnZnajdzDealera.UseVisualStyleBackColor = false;
            this.btnZnajdzDealera.Click += new System.EventHandler(this.btnZnajdzDealera_Click);
            // 
            // lboxKontrahenci
            // 
            this.lboxKontrahenci.AccessibleName = "lboxKontrahenci";
            this.lboxKontrahenci.BackColor = System.Drawing.SystemColors.Window;
            this.lboxKontrahenci.ColumnWidth = 10;
            this.lboxKontrahenci.DisplayMember = "nazwa";
            this.lboxKontrahenci.FormattingEnabled = true;
            this.lboxKontrahenci.HorizontalExtent = 10;
            this.lboxKontrahenci.HorizontalScrollbar = true;
            this.lboxKontrahenci.ItemHeight = 16;
            this.lboxKontrahenci.Location = new System.Drawing.Point(16, 17);
            this.lboxKontrahenci.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.lboxKontrahenci.Name = "lboxKontrahenci";
            this.lboxKontrahenci.Size = new System.Drawing.Size(1108, 356);
            this.lboxKontrahenci.TabIndex = 0;
            this.lboxKontrahenci.ValueMember = "nazwa";
            // 
            // btnPokazKontrahentow
            // 
            this.btnPokazKontrahentow.AccessibleName = "btnPokazKontrahentow";
            this.btnPokazKontrahentow.BackColor = System.Drawing.Color.Aqua;
            this.btnPokazKontrahentow.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnPokazKontrahentow.Location = new System.Drawing.Point(30, 471);
            this.btnPokazKontrahentow.Name = "btnPokazKontrahentow";
            this.btnPokazKontrahentow.Size = new System.Drawing.Size(172, 23);
            this.btnPokazKontrahentow.TabIndex = 8;
            this.btnPokazKontrahentow.Text = "pokaż listę kontrahentów";
            this.btnPokazKontrahentow.UseVisualStyleBackColor = false;
            this.btnPokazKontrahentow.Click += new System.EventHandler(this.btnPokazKontrahentow_Click);
            // 
            // btnUzupelnijDaneKH
            // 
            this.btnUzupelnijDaneKH.AccessibleName = "btnUzupelnijDaneKH";
            this.btnUzupelnijDaneKH.BackColor = System.Drawing.Color.Aqua;
            this.btnUzupelnijDaneKH.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnUzupelnijDaneKH.Location = new System.Drawing.Point(30, 442);
            this.btnUzupelnijDaneKH.Name = "btnUzupelnijDaneKH";
            this.btnUzupelnijDaneKH.Size = new System.Drawing.Size(172, 23);
            this.btnUzupelnijDaneKH.TabIndex = 5;
            this.btnUzupelnijDaneKH.Text = "pokaz dane";
            this.btnUzupelnijDaneKH.UseVisualStyleBackColor = false;
            this.btnUzupelnijDaneKH.Click += new System.EventHandler(this.btnUzupelnijDaneKH_Click);
            // 
            // txt_wybrany_kh_dlugosc
            // 
            this.txt_wybrany_kh_dlugosc.AccessibleDescription = "txt_wybrany_kh_dlugosc";
            this.txt_wybrany_kh_dlugosc.AccessibleName = "txt_wybrany_kh_dlugosc";
            this.txt_wybrany_kh_dlugosc.Location = new System.Drawing.Point(1146, 32);
            this.txt_wybrany_kh_dlugosc.Name = "txt_wybrany_kh_dlugosc";
            this.txt_wybrany_kh_dlugosc.Size = new System.Drawing.Size(73, 22);
            this.txt_wybrany_kh_dlugosc.TabIndex = 46;
            // 
            // txt_wybrany_kh_id
            // 
            this.txt_wybrany_kh_id.AccessibleDescription = "txt_wybrany_kh_id";
            this.txt_wybrany_kh_id.Location = new System.Drawing.Point(1102, 32);
            this.txt_wybrany_kh_id.Name = "txt_wybrany_kh_id";
            this.txt_wybrany_kh_id.Size = new System.Drawing.Size(38, 22);
            this.txt_wybrany_kh_id.TabIndex = 45;
            // 
            // txt_wybrany_kh
            // 
            this.txt_wybrany_kh.AccessibleDescription = "txt_wybrany_kh";
            this.txt_wybrany_kh.Location = new System.Drawing.Point(1017, 32);
            this.txt_wybrany_kh.Name = "txt_wybrany_kh";
            this.txt_wybrany_kh.Size = new System.Drawing.Size(79, 22);
            this.txt_wybrany_kh.TabIndex = 44;
            // 
            // Sprzedaz
            // 
            this.Sprzedaz.BackColor = System.Drawing.Color.MediumAquamarine;
            this.Sprzedaz.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Sprzedaz.Controls.Add(this.dgvSprzedaz);
            this.Sprzedaz.Controls.Add(this.btnSzczegolySprzedazy);
            this.Sprzedaz.Controls.Add(this.btnPokazSprzedaz);
            this.Sprzedaz.Controls.Add(this.lboxSprzedaz);
            this.Sprzedaz.Location = new System.Drawing.Point(25, 4);
            this.Sprzedaz.Name = "Sprzedaz";
            this.Sprzedaz.Size = new System.Drawing.Size(1156, 537);
            this.Sprzedaz.TabIndex = 2;
            this.Sprzedaz.Text = "Sprzedaż";
            // 
            // dgvSprzedaz
            // 
            this.dgvSprzedaz.AccessibleName = "dgvSprzedaz";
            this.dgvSprzedaz.AutoGenerateColumns = false;
            this.dgvSprzedaz.BackgroundColor = System.Drawing.Color.LightSteelBlue;
            this.dgvSprzedaz.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvSprzedaz.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idDataGridViewTextBoxColumn1,
            this.rejestracjaDataGridViewTextBoxColumn1,
            this.właścicielobecnyDataGridViewTextBoxColumn,
            this.właścicielpoprzedniDataGridViewTextBoxColumn,
            this.rokprodukcjiDataGridViewTextBoxColumn1,
            this.przebiegDataGridViewTextBoxColumn1,
            this.markaDataGridViewTextBoxColumn1,
            this.silnikDataGridViewTextBoxColumn1,
            this.kolorDataGridViewTextBoxColumn1,
            this.cenawywoławczaDataGridViewTextBoxColumn,
            this.cenasprzedażyDataGridViewTextBoxColumn,
            this.obecnystatusDataGridViewTextBoxColumn,
            this.dataDataGridViewTextBoxColumn});
            this.dgvSprzedaz.DataSource = this.sprzedaneautaBindingSource1;
            this.dgvSprzedaz.Location = new System.Drawing.Point(19, 21);
            this.dgvSprzedaz.Name = "dgvSprzedaz";
            this.dgvSprzedaz.RowHeadersVisible = false;
            this.dgvSprzedaz.RowTemplate.Height = 24;
            this.dgvSprzedaz.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvSprzedaz.Size = new System.Drawing.Size(1071, 452);
            this.dgvSprzedaz.TabIndex = 50;
            // 
            // btnSzczegolySprzedazy
            // 
            this.btnSzczegolySprzedazy.AccessibleName = "btnSzczegolySprzedazy";
            this.btnSzczegolySprzedazy.BackColor = System.Drawing.Color.Aqua;
            this.btnSzczegolySprzedazy.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnSzczegolySprzedazy.Location = new System.Drawing.Point(224, 488);
            this.btnSzczegolySprzedazy.Name = "btnSzczegolySprzedazy";
            this.btnSzczegolySprzedazy.Size = new System.Drawing.Size(172, 23);
            this.btnSzczegolySprzedazy.TabIndex = 49;
            this.btnSzczegolySprzedazy.Text = "pokaż dane auta";
            this.btnSzczegolySprzedazy.UseVisualStyleBackColor = false;
            this.btnSzczegolySprzedazy.Click += new System.EventHandler(this.btnSzczegolySprzedazy_Click);
            // 
            // btnPokazSprzedaz
            // 
            this.btnPokazSprzedaz.AccessibleName = "btnPokazSprzedaz";
            this.btnPokazSprzedaz.BackColor = System.Drawing.Color.Aqua;
            this.btnPokazSprzedaz.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnPokazSprzedaz.Location = new System.Drawing.Point(19, 488);
            this.btnPokazSprzedaz.Name = "btnPokazSprzedaz";
            this.btnPokazSprzedaz.Size = new System.Drawing.Size(172, 23);
            this.btnPokazSprzedaz.TabIndex = 46;
            this.btnPokazSprzedaz.Text = "pokaż sprzedane auta";
            this.btnPokazSprzedaz.UseVisualStyleBackColor = false;
            this.btnPokazSprzedaz.Click += new System.EventHandler(this.btnPokazSprzedaz_Click);
            // 
            // lbKopiujHaslo
            // 
            this.lbKopiujHaslo.AccessibleName = "lbKopiujHaslo";
            this.lbKopiujHaslo.AutoSize = true;
            this.lbKopiujHaslo.Location = new System.Drawing.Point(927, 12);
            this.lbKopiujHaslo.Name = "lbKopiujHaslo";
            this.lbKopiujHaslo.Size = new System.Drawing.Size(80, 17);
            this.lbKopiujHaslo.TabIndex = 65;
            this.lbKopiujHaslo.Text = "kopia hasła";
            // 
            // lbRejestracja
            // 
            this.lbRejestracja.AutoSize = true;
            this.lbRejestracja.Location = new System.Drawing.Point(203, 375);
            this.lbRejestracja.Name = "lbRejestracja";
            this.lbRejestracja.Size = new System.Drawing.Size(132, 17);
            this.lbRejestracja.TabIndex = 28;
            this.lbRejestracja.Text = "numer rejestracyjny";
            // 
            // lbWybranaRejestracja
            // 
            this.lbWybranaRejestracja.AccessibleName = "lbWybranaRejestracja";
            this.lbWybranaRejestracja.AutoSize = true;
            this.lbWybranaRejestracja.Location = new System.Drawing.Point(582, 11);
            this.lbWybranaRejestracja.Name = "lbWybranaRejestracja";
            this.lbWybranaRejestracja.Size = new System.Drawing.Size(131, 17);
            this.lbWybranaRejestracja.TabIndex = 72;
            this.lbWybranaRejestracja.Text = "wybrana rejestracja";
            // 
            // txtWybranaRejestracja
            // 
            this.txtWybranaRejestracja.AccessibleDescription = "txtWybranaRejestracja";
            this.txtWybranaRejestracja.Location = new System.Drawing.Point(582, 32);
            this.txtWybranaRejestracja.Name = "txtWybranaRejestracja";
            this.txtWybranaRejestracja.Size = new System.Drawing.Size(128, 22);
            this.txtWybranaRejestracja.TabIndex = 71;
            // 
            // txtZalogowanyNazwa
            // 
            this.txtZalogowanyNazwa.AccessibleDescription = "txtZalogowanyNazwa";
            this.txtZalogowanyNazwa.Location = new System.Drawing.Point(842, 32);
            this.txtZalogowanyNazwa.Name = "txtZalogowanyNazwa";
            this.txtZalogowanyNazwa.Size = new System.Drawing.Size(86, 22);
            this.txtZalogowanyNazwa.TabIndex = 79;
            this.txtZalogowanyNazwa.Tag = "Administrator";
            // 
            // lbZalogowany
            // 
            this.lbZalogowany.AccessibleName = "lbZalogowany";
            this.lbZalogowany.AutoSize = true;
            this.lbZalogowany.Location = new System.Drawing.Point(839, 12);
            this.lbZalogowany.Name = "lbZalogowany";
            this.lbZalogowany.Size = new System.Drawing.Size(82, 17);
            this.lbZalogowany.TabIndex = 80;
            this.lbZalogowany.Text = "zalogowany";
            // 
            // rtxKomunikat
            // 
            this.rtxKomunikat.AccessibleName = "rtxKomunikat";
            this.rtxKomunikat.Location = new System.Drawing.Point(1249, 496);
            this.rtxKomunikat.Name = "rtxKomunikat";
            this.rtxKomunikat.Size = new System.Drawing.Size(172, 120);
            this.rtxKomunikat.TabIndex = 76;
            this.rtxKomunikat.Text = "";
            // 
            // txtRejestracja
            // 
            this.txtRejestracja.AccessibleDescription = "txtRejestracja";
            this.txtRejestracja.Location = new System.Drawing.Point(206, 395);
            this.txtRejestracja.Name = "txtRejestracja";
            this.txtRejestracja.Size = new System.Drawing.Size(129, 22);
            this.txtRejestracja.TabIndex = 27;
            // 
            // lbKolor
            // 
            this.lbKolor.AutoSize = true;
            this.lbKolor.Location = new System.Drawing.Point(399, 420);
            this.lbKolor.Name = "lbKolor";
            this.lbKolor.Size = new System.Drawing.Size(39, 17);
            this.lbKolor.TabIndex = 26;
            this.lbKolor.Text = "kolor";
            // 
            // txtKolor
            // 
            this.txtKolor.AccessibleDescription = "txtKolor";
            this.txtKolor.Location = new System.Drawing.Point(402, 440);
            this.txtKolor.Name = "txtKolor";
            this.txtKolor.Size = new System.Drawing.Size(129, 22);
            this.txtKolor.TabIndex = 25;
            // 
            // lbPrzebieg
            // 
            this.lbPrzebieg.AutoSize = true;
            this.lbPrzebieg.Location = new System.Drawing.Point(568, 375);
            this.lbPrzebieg.Name = "lbPrzebieg";
            this.lbPrzebieg.Size = new System.Drawing.Size(63, 17);
            this.lbPrzebieg.TabIndex = 24;
            this.lbPrzebieg.Text = "przebieg";
            // 
            // txtPrzebieg
            // 
            this.txtPrzebieg.AccessibleDescription = "txtPrzebieg";
            this.txtPrzebieg.Location = new System.Drawing.Point(571, 395);
            this.txtPrzebieg.Name = "txtPrzebieg";
            this.txtPrzebieg.Size = new System.Drawing.Size(129, 22);
            this.txtPrzebieg.TabIndex = 23;
            // 
            // txtDlugoscRejestracji
            // 
            this.txtDlugoscRejestracji.AccessibleDescription = "txtDlugoscRejestracji";
            this.txtDlugoscRejestracji.Location = new System.Drawing.Point(722, 32);
            this.txtDlugoscRejestracji.Name = "txtDlugoscRejestracji";
            this.txtDlugoscRejestracji.Size = new System.Drawing.Size(54, 22);
            this.txtDlugoscRejestracji.TabIndex = 68;
            // 
            // lbIdAuta
            // 
            this.lbIdAuta.AccessibleName = "lbIdAuta";
            this.lbIdAuta.AutoSize = true;
            this.lbIdAuta.Location = new System.Drawing.Point(782, 12);
            this.lbIdAuta.Name = "lbIdAuta";
            this.lbIdAuta.Size = new System.Drawing.Size(51, 17);
            this.lbIdAuta.TabIndex = 67;
            this.lbIdAuta.Text = "id auta";
            // 
            // mtxHasloPowtorz
            // 
            this.mtxHasloPowtorz.AccessibleName = "mtxHasloPowtorz";
            this.mtxHasloPowtorz.Location = new System.Drawing.Point(934, 31);
            this.mtxHasloPowtorz.Name = "mtxHasloPowtorz";
            this.mtxHasloPowtorz.Size = new System.Drawing.Size(77, 22);
            this.mtxHasloPowtorz.TabIndex = 75;
            // 
            // lbRok
            // 
            this.lbRok.AutoSize = true;
            this.lbRok.Location = new System.Drawing.Point(568, 329);
            this.lbRok.Name = "lbRok";
            this.lbRok.Size = new System.Drawing.Size(89, 17);
            this.lbRok.TabIndex = 22;
            this.lbRok.Text = "rok produkcji";
            // 
            // txtRok
            // 
            this.txtRok.AccessibleDescription = "txtRok";
            this.txtRok.Location = new System.Drawing.Point(571, 349);
            this.txtRok.Name = "txtRok";
            this.txtRok.Size = new System.Drawing.Size(129, 22);
            this.txtRok.TabIndex = 21;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(203, 330);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(66, 17);
            this.label9.TabIndex = 20;
            this.label9.Text = "wlasciciel";
            // 
            // lbDlugoscRejestracji
            // 
            this.lbDlugoscRejestracji.AccessibleName = "lbDlugoscRejestracji";
            this.lbDlugoscRejestracji.AutoSize = true;
            this.lbDlugoscRejestracji.Location = new System.Drawing.Point(719, 12);
            this.lbDlugoscRejestracji.Name = "lbDlugoscRejestracji";
            this.lbDlugoscRejestracji.Size = new System.Drawing.Size(57, 17);
            this.lbDlugoscRejestracji.TabIndex = 69;
            this.lbDlugoscRejestracji.Text = "długość";
            // 
            // txtIdWybranegoAuta
            // 
            this.txtIdWybranegoAuta.AccessibleDescription = "txtIdWybranegoAuta";
            this.txtIdWybranegoAuta.Location = new System.Drawing.Point(782, 31);
            this.txtIdWybranegoAuta.Name = "txtIdWybranegoAuta";
            this.txtIdWybranegoAuta.Size = new System.Drawing.Size(51, 22);
            this.txtIdWybranegoAuta.TabIndex = 66;
            // 
            // txtWlasciciel
            // 
            this.txtWlasciciel.AccessibleDescription = "txtWlasciciel";
            this.txtWlasciciel.Location = new System.Drawing.Point(206, 350);
            this.txtWlasciciel.Name = "txtWlasciciel";
            this.txtWlasciciel.Size = new System.Drawing.Size(129, 22);
            this.txtWlasciciel.TabIndex = 19;
            // 
            // tcKontrahentTowar
            // 
            this.tcKontrahentTowar.AccessibleName = "tcKontrahentTowar";
            this.tcKontrahentTowar.Alignment = System.Windows.Forms.TabAlignment.Left;
            this.tcKontrahentTowar.Controls.Add(this.Samochody);
            this.tcKontrahentTowar.Controls.Add(this.Kontrahenci);
            this.tcKontrahentTowar.Controls.Add(this.Sprzedaz);
            this.tcKontrahentTowar.Controls.Add(this.tabPage1);
            this.tcKontrahentTowar.Location = new System.Drawing.Point(34, 71);
            this.tcKontrahentTowar.Multiline = true;
            this.tcKontrahentTowar.Name = "tcKontrahentTowar";
            this.tcKontrahentTowar.SelectedIndex = 0;
            this.tcKontrahentTowar.Size = new System.Drawing.Size(1185, 545);
            this.tcKontrahentTowar.TabIndex = 64;
            this.tcKontrahentTowar.Tag = "Kontrahenci";
            this.tcKontrahentTowar.SelectedIndexChanged += new System.EventHandler(this.lboxKontrahenci_SelectedIndexChanged);
            // 
            // Samochody
            // 
            this.Samochody.AccessibleName = "Samochody";
            this.Samochody.BackColor = System.Drawing.Color.MediumAquamarine;
            this.Samochody.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Samochody.Controls.Add(this.dgvListaAut);
            this.Samochody.Controls.Add(this.btnDodajAuto);
            this.Samochody.Controls.Add(this.btnSzukajAuta);
            this.Samochody.Controls.Add(this.btnDaneAuta);
            this.Samochody.Controls.Add(this.btnListaAut);
            this.Samochody.Controls.Add(this.label8);
            this.Samochody.Controls.Add(this.txtCenaMin);
            this.Samochody.Controls.Add(this.label4);
            this.Samochody.Controls.Add(this.txtPrzebiegDo);
            this.Samochody.Controls.Add(this.label3);
            this.Samochody.Controls.Add(this.txtRokDo);
            this.Samochody.Controls.Add(this.label7);
            this.Samochody.Controls.Add(this.txtCena);
            this.Samochody.Controls.Add(this.lbRejestracja);
            this.Samochody.Controls.Add(this.txtRejestracja);
            this.Samochody.Controls.Add(this.lbKolor);
            this.Samochody.Controls.Add(this.txtKolor);
            this.Samochody.Controls.Add(this.lbPrzebieg);
            this.Samochody.Controls.Add(this.txtPrzebieg);
            this.Samochody.Controls.Add(this.lbRok);
            this.Samochody.Controls.Add(this.txtRok);
            this.Samochody.Controls.Add(this.label9);
            this.Samochody.Controls.Add(this.txtWlasciciel);
            this.Samochody.Controls.Add(this.lbSilnik);
            this.Samochody.Controls.Add(this.txtSilnik);
            this.Samochody.Controls.Add(this.lbMarka);
            this.Samochody.Controls.Add(this.txtMarka);
            this.Samochody.Controls.Add(this.lboxSamochody);
            this.Samochody.Location = new System.Drawing.Point(25, 4);
            this.Samochody.Name = "Samochody";
            this.Samochody.Padding = new System.Windows.Forms.Padding(3);
            this.Samochody.Size = new System.Drawing.Size(1156, 537);
            this.Samochody.TabIndex = 1;
            this.Samochody.Tag = "Samochody";
            this.Samochody.Text = "Samochody";
            // 
            // dgvListaAut
            // 
            this.dgvListaAut.AutoGenerateColumns = false;
            this.dgvListaAut.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dgvListaAut.BackgroundColor = System.Drawing.Color.LightCyan;
            this.dgvListaAut.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.id,
            this.rejestracjaDataGridViewTextBoxColumn,
            this.właścicielDataGridViewTextBoxColumn,
            this.rokprodukcjiDataGridViewTextBoxColumn,
            this.przebiegDataGridViewTextBoxColumn,
            this.markaDataGridViewTextBoxColumn,
            this.silnikDataGridViewTextBoxColumn,
            this.kolorDataGridViewTextBoxColumn,
            this.najwyzsza_cena,
            this.najnizsza_cena,
            this.ostatnia_cena});
            this.dgvListaAut.DataSource = this.listaautBindingSource;
            this.dgvListaAut.GridColor = System.Drawing.Color.LightGreen;
            this.dgvListaAut.Location = new System.Drawing.Point(19, 21);
            this.dgvListaAut.Name = "dgvListaAut";
            this.dgvListaAut.RowHeadersVisible = false;
            this.dgvListaAut.RowTemplate.Height = 24;
            this.dgvListaAut.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvListaAut.Size = new System.Drawing.Size(1121, 292);
            this.dgvListaAut.TabIndex = 48;
            this.dgvListaAut.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvListaAut_CellContentClick);
            // 
            // id
            // 
            this.id.DataPropertyName = "id";
            this.id.HeaderText = "id";
            this.id.Name = "id";
            this.id.Visible = false;
            // 
            // najwyzsza_cena
            // 
            this.najwyzsza_cena.DataPropertyName = "najwyzsza_cena";
            this.najwyzsza_cena.HeaderText = "cena max";
            this.najwyzsza_cena.Name = "najwyzsza_cena";
            this.najwyzsza_cena.Width = 70;
            // 
            // najnizsza_cena
            // 
            this.najnizsza_cena.DataPropertyName = "najnizsza_cena";
            this.najnizsza_cena.HeaderText = "cena min";
            this.najnizsza_cena.Name = "najnizsza_cena";
            this.najnizsza_cena.Width = 70;
            // 
            // ostatnia_cena
            // 
            this.ostatnia_cena.DataPropertyName = "ostatnia_cena";
            this.ostatnia_cena.HeaderText = "ostatnia cena";
            this.ostatnia_cena.Name = "ostatnia_cena";
            this.ostatnia_cena.Width = 80;
            // 
            // lbSilnik
            // 
            this.lbSilnik.AutoSize = true;
            this.lbSilnik.Location = new System.Drawing.Point(399, 373);
            this.lbSilnik.Name = "lbSilnik";
            this.lbSilnik.Size = new System.Drawing.Size(39, 17);
            this.lbSilnik.TabIndex = 18;
            this.lbSilnik.Text = "silnik";
            // 
            // txtSilnik
            // 
            this.txtSilnik.AccessibleDescription = "txtSilnik";
            this.txtSilnik.Location = new System.Drawing.Point(402, 393);
            this.txtSilnik.Name = "txtSilnik";
            this.txtSilnik.Size = new System.Drawing.Size(129, 22);
            this.txtSilnik.TabIndex = 17;
            // 
            // lbMarka
            // 
            this.lbMarka.AutoSize = true;
            this.lbMarka.Location = new System.Drawing.Point(399, 329);
            this.lbMarka.Name = "lbMarka";
            this.lbMarka.Size = new System.Drawing.Size(47, 17);
            this.lbMarka.TabIndex = 16;
            this.lbMarka.Text = "marka";
            // 
            // txtMarka
            // 
            this.txtMarka.AccessibleDescription = "txtMarka";
            this.txtMarka.Location = new System.Drawing.Point(402, 349);
            this.txtMarka.Name = "txtMarka";
            this.txtMarka.Size = new System.Drawing.Size(129, 22);
            this.txtMarka.TabIndex = 15;
            // 
            // lboxSamochody
            // 
            this.lboxSamochody.AccessibleName = "lboxSamochody";
            this.lboxSamochody.AllowDrop = true;
            this.lboxSamochody.BackColor = System.Drawing.SystemColors.Window;
            this.lboxSamochody.ColumnWidth = 10;
            this.lboxSamochody.Cursor = System.Windows.Forms.Cursors.Default;
            this.lboxSamochody.DisplayMember = "rejestracja";
            this.lboxSamochody.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.lboxSamochody.FormattingEnabled = true;
            this.lboxSamochody.HorizontalExtent = 10;
            this.lboxSamochody.HorizontalScrollbar = true;
            this.lboxSamochody.ItemHeight = 16;
            this.lboxSamochody.Location = new System.Drawing.Point(19, 21);
            this.lboxSamochody.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.lboxSamochody.Name = "lboxSamochody";
            this.lboxSamochody.Size = new System.Drawing.Size(1121, 292);
            this.lboxSamochody.TabIndex = 0;
            this.lboxSamochody.ValueMember = "rejestracja";
            this.lboxSamochody.SelectedIndexChanged += new System.EventHandler(this.lboxSamochody_SelectedIndexChanged);
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.MediumAquamarine;
            this.tabPage1.Controls.Add(this.dgvMojeTransakcje);
            this.tabPage1.Controls.Add(this.btnSzczegolyTransakcji);
            this.tabPage1.Controls.Add(this.btnPokazMojeTransakcje);
            this.tabPage1.Controls.Add(this.lboxMojeTransakcje);
            this.tabPage1.Location = new System.Drawing.Point(25, 4);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Size = new System.Drawing.Size(1156, 537);
            this.tabPage1.TabIndex = 3;
            this.tabPage1.Text = "MojeTransakcje";
            // 
            // dgvMojeTransakcje
            // 
            this.dgvMojeTransakcje.AccessibleName = "dgvMojeTransakcje";
            this.dgvMojeTransakcje.AutoGenerateColumns = false;
            this.dgvMojeTransakcje.BackgroundColor = System.Drawing.Color.PowderBlue;
            this.dgvMojeTransakcje.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvMojeTransakcje.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ostatniatransakcjaDataGridViewTextBoxColumn,
            this.idautoDataGridViewTextBoxColumn,
            this.idkontrahentDataGridViewTextBoxColumn,
            this.kontrahentDataGridViewTextBoxColumn,
            this.rejestracjaDataGridViewTextBoxColumn2,
            this.cenaDataGridViewTextBoxColumn,
            this.markaDataGridViewTextBoxColumn2,
            this.silnikDataGridViewTextBoxColumn2,
            this.kolorDataGridViewTextBoxColumn2,
            this.idaktualnegostatusuDataGridViewTextBoxColumn,
            this.obecnystatusDataGridViewTextBoxColumn1,
            this.kontrahentaktualnegostatusuDataGridViewTextBoxColumn,
            this.ostatnistatuskontrahentaDataGridViewTextBoxColumn,
            this.dataDataGridViewTextBoxColumn1});
            this.dgvMojeTransakcje.DataSource = this.transakcjekontrahenciautaBindingSource2;
            this.dgvMojeTransakcje.GridColor = System.Drawing.Color.PaleTurquoise;
            this.dgvMojeTransakcje.Location = new System.Drawing.Point(25, 42);
            this.dgvMojeTransakcje.Name = "dgvMojeTransakcje";
            this.dgvMojeTransakcje.RowHeadersVisible = false;
            this.dgvMojeTransakcje.RowTemplate.Height = 24;
            this.dgvMojeTransakcje.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvMojeTransakcje.Size = new System.Drawing.Size(1071, 436);
            this.dgvMojeTransakcje.TabIndex = 49;
            this.dgvMojeTransakcje.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvMojeTransakcje_CellContentClick);
            // 
            // btnSzczegolyTransakcji
            // 
            this.btnSzczegolyTransakcji.AccessibleName = "btnSzczegolyTransakcji";
            this.btnSzczegolyTransakcji.BackColor = System.Drawing.Color.Aqua;
            this.btnSzczegolyTransakcji.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnSzczegolyTransakcji.Location = new System.Drawing.Point(238, 497);
            this.btnSzczegolyTransakcji.Name = "btnSzczegolyTransakcji";
            this.btnSzczegolyTransakcji.Size = new System.Drawing.Size(172, 23);
            this.btnSzczegolyTransakcji.TabIndex = 48;
            this.btnSzczegolyTransakcji.Text = "pokaż dane auta";
            this.btnSzczegolyTransakcji.UseVisualStyleBackColor = false;
            this.btnSzczegolyTransakcji.Click += new System.EventHandler(this.btnSzczegolyTransakcji_Click);
            // 
            // btnPokazMojeTransakcje
            // 
            this.btnPokazMojeTransakcje.AccessibleName = "btnPokazMojeTransakcje";
            this.btnPokazMojeTransakcje.BackColor = System.Drawing.Color.Aqua;
            this.btnPokazMojeTransakcje.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnPokazMojeTransakcje.Location = new System.Drawing.Point(25, 497);
            this.btnPokazMojeTransakcje.Name = "btnPokazMojeTransakcje";
            this.btnPokazMojeTransakcje.Size = new System.Drawing.Size(172, 23);
            this.btnPokazMojeTransakcje.TabIndex = 47;
            this.btnPokazMojeTransakcje.Text = "pokaż moje transakcje";
            this.btnPokazMojeTransakcje.UseVisualStyleBackColor = false;
            this.btnPokazMojeTransakcje.Click += new System.EventHandler(this.btnPokazMojeTransakcje_Click);
            // 
            // lboxMojeTransakcje
            // 
            this.lboxMojeTransakcje.AccessibleName = "lboxMojeTransakcje";
            this.lboxMojeTransakcje.ColumnWidth = 10;
            this.lboxMojeTransakcje.FormattingEnabled = true;
            this.lboxMojeTransakcje.HorizontalExtent = 10;
            this.lboxMojeTransakcje.HorizontalScrollbar = true;
            this.lboxMojeTransakcje.ItemHeight = 16;
            this.lboxMojeTransakcje.Location = new System.Drawing.Point(25, 42);
            this.lboxMojeTransakcje.Name = "lboxMojeTransakcje";
            this.lboxMojeTransakcje.ScrollAlwaysVisible = true;
            this.lboxMojeTransakcje.Size = new System.Drawing.Size(1071, 436);
            this.lboxMojeTransakcje.TabIndex = 1;
            // 
            // txtUzytkownik
            // 
            this.txtUzytkownik.AccessibleDescription = "txtUzytkownik";
            this.txtUzytkownik.Location = new System.Drawing.Point(1249, 206);
            this.txtUzytkownik.Name = "txtUzytkownik";
            this.txtUzytkownik.Size = new System.Drawing.Size(172, 22);
            this.txtUzytkownik.TabIndex = 41;
            // 
            // btnWyLogowanie
            // 
            this.btnWyLogowanie.AccessibleName = "btnWyLogowanie";
            this.btnWyLogowanie.BackColor = System.Drawing.Color.DodgerBlue;
            this.btnWyLogowanie.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnWyLogowanie.Location = new System.Drawing.Point(1249, 289);
            this.btnWyLogowanie.Name = "btnWyLogowanie";
            this.btnWyLogowanie.Size = new System.Drawing.Size(172, 23);
            this.btnWyLogowanie.TabIndex = 31;
            this.btnWyLogowanie.Text = "wyloguj";
            this.btnWyLogowanie.UseVisualStyleBackColor = false;
            this.btnWyLogowanie.Click += new System.EventHandler(this.btnWyLogowanie_Click);
            // 
            // btnLogowanie
            // 
            this.btnLogowanie.AccessibleName = "btnLogowanie";
            this.btnLogowanie.BackColor = System.Drawing.Color.DarkTurquoise;
            this.btnLogowanie.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnLogowanie.Location = new System.Drawing.Point(1249, 289);
            this.btnLogowanie.Name = "btnLogowanie";
            this.btnLogowanie.Size = new System.Drawing.Size(172, 23);
            this.btnLogowanie.TabIndex = 7;
            this.btnLogowanie.Text = "zaloguj";
            this.btnLogowanie.UseVisualStyleBackColor = false;
            this.btnLogowanie.Click += new System.EventHandler(this.btnLogowanie_Click);
            // 
            // lbHaslo
            // 
            this.lbHaslo.AccessibleName = "lbHaslo";
            this.lbHaslo.AutoSize = true;
            this.lbHaslo.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F);
            this.lbHaslo.Location = new System.Drawing.Point(1308, 228);
            this.lbHaslo.Margin = new System.Windows.Forms.Padding(0);
            this.lbHaslo.Name = "lbHaslo";
            this.lbHaslo.Size = new System.Drawing.Size(42, 17);
            this.lbHaslo.TabIndex = 29;
            this.lbHaslo.Text = "hasło";
            // 
            // mtxHaslo
            // 
            this.mtxHaslo.AccessibleName = "mtxHaslo";
            this.mtxHaslo.Location = new System.Drawing.Point(1249, 244);
            this.mtxHaslo.Name = "mtxHaslo";
            this.mtxHaslo.Size = new System.Drawing.Size(172, 22);
            this.mtxHaslo.TabIndex = 40;
            // 
            // btnZarejestruj
            // 
            this.btnZarejestruj.AccessibleName = "btnZarejestruj";
            this.btnZarejestruj.BackColor = System.Drawing.Color.DarkTurquoise;
            this.btnZarejestruj.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnZarejestruj.Location = new System.Drawing.Point(1248, 149);
            this.btnZarejestruj.Name = "btnZarejestruj";
            this.btnZarejestruj.Size = new System.Drawing.Size(172, 23);
            this.btnZarejestruj.TabIndex = 31;
            this.btnZarejestruj.Text = "zarejestruj";
            this.btnZarejestruj.UseVisualStyleBackColor = false;
            this.btnZarejestruj.Click += new System.EventHandler(this.btnZarejestruj_Click);
            // 
            // btnZamknij
            // 
            this.btnZamknij.AccessibleName = "btnZamknij";
            this.btnZamknij.BackColor = System.Drawing.Color.DarkTurquoise;
            this.btnZamknij.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnZamknij.Location = new System.Drawing.Point(1249, 75);
            this.btnZamknij.Name = "btnZamknij";
            this.btnZamknij.Size = new System.Drawing.Size(172, 23);
            this.btnZamknij.TabIndex = 8;
            this.btnZamknij.Text = "zamknij";
            this.btnZamknij.UseVisualStyleBackColor = false;
            this.btnZamknij.Click += new System.EventHandler(this.btnZamknij_Click);
            // 
            // btnWylogujAdmina
            // 
            this.btnWylogujAdmina.AccessibleName = "btnWylogujAdmina";
            this.btnWylogujAdmina.BackColor = System.Drawing.Color.DodgerBlue;
            this.btnWylogujAdmina.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnWylogujAdmina.Location = new System.Drawing.Point(1248, 458);
            this.btnWylogujAdmina.Name = "btnWylogujAdmina";
            this.btnWylogujAdmina.Size = new System.Drawing.Size(172, 23);
            this.btnWylogujAdmina.TabIndex = 81;
            this.btnWylogujAdmina.Text = "wyloguj admina";
            this.btnWylogujAdmina.UseVisualStyleBackColor = false;
            this.btnWylogujAdmina.Click += new System.EventHandler(this.btnWylogujAdmina_Click);
            // 
            // txtAdmin
            // 
            this.txtAdmin.AccessibleDescription = "txtAdmin";
            this.txtAdmin.Location = new System.Drawing.Point(1249, 375);
            this.txtAdmin.Name = "txtAdmin";
            this.txtAdmin.Size = new System.Drawing.Size(172, 22);
            this.txtAdmin.TabIndex = 46;
            // 
            // lbAdminHaslo
            // 
            this.lbAdminHaslo.AccessibleName = "lbAdminHaslo";
            this.lbAdminHaslo.AutoSize = true;
            this.lbAdminHaslo.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F);
            this.lbAdminHaslo.Location = new System.Drawing.Point(1308, 397);
            this.lbAdminHaslo.Margin = new System.Windows.Forms.Padding(0);
            this.lbAdminHaslo.Name = "lbAdminHaslo";
            this.lbAdminHaslo.Size = new System.Drawing.Size(42, 17);
            this.lbAdminHaslo.TabIndex = 44;
            this.lbAdminHaslo.Text = "hasło";
            // 
            // mtxAdmin
            // 
            this.mtxAdmin.AccessibleName = "mtxAdmin";
            this.mtxAdmin.Location = new System.Drawing.Point(1249, 413);
            this.mtxAdmin.Name = "mtxAdmin";
            this.mtxAdmin.Size = new System.Drawing.Size(172, 22);
            this.mtxAdmin.TabIndex = 45;
            // 
            // btnZarządzaj
            // 
            this.btnZarządzaj.AccessibleName = "btnZarządzaj";
            this.btnZarządzaj.BackColor = System.Drawing.Color.DarkTurquoise;
            this.btnZarządzaj.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnZarządzaj.Location = new System.Drawing.Point(1248, 458);
            this.btnZarządzaj.Name = "btnZarządzaj";
            this.btnZarządzaj.Size = new System.Drawing.Size(172, 23);
            this.btnZarządzaj.TabIndex = 9;
            this.btnZarządzaj.Text = "zarządzaj";
            this.btnZarządzaj.UseVisualStyleBackColor = false;
            this.btnZarządzaj.Click += new System.EventHandler(this.btnZarządzaj_Click_1);
            // 
            // lbWybranyKh
            // 
            this.lbWybranyKh.AccessibleName = "lbWybranyKh";
            this.lbWybranyKh.AutoSize = true;
            this.lbWybranyKh.Location = new System.Drawing.Point(1017, 12);
            this.lbWybranyKh.Name = "lbWybranyKh";
            this.lbWybranyKh.Size = new System.Drawing.Size(79, 17);
            this.lbWybranyKh.TabIndex = 81;
            this.lbWybranyKh.Text = "wybrany kh";
            // 
            // lbWybranyKhId
            // 
            this.lbWybranyKhId.AccessibleName = "lbWybranyKhId";
            this.lbWybranyKhId.AutoSize = true;
            this.lbWybranyKhId.Location = new System.Drawing.Point(1102, 12);
            this.lbWybranyKhId.Name = "lbWybranyKhId";
            this.lbWybranyKhId.Size = new System.Drawing.Size(38, 17);
            this.lbWybranyKhId.TabIndex = 82;
            this.lbWybranyKhId.Text = "kh id";
            // 
            // lbWybranyKhDlugosc
            // 
            this.lbWybranyKhDlugosc.AccessibleName = "lbWybranyKhDlugosc";
            this.lbWybranyKhDlugosc.AutoSize = true;
            this.lbWybranyKhDlugosc.Location = new System.Drawing.Point(1143, 12);
            this.lbWybranyKhDlugosc.Name = "lbWybranyKhDlugosc";
            this.lbWybranyKhDlugosc.Size = new System.Drawing.Size(76, 17);
            this.lbWybranyKhDlugosc.TabIndex = 83;
            this.lbWybranyKhDlugosc.Text = "kh dlugosc";
            // 
            // txtZnak
            // 
            this.txtZnak.AccessibleDescription = "txtZnak";
            this.txtZnak.Location = new System.Drawing.Point(1225, 31);
            this.txtZnak.Name = "txtZnak";
            this.txtZnak.Size = new System.Drawing.Size(67, 22);
            this.txtZnak.TabIndex = 84;
            // 
            // lbZnak
            // 
            this.lbZnak.AccessibleName = "lbZnak";
            this.lbZnak.AutoSize = true;
            this.lbZnak.Location = new System.Drawing.Point(1225, 11);
            this.lbZnak.Name = "lbZnak";
            this.lbZnak.Size = new System.Drawing.Size(38, 17);
            this.lbZnak.TabIndex = 85;
            this.lbZnak.Text = "znak";
            // 
            // txtKomunikat
            // 
            this.txtKomunikat.AccessibleDescription = "txtKomunikat";
            this.txtKomunikat.Location = new System.Drawing.Point(75, 32);
            this.txtKomunikat.Name = "txtKomunikat";
            this.txtKomunikat.Size = new System.Drawing.Size(473, 22);
            this.txtKomunikat.TabIndex = 86;
            // 
            // lbNazwa
            // 
            this.lbNazwa.AccessibleName = "lbNazwa";
            this.lbNazwa.AutoSize = true;
            this.lbNazwa.Location = new System.Drawing.Point(627, 382);
            this.lbNazwa.Name = "lbNazwa";
            this.lbNazwa.Size = new System.Drawing.Size(48, 17);
            this.lbNazwa.TabIndex = 76;
            this.lbNazwa.Text = "nazwa";
            // 
            // txtNazwa
            // 
            this.txtNazwa.AccessibleDescription = "txttNazwa";
            this.txtNazwa.AccessibleName = "txttNazwa";
            this.txtNazwa.Location = new System.Drawing.Point(630, 402);
            this.txtNazwa.Name = "txtNazwa";
            this.txtNazwa.Size = new System.Drawing.Size(129, 22);
            this.txtNazwa.TabIndex = 75;
            // 
            // rejestracjaDataGridViewTextBoxColumn
            // 
            this.rejestracjaDataGridViewTextBoxColumn.DataPropertyName = "rejestracja";
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.rejestracjaDataGridViewTextBoxColumn.DefaultCellStyle = dataGridViewCellStyle1;
            this.rejestracjaDataGridViewTextBoxColumn.HeaderText = "rejestracja";
            this.rejestracjaDataGridViewTextBoxColumn.Name = "rejestracjaDataGridViewTextBoxColumn";
            this.rejestracjaDataGridViewTextBoxColumn.Width = 80;
            // 
            // właścicielDataGridViewTextBoxColumn
            // 
            this.właścicielDataGridViewTextBoxColumn.DataPropertyName = "właściciel";
            this.właścicielDataGridViewTextBoxColumn.HeaderText = "właściciel";
            this.właścicielDataGridViewTextBoxColumn.Name = "właścicielDataGridViewTextBoxColumn";
            this.właścicielDataGridViewTextBoxColumn.Width = 140;
            // 
            // rokprodukcjiDataGridViewTextBoxColumn
            // 
            this.rokprodukcjiDataGridViewTextBoxColumn.DataPropertyName = "rok_produkcji";
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.rokprodukcjiDataGridViewTextBoxColumn.DefaultCellStyle = dataGridViewCellStyle2;
            this.rokprodukcjiDataGridViewTextBoxColumn.HeaderText = "rok";
            this.rokprodukcjiDataGridViewTextBoxColumn.Name = "rokprodukcjiDataGridViewTextBoxColumn";
            this.rokprodukcjiDataGridViewTextBoxColumn.Width = 50;
            // 
            // przebiegDataGridViewTextBoxColumn
            // 
            this.przebiegDataGridViewTextBoxColumn.DataPropertyName = "przebieg";
            this.przebiegDataGridViewTextBoxColumn.HeaderText = "przebieg";
            this.przebiegDataGridViewTextBoxColumn.Name = "przebiegDataGridViewTextBoxColumn";
            this.przebiegDataGridViewTextBoxColumn.Width = 80;
            // 
            // markaDataGridViewTextBoxColumn
            // 
            this.markaDataGridViewTextBoxColumn.DataPropertyName = "marka";
            this.markaDataGridViewTextBoxColumn.HeaderText = "marka";
            this.markaDataGridViewTextBoxColumn.Name = "markaDataGridViewTextBoxColumn";
            this.markaDataGridViewTextBoxColumn.Width = 80;
            // 
            // silnikDataGridViewTextBoxColumn
            // 
            this.silnikDataGridViewTextBoxColumn.DataPropertyName = "silnik";
            this.silnikDataGridViewTextBoxColumn.HeaderText = "silnik";
            this.silnikDataGridViewTextBoxColumn.Name = "silnikDataGridViewTextBoxColumn";
            this.silnikDataGridViewTextBoxColumn.Width = 90;
            // 
            // kolorDataGridViewTextBoxColumn
            // 
            this.kolorDataGridViewTextBoxColumn.DataPropertyName = "kolor";
            this.kolorDataGridViewTextBoxColumn.HeaderText = "kolor";
            this.kolorDataGridViewTextBoxColumn.Name = "kolorDataGridViewTextBoxColumn";
            this.kolorDataGridViewTextBoxColumn.Width = 80;
            // 
            // listaautBindingSource
            // 
            this.listaautBindingSource.DataSource = typeof(Gielda_Samochodowa.lista_aut);
            // 
            // idDataGridViewTextBoxColumn
            // 
            this.idDataGridViewTextBoxColumn.DataPropertyName = "id";
            this.idDataGridViewTextBoxColumn.HeaderText = "id";
            this.idDataGridViewTextBoxColumn.Name = "idDataGridViewTextBoxColumn";
            this.idDataGridViewTextBoxColumn.Visible = false;
            // 
            // nazwaDataGridViewTextBoxColumn
            // 
            this.nazwaDataGridViewTextBoxColumn.DataPropertyName = "nazwa";
            this.nazwaDataGridViewTextBoxColumn.HeaderText = "nazwa";
            this.nazwaDataGridViewTextBoxColumn.Name = "nazwaDataGridViewTextBoxColumn";
            // 
            // nazwiskoDataGridViewTextBoxColumn
            // 
            this.nazwiskoDataGridViewTextBoxColumn.DataPropertyName = "nazwisko";
            this.nazwiskoDataGridViewTextBoxColumn.HeaderText = "nazwisko";
            this.nazwiskoDataGridViewTextBoxColumn.Name = "nazwiskoDataGridViewTextBoxColumn";
            // 
            // imieDataGridViewTextBoxColumn
            // 
            this.imieDataGridViewTextBoxColumn.DataPropertyName = "imie";
            this.imieDataGridViewTextBoxColumn.HeaderText = "imie";
            this.imieDataGridViewTextBoxColumn.Name = "imieDataGridViewTextBoxColumn";
            this.imieDataGridViewTextBoxColumn.Width = 80;
            // 
            // firmaDataGridViewTextBoxColumn
            // 
            this.firmaDataGridViewTextBoxColumn.DataPropertyName = "firma";
            this.firmaDataGridViewTextBoxColumn.HeaderText = "firma";
            this.firmaDataGridViewTextBoxColumn.Name = "firmaDataGridViewTextBoxColumn";
            this.firmaDataGridViewTextBoxColumn.Width = 80;
            // 
            // telefonDataGridViewTextBoxColumn
            // 
            this.telefonDataGridViewTextBoxColumn.DataPropertyName = "telefon";
            this.telefonDataGridViewTextBoxColumn.HeaderText = "telefon";
            this.telefonDataGridViewTextBoxColumn.Name = "telefonDataGridViewTextBoxColumn";
            this.telefonDataGridViewTextBoxColumn.Width = 60;
            // 
            // emailDataGridViewTextBoxColumn
            // 
            this.emailDataGridViewTextBoxColumn.DataPropertyName = "email";
            this.emailDataGridViewTextBoxColumn.HeaderText = "email";
            this.emailDataGridViewTextBoxColumn.Name = "emailDataGridViewTextBoxColumn";
            this.emailDataGridViewTextBoxColumn.Width = 80;
            // 
            // adresDataGridViewTextBoxColumn
            // 
            this.adresDataGridViewTextBoxColumn.DataPropertyName = "adres";
            this.adresDataGridViewTextBoxColumn.HeaderText = "adres";
            this.adresDataGridViewTextBoxColumn.Name = "adresDataGridViewTextBoxColumn";
            // 
            // kodDataGridViewTextBoxColumn
            // 
            this.kodDataGridViewTextBoxColumn.DataPropertyName = "kod";
            this.kodDataGridViewTextBoxColumn.HeaderText = "kod";
            this.kodDataGridViewTextBoxColumn.Name = "kodDataGridViewTextBoxColumn";
            this.kodDataGridViewTextBoxColumn.Width = 40;
            // 
            // miastoDataGridViewTextBoxColumn
            // 
            this.miastoDataGridViewTextBoxColumn.DataPropertyName = "miasto";
            this.miastoDataGridViewTextBoxColumn.HeaderText = "miasto";
            this.miastoDataGridViewTextBoxColumn.Name = "miastoDataGridViewTextBoxColumn";
            this.miastoDataGridViewTextBoxColumn.Width = 80;
            // 
            // skypeDataGridViewTextBoxColumn
            // 
            this.skypeDataGridViewTextBoxColumn.DataPropertyName = "skype";
            this.skypeDataGridViewTextBoxColumn.HeaderText = "skype";
            this.skypeDataGridViewTextBoxColumn.Name = "skypeDataGridViewTextBoxColumn";
            this.skypeDataGridViewTextBoxColumn.Width = 80;
            // 
            // wwwDataGridViewTextBoxColumn
            // 
            this.wwwDataGridViewTextBoxColumn.DataPropertyName = "www";
            this.wwwDataGridViewTextBoxColumn.HeaderText = "www";
            this.wwwDataGridViewTextBoxColumn.Name = "wwwDataGridViewTextBoxColumn";
            this.wwwDataGridViewTextBoxColumn.Width = 80;
            // 
            // rejestrkontrahentowBindingSource
            // 
            this.rejestrkontrahentowBindingSource.DataSource = typeof(Gielda_Samochodowa.rejestr_kontrahentow);
            // 
            // idDataGridViewTextBoxColumn1
            // 
            this.idDataGridViewTextBoxColumn1.DataPropertyName = "id";
            this.idDataGridViewTextBoxColumn1.HeaderText = "id";
            this.idDataGridViewTextBoxColumn1.Name = "idDataGridViewTextBoxColumn1";
            this.idDataGridViewTextBoxColumn1.Visible = false;
            // 
            // rejestracjaDataGridViewTextBoxColumn1
            // 
            this.rejestracjaDataGridViewTextBoxColumn1.DataPropertyName = "rejestracja";
            this.rejestracjaDataGridViewTextBoxColumn1.HeaderText = "rejestracja";
            this.rejestracjaDataGridViewTextBoxColumn1.Name = "rejestracjaDataGridViewTextBoxColumn1";
            this.rejestracjaDataGridViewTextBoxColumn1.Width = 80;
            // 
            // właścicielobecnyDataGridViewTextBoxColumn
            // 
            this.właścicielobecnyDataGridViewTextBoxColumn.DataPropertyName = "właściciel_obecny";
            this.właścicielobecnyDataGridViewTextBoxColumn.HeaderText = "aktualny właściciel";
            this.właścicielobecnyDataGridViewTextBoxColumn.Name = "właścicielobecnyDataGridViewTextBoxColumn";
            // 
            // właścicielpoprzedniDataGridViewTextBoxColumn
            // 
            this.właścicielpoprzedniDataGridViewTextBoxColumn.DataPropertyName = "właściciel_poprzedni";
            this.właścicielpoprzedniDataGridViewTextBoxColumn.HeaderText = "poprzedni właściciel";
            this.właścicielpoprzedniDataGridViewTextBoxColumn.Name = "właścicielpoprzedniDataGridViewTextBoxColumn";
            // 
            // rokprodukcjiDataGridViewTextBoxColumn1
            // 
            this.rokprodukcjiDataGridViewTextBoxColumn1.DataPropertyName = "rok_produkcji";
            this.rokprodukcjiDataGridViewTextBoxColumn1.HeaderText = "rocznik";
            this.rokprodukcjiDataGridViewTextBoxColumn1.Name = "rokprodukcjiDataGridViewTextBoxColumn1";
            this.rokprodukcjiDataGridViewTextBoxColumn1.Width = 40;
            // 
            // przebiegDataGridViewTextBoxColumn1
            // 
            this.przebiegDataGridViewTextBoxColumn1.DataPropertyName = "przebieg";
            this.przebiegDataGridViewTextBoxColumn1.HeaderText = "przebieg";
            this.przebiegDataGridViewTextBoxColumn1.Name = "przebiegDataGridViewTextBoxColumn1";
            this.przebiegDataGridViewTextBoxColumn1.Width = 60;
            // 
            // markaDataGridViewTextBoxColumn1
            // 
            this.markaDataGridViewTextBoxColumn1.DataPropertyName = "marka";
            this.markaDataGridViewTextBoxColumn1.HeaderText = "marka";
            this.markaDataGridViewTextBoxColumn1.Name = "markaDataGridViewTextBoxColumn1";
            this.markaDataGridViewTextBoxColumn1.Width = 80;
            // 
            // silnikDataGridViewTextBoxColumn1
            // 
            this.silnikDataGridViewTextBoxColumn1.DataPropertyName = "silnik";
            this.silnikDataGridViewTextBoxColumn1.HeaderText = "silnik";
            this.silnikDataGridViewTextBoxColumn1.Name = "silnikDataGridViewTextBoxColumn1";
            this.silnikDataGridViewTextBoxColumn1.Width = 70;
            // 
            // kolorDataGridViewTextBoxColumn1
            // 
            this.kolorDataGridViewTextBoxColumn1.DataPropertyName = "kolor";
            this.kolorDataGridViewTextBoxColumn1.HeaderText = "kolor";
            this.kolorDataGridViewTextBoxColumn1.Name = "kolorDataGridViewTextBoxColumn1";
            this.kolorDataGridViewTextBoxColumn1.Width = 60;
            // 
            // cenawywoławczaDataGridViewTextBoxColumn
            // 
            this.cenawywoławczaDataGridViewTextBoxColumn.DataPropertyName = "cena_wywoławcza";
            this.cenawywoławczaDataGridViewTextBoxColumn.HeaderText = "cena start";
            this.cenawywoławczaDataGridViewTextBoxColumn.Name = "cenawywoławczaDataGridViewTextBoxColumn";
            this.cenawywoławczaDataGridViewTextBoxColumn.Width = 60;
            // 
            // cenasprzedażyDataGridViewTextBoxColumn
            // 
            this.cenasprzedażyDataGridViewTextBoxColumn.DataPropertyName = "cena_sprzedaży";
            this.cenasprzedażyDataGridViewTextBoxColumn.HeaderText = "cena sprzedaż";
            this.cenasprzedażyDataGridViewTextBoxColumn.Name = "cenasprzedażyDataGridViewTextBoxColumn";
            this.cenasprzedażyDataGridViewTextBoxColumn.Width = 60;
            // 
            // obecnystatusDataGridViewTextBoxColumn
            // 
            this.obecnystatusDataGridViewTextBoxColumn.DataPropertyName = "obecny_status";
            this.obecnystatusDataGridViewTextBoxColumn.HeaderText = "obecny status";
            this.obecnystatusDataGridViewTextBoxColumn.Name = "obecnystatusDataGridViewTextBoxColumn";
            this.obecnystatusDataGridViewTextBoxColumn.Width = 60;
            // 
            // dataDataGridViewTextBoxColumn
            // 
            this.dataDataGridViewTextBoxColumn.DataPropertyName = "data";
            this.dataDataGridViewTextBoxColumn.HeaderText = "data";
            this.dataDataGridViewTextBoxColumn.Name = "dataDataGridViewTextBoxColumn";
            this.dataDataGridViewTextBoxColumn.Width = 80;
            // 
            // sprzedaneautaBindingSource1
            // 
            this.sprzedaneautaBindingSource1.DataSource = typeof(Gielda_Samochodowa.sprzedane_auta);
            // 
            // ostatniatransakcjaDataGridViewTextBoxColumn
            // 
            this.ostatniatransakcjaDataGridViewTextBoxColumn.DataPropertyName = "ostatnia_transakcja";
            this.ostatniatransakcjaDataGridViewTextBoxColumn.HeaderText = "ostatnia_transakcja";
            this.ostatniatransakcjaDataGridViewTextBoxColumn.Name = "ostatniatransakcjaDataGridViewTextBoxColumn";
            this.ostatniatransakcjaDataGridViewTextBoxColumn.Visible = false;
            // 
            // idautoDataGridViewTextBoxColumn
            // 
            this.idautoDataGridViewTextBoxColumn.DataPropertyName = "id_auto";
            this.idautoDataGridViewTextBoxColumn.HeaderText = "id_auto";
            this.idautoDataGridViewTextBoxColumn.Name = "idautoDataGridViewTextBoxColumn";
            this.idautoDataGridViewTextBoxColumn.Visible = false;
            // 
            // idkontrahentDataGridViewTextBoxColumn
            // 
            this.idkontrahentDataGridViewTextBoxColumn.DataPropertyName = "id_kontrahent";
            this.idkontrahentDataGridViewTextBoxColumn.HeaderText = "id_kontrahent";
            this.idkontrahentDataGridViewTextBoxColumn.Name = "idkontrahentDataGridViewTextBoxColumn";
            this.idkontrahentDataGridViewTextBoxColumn.Visible = false;
            // 
            // kontrahentDataGridViewTextBoxColumn
            // 
            this.kontrahentDataGridViewTextBoxColumn.DataPropertyName = "kontrahent";
            this.kontrahentDataGridViewTextBoxColumn.HeaderText = "kontrahent";
            this.kontrahentDataGridViewTextBoxColumn.Name = "kontrahentDataGridViewTextBoxColumn";
            // 
            // rejestracjaDataGridViewTextBoxColumn2
            // 
            this.rejestracjaDataGridViewTextBoxColumn2.DataPropertyName = "rejestracja";
            this.rejestracjaDataGridViewTextBoxColumn2.HeaderText = "rejestracja";
            this.rejestracjaDataGridViewTextBoxColumn2.Name = "rejestracjaDataGridViewTextBoxColumn2";
            this.rejestracjaDataGridViewTextBoxColumn2.Width = 60;
            // 
            // cenaDataGridViewTextBoxColumn
            // 
            this.cenaDataGridViewTextBoxColumn.DataPropertyName = "cena";
            this.cenaDataGridViewTextBoxColumn.HeaderText = "cena";
            this.cenaDataGridViewTextBoxColumn.Name = "cenaDataGridViewTextBoxColumn";
            this.cenaDataGridViewTextBoxColumn.Width = 30;
            // 
            // markaDataGridViewTextBoxColumn2
            // 
            this.markaDataGridViewTextBoxColumn2.DataPropertyName = "marka";
            this.markaDataGridViewTextBoxColumn2.HeaderText = "marka";
            this.markaDataGridViewTextBoxColumn2.Name = "markaDataGridViewTextBoxColumn2";
            this.markaDataGridViewTextBoxColumn2.Width = 70;
            // 
            // silnikDataGridViewTextBoxColumn2
            // 
            this.silnikDataGridViewTextBoxColumn2.DataPropertyName = "silnik";
            this.silnikDataGridViewTextBoxColumn2.HeaderText = "silnik";
            this.silnikDataGridViewTextBoxColumn2.Name = "silnikDataGridViewTextBoxColumn2";
            this.silnikDataGridViewTextBoxColumn2.Width = 70;
            // 
            // kolorDataGridViewTextBoxColumn2
            // 
            this.kolorDataGridViewTextBoxColumn2.DataPropertyName = "kolor";
            this.kolorDataGridViewTextBoxColumn2.HeaderText = "kolor";
            this.kolorDataGridViewTextBoxColumn2.Name = "kolorDataGridViewTextBoxColumn2";
            this.kolorDataGridViewTextBoxColumn2.Width = 60;
            // 
            // idaktualnegostatusuDataGridViewTextBoxColumn
            // 
            this.idaktualnegostatusuDataGridViewTextBoxColumn.DataPropertyName = "id_aktualnego_statusu";
            this.idaktualnegostatusuDataGridViewTextBoxColumn.HeaderText = "id_aktualnego_statusu";
            this.idaktualnegostatusuDataGridViewTextBoxColumn.Name = "idaktualnegostatusuDataGridViewTextBoxColumn";
            this.idaktualnegostatusuDataGridViewTextBoxColumn.Visible = false;
            // 
            // obecnystatusDataGridViewTextBoxColumn1
            // 
            this.obecnystatusDataGridViewTextBoxColumn1.DataPropertyName = "obecny_status";
            this.obecnystatusDataGridViewTextBoxColumn1.HeaderText = "aktualny status";
            this.obecnystatusDataGridViewTextBoxColumn1.Name = "obecnystatusDataGridViewTextBoxColumn1";
            this.obecnystatusDataGridViewTextBoxColumn1.Width = 70;
            // 
            // kontrahentaktualnegostatusuDataGridViewTextBoxColumn
            // 
            this.kontrahentaktualnegostatusuDataGridViewTextBoxColumn.DataPropertyName = "kontrahent_aktualnego_statusu";
            this.kontrahentaktualnegostatusuDataGridViewTextBoxColumn.HeaderText = "kontrahent aktualnego statusu";
            this.kontrahentaktualnegostatusuDataGridViewTextBoxColumn.Name = "kontrahentaktualnegostatusuDataGridViewTextBoxColumn";
            // 
            // ostatnistatuskontrahentaDataGridViewTextBoxColumn
            // 
            this.ostatnistatuskontrahentaDataGridViewTextBoxColumn.DataPropertyName = "ostatni_status_kontrahenta";
            this.ostatnistatuskontrahentaDataGridViewTextBoxColumn.HeaderText = "ostatni status kontrahenta";
            this.ostatnistatuskontrahentaDataGridViewTextBoxColumn.Name = "ostatnistatuskontrahentaDataGridViewTextBoxColumn";
            this.ostatnistatuskontrahentaDataGridViewTextBoxColumn.Width = 70;
            // 
            // dataDataGridViewTextBoxColumn1
            // 
            this.dataDataGridViewTextBoxColumn1.DataPropertyName = "data";
            this.dataDataGridViewTextBoxColumn1.HeaderText = "data";
            this.dataDataGridViewTextBoxColumn1.Name = "dataDataGridViewTextBoxColumn1";
            this.dataDataGridViewTextBoxColumn1.Width = 60;
            // 
            // transakcjekontrahenciautaBindingSource2
            // 
            this.transakcjekontrahenciautaBindingSource2.DataSource = typeof(Gielda_Samochodowa.transakcje_kontrahenci_auta);
            // 
            // listawszystkichautBindingSource
            // 
            this.listawszystkichautBindingSource.DataSource = typeof(Gielda_Samochodowa.lista_wszystkich_aut);
            // 
            // sprzedaneautaBindingSource
            // 
            this.sprzedaneautaBindingSource.DataSource = typeof(Gielda_Samochodowa.sprzedane_auta);
            // 
            // transakcjekontrahenciautaBindingSource
            // 
            this.transakcjekontrahenciautaBindingSource.DataSource = typeof(Gielda_Samochodowa.transakcje_kontrahenci_auta);
            // 
            // transakcjekontrahenciautaBindingSource1
            // 
            this.transakcjekontrahenciautaBindingSource1.DataSource = typeof(Gielda_Samochodowa.transakcje_kontrahenci_auta);
            // 
            // SamochodyForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(1471, 655);
            this.Controls.Add(this.txtKomunikat);
            this.Controls.Add(this.btnZarządzaj);
            this.Controls.Add(this.btnWylogujAdmina);
            this.Controls.Add(lbLogin);
            this.Controls.Add(lbAdmin);
            this.Controls.Add(this.btnZamknij);
            this.Controls.Add(this.txtAdmin);
            this.Controls.Add(this.lbAdminHaslo);
            this.Controls.Add(this.txtUzytkownik);
            this.Controls.Add(this.mtxAdmin);
            this.Controls.Add(this.lbZnak);
            this.Controls.Add(this.lbHaslo);
            this.Controls.Add(this.btnLogowanie);
            this.Controls.Add(this.btnWyLogowanie);
            this.Controls.Add(this.mtxHaslo);
            this.Controls.Add(this.btnZarejestruj);
            this.Controls.Add(this.txtZnak);
            this.Controls.Add(this.lbWybranyKhDlugosc);
            this.Controls.Add(this.lbWybranyKhId);
            this.Controls.Add(this.lbWybranyKh);
            this.Controls.Add(this.txt_wybrany_kh_dlugosc);
            this.Controls.Add(this.lbKopiujHaslo);
            this.Controls.Add(this.lbWybranaRejestracja);
            this.Controls.Add(this.txt_wybrany_kh_id);
            this.Controls.Add(this.txtWybranaRejestracja);
            this.Controls.Add(this.rtxKomunikat);
            this.Controls.Add(this.txtZalogowanyNazwa);
            this.Controls.Add(this.txt_wybrany_kh);
            this.Controls.Add(this.lbZalogowany);
            this.Controls.Add(this.txtDlugoscRejestracji);
            this.Controls.Add(this.lbIdAuta);
            this.Controls.Add(this.mtxHasloPowtorz);
            this.Controls.Add(this.lbDlugoscRejestracji);
            this.Controls.Add(this.txtIdWybranegoAuta);
            this.Controls.Add(this.tcKontrahentTowar);
            this.Name = "SamochodyForm";
            this.Text = "Giełda Samochodowa";
            this.Load += new System.EventHandler(this.SamochodyForm_Load);
            this.Kontrahenci.ResumeLayout(false);
            this.Kontrahenci.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvKontrahenci)).EndInit();
            this.Sprzedaz.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvSprzedaz)).EndInit();
            this.tcKontrahentTowar.ResumeLayout(false);
            this.Samochody.ResumeLayout(false);
            this.Samochody.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvListaAut)).EndInit();
            this.tabPage1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvMojeTransakcje)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.listaautBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rejestrkontrahentowBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sprzedaneautaBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.transakcjekontrahenciautaBindingSource2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.listawszystkichautBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sprzedaneautaBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.transakcjekontrahenciautaBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.transakcjekontrahenciautaBindingSource1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtPrzebiegDo;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtRokDo;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtCena;
        private System.Windows.Forms.ListBox lboxSprzedaz;
        private System.Windows.Forms.Button btnListaAut;
        private System.Windows.Forms.Button btnSzukajAuta;
        private System.Windows.Forms.Button btnDodajAuto;
        private System.Windows.Forms.Button btnDaneAuta;
        private System.Windows.Forms.TextBox txtCenaMin;
        private System.Windows.Forms.TabPage Kontrahenci;
        private System.Windows.Forms.TextBox txt_wybrany_kh_dlugosc;
        private System.Windows.Forms.TextBox txt_wybrany_kh_id;
        private System.Windows.Forms.TextBox txt_wybrany_kh;
        private System.Windows.Forms.ListBox lboxKontrahenci;
        private System.Windows.Forms.Button btnZnajdzDealera;
        private System.Windows.Forms.Button btnPokazKontrahentow;
        private System.Windows.Forms.Button btnUzupelnijDaneKH;
        private System.Windows.Forms.TabPage Sprzedaz;
        private System.Windows.Forms.Button btnPokazSprzedaz;
        private System.Windows.Forms.Label lbKopiujHaslo;
        private System.Windows.Forms.Label lbRejestracja;
        private System.Windows.Forms.Label lbWybranaRejestracja;
        private System.Windows.Forms.TextBox txtWybranaRejestracja;
        private System.Windows.Forms.TextBox txtZalogowanyNazwa;
        private System.Windows.Forms.Label lbZalogowany;
        private System.Windows.Forms.RichTextBox rtxKomunikat;
        private System.Windows.Forms.TextBox txtRejestracja;
        private System.Windows.Forms.Label lbKolor;
        private System.Windows.Forms.TextBox txtKolor;
        private System.Windows.Forms.Label lbPrzebieg;
        private System.Windows.Forms.TextBox txtPrzebieg;
        private System.Windows.Forms.TextBox txtDlugoscRejestracji;
        private System.Windows.Forms.Label lbIdAuta;
        private System.Windows.Forms.MaskedTextBox mtxHasloPowtorz;
        private System.Windows.Forms.Label lbRok;
        private System.Windows.Forms.TextBox txtRok;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label lbDlugoscRejestracji;
        private System.Windows.Forms.TextBox txtIdWybranegoAuta;
        private System.Windows.Forms.TextBox txtWlasciciel;
        private System.Windows.Forms.TabControl tcKontrahentTowar;
        private System.Windows.Forms.TabPage Samochody;
        private System.Windows.Forms.Label lbSilnik;
        private System.Windows.Forms.TextBox txtSilnik;
        private System.Windows.Forms.Label lbMarka;
        private System.Windows.Forms.TextBox txtMarka;
        private System.Windows.Forms.ListBox lboxSamochody;
        private System.Windows.Forms.TextBox txtUzytkownik;
        private System.Windows.Forms.Button btnWyLogowanie;
        private System.Windows.Forms.Button btnLogowanie;
        private System.Windows.Forms.Label lbHaslo;
        private System.Windows.Forms.MaskedTextBox mtxHaslo;
        private System.Windows.Forms.Button btnZarejestruj;
        private System.Windows.Forms.Button btnZamknij;
        private System.Windows.Forms.Button btnZarządzaj;
        private System.Windows.Forms.TextBox txtAdmin;
        private System.Windows.Forms.Label lbAdminHaslo;
        private System.Windows.Forms.MaskedTextBox mtxAdmin;
        private System.Windows.Forms.Button btnWylogujAdmina;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.ListBox lboxMojeTransakcje;
        private System.Windows.Forms.Label lbWybranyKh;
        private System.Windows.Forms.Label lbWybranyKhId;
        private System.Windows.Forms.Label lbWybranyKhDlugosc;
        private System.Windows.Forms.TextBox txtZnak;
        private System.Windows.Forms.Label lbZnak;
        private System.Windows.Forms.Label lbSkype;
        private System.Windows.Forms.TextBox txtSkype;
        private System.Windows.Forms.Label lbImie;
        private System.Windows.Forms.TextBox txtImie;
        private System.Windows.Forms.Label lbKod;
        private System.Windows.Forms.TextBox txtKod;
        private System.Windows.Forms.Label lbwww;
        private System.Windows.Forms.TextBox txtWWW;
        private System.Windows.Forms.Label lbEmail;
        private System.Windows.Forms.TextBox txtEmail;
        private System.Windows.Forms.Label lbNazwisko;
        private System.Windows.Forms.TextBox txtNazwisko;
        private System.Windows.Forms.Label lbMiasto;
        private System.Windows.Forms.TextBox txtMiasto;
        private System.Windows.Forms.Label lbFirma;
        private System.Windows.Forms.TextBox txtFirma;
        private System.Windows.Forms.TextBox txtTelefon;
        private System.Windows.Forms.Label lbTelefon;
        private System.Windows.Forms.Button btnPokazMojeTransakcje;
        private System.Windows.Forms.TextBox txtKomunikat;
        private System.Windows.Forms.Button btnSzczegolyTransakcji;
        private System.Windows.Forms.Button btnSzczegolySprzedazy;
        private System.Windows.Forms.DataGridView dgvListaAut;
        private System.Windows.Forms.BindingSource listaautBindingSource;
        private System.Windows.Forms.DataGridView dgvKontrahenci;
        private System.Windows.Forms.DataGridView dgvSprzedaz;
        private System.Windows.Forms.DataGridView dgvMojeTransakcje;
        private System.Windows.Forms.DataGridViewTextBoxColumn id;
        private System.Windows.Forms.DataGridViewTextBoxColumn rejestracjaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn właścicielDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn rokprodukcjiDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn przebiegDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn markaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn silnikDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn kolorDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn najwyzsza_cena;
        private System.Windows.Forms.DataGridViewTextBoxColumn najnizsza_cena;
        private System.Windows.Forms.DataGridViewTextBoxColumn ostatnia_cena;
        private System.Windows.Forms.DataGridViewTextBoxColumn idDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn nazwaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn nazwiskoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn imieDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn firmaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn telefonDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn emailDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn adresDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn kodDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn miastoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn skypeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn wwwDataGridViewTextBoxColumn;
        private System.Windows.Forms.BindingSource rejestrkontrahentowBindingSource;
        private System.Windows.Forms.BindingSource sprzedaneautaBindingSource1;
        private System.Windows.Forms.BindingSource sprzedaneautaBindingSource;
        private System.Windows.Forms.DataGridViewTextBoxColumn idDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn rejestracjaDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn właścicielobecnyDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn właścicielpoprzedniDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn rokprodukcjiDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn przebiegDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn markaDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn silnikDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn kolorDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn cenawywoławczaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn cenasprzedażyDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn obecnystatusDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataDataGridViewTextBoxColumn;
        private System.Windows.Forms.BindingSource listawszystkichautBindingSource;
        private System.Windows.Forms.DataGridViewTextBoxColumn ostatniatransakcjaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn idautoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn idkontrahentDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn kontrahentDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn rejestracjaDataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn cenaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn markaDataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn silnikDataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn kolorDataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn idaktualnegostatusuDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn obecnystatusDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn kontrahentaktualnegostatusuDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn ostatnistatuskontrahentaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataDataGridViewTextBoxColumn1;
        private System.Windows.Forms.BindingSource transakcjekontrahenciautaBindingSource2;
        private System.Windows.Forms.BindingSource transakcjekontrahenciautaBindingSource;
        private System.Windows.Forms.BindingSource transakcjekontrahenciautaBindingSource1;
        private System.Windows.Forms.Label lbNazwa;
        private System.Windows.Forms.TextBox txtNazwa;
    }
}

