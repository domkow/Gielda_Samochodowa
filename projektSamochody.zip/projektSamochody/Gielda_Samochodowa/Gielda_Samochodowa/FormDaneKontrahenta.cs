﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Gielda_Samochodowa
{
    public partial class FormDaneKontrahenta : Form
    {
        public FormDaneKontrahenta(int wybrany_kh_id, int edycja, bool administracja)
        {
            InitializeComponent();
            if (administracja == true)
            {
                txtAdministracja.Text = "Administrator";
            }
            else
            {
                txtAdministracja.Text = "";
            }
            //txtUprawnienia.Text = edycja.ToString();
            if (edycja == 0)
            {
                btnPoprawImie.Hide();
                btnPoprawNazwisko.Hide();
                btnPoprawAdres.Hide();
                btnPoprawFirma.Hide();
                btnPoprawMiasto.Hide();
                btnPoprawTelefon.Hide();
                btnPoprawEmail.Hide();
                btnPoprawWWW.Hide();
                btnPoprawSkype.Hide();
                btnZapiszDaneKh.Hide();
                btnPoprawKod.Hide();
            }
            txtId.Text = wybrany_kh_id.ToString();
        }

        //int id_obiektu = 0;
        DBSamochodyEntities baza = new DBSamochodyEntities();

        private void FormDaneKontrahenta_Load(object sender, EventArgs e)
        {
            pokaz_wszystkie_dane();
            administracja_status();
        }

        public void administracja_status()
        {
            if (txtAdministracja.Text == "Administrator")
            {
                odkryj_obiekty_admin();
            }
            else
            {
                ukryj_obiekty_admin();
            }
        }


        public void odkryj_obiekty_admin()
        {
            txtAdministracja.Show();
            txtId.Show();
            txtUprawnienia.Show();
            lbUprawnienia.Show();
            lbKhId.Show();
            lbAdministracja.Show();
        }

        public void ukryj_obiekty_admin()
        {
            txtAdministracja.Hide();
            txtId.Hide();
            txtUprawnienia.Hide();
            lbUprawnienia.Hide();
            lbKhId.Hide();
            lbAdministracja.Hide();
        }


        public void dodaj_dane_kontrahenta(TextBox pole_danej)
        {
            //funkcja nieużywana - ale działa
            Dane_Kontrahenta informacja = new Dane_Kontrahenta();
            int.TryParse(txtId.Text, out int id_obiektu);
            int.TryParse(pole_danej.Tag.ToString(), out int typ_danej);
            if (pole_danej.Text != "")
            {
                informacja.id_kontrahent = id_obiektu;
                informacja.id_typ_danej = typ_danej;
                informacja.wartosc = pole_danej.Text.Trim();
                informacja.priorytet = 1;
                informacja.pokaz = 1;

                try

                {
                    baza.Dane_Kontrahenta.Add(informacja);
                    baza.SaveChanges();
                }

                catch (DataException problem)
                {

                    rtxKomunikatDane.Text = "Ta informacja już istnieje. Zrestartuj aplikację i wprowadź inne dane";
                    problem.GetBaseException();
                    problem.InnerException.Data.Clear();
                    problem.Data.Clear();

                    System.Data.SqlClient.SqlConnection.ClearAllPools();


                }
                catch (Exception ex)
                {
                    rtxKomunikatDane.Text = ex.ToString();
                    ex.Data.Clear();

                }

            }
        }

        public void pokaz_dane_kontrahenta_unikalne(TextBox pole_danej)
        {
            
            int.TryParse(txtId.Text, out int id_kontrahenta);
            var kontrahenci = baza.rejestr_kontrahentow.Where(znajdz => znajdz.id == id_kontrahenta);
            foreach (rejestr_kontrahentow wiersz in kontrahenci)
            {
                pole_danej.Text = wiersz.nazwa.ToString();

            }

        }




        public void pokaz_dane_kontrahenta_teksty(TextBox pole_danej, NumericUpDown priorytet)
        {


            int.TryParse(pole_danej.Tag.ToString(), out int typ_danej);
            int.TryParse(txtId.Text, out int id_obiektu);
            int priorytet_wpisu = decimal.ToInt32(priorytet.Value);
            //int.TryParse(pole_danej.Tag.ToString(), out int typ_danej);
            //var wybrany_kh = baza.Kontrahenci.Where(znajdz => znajdz.id == id_obiektu);
            var dane_kontrahenta = baza.Dane_Kontrahenta.Where(znajdz => znajdz.id_kontrahent == id_obiektu && znajdz.id_typ_danej == typ_danej && znajdz.priorytet == priorytet_wpisu);
            foreach (Dane_Kontrahenta informacja in dane_kontrahenta)
            {
                try
                {
                    pole_danej.Text = informacja.wartosc.Trim();
                }
                catch (DataException problem)
                {
                    pole_danej.Text = "";
                    problem.GetBaseException();
                    problem.InnerException.Data.Clear();
                    problem.Data.Clear();
                    System.Data.SqlClient.SqlConnection.ClearAllPools();
                }
                catch (Exception ex)
                {
                    rtxKomunikatDane.Text = ex.ToString();
                    ex.Data.Clear();
                }
            }
        }

        public void pokaz_wszystkie_dane()
        {
            pokaz_dane_kontrahenta_teksty(txtImie, numPriorityImie);
            pokaz_dane_kontrahenta_teksty(txtNazwa, numPriorityNazwisko);
            pokaz_dane_kontrahenta_teksty(txtFirma, numPriorityFirma);
            pokaz_dane_kontrahenta_teksty(txtEmail, numPriorityEmail);
            pokaz_dane_kontrahenta_teksty(txtTelefon, numPriorityTelefon);
            pokaz_dane_kontrahenta_teksty(txtMiasto, numPriorityMiasto);
            pokaz_dane_kontrahenta_teksty(txtAdres, numPriorityAdres);
            pokaz_dane_kontrahenta_teksty(txtKod, numPriorityKod);
            pokaz_dane_kontrahenta_teksty(txtSkype, numPrioritySkype);
            pokaz_dane_kontrahenta_teksty(txtWWW, numPriorityWWW);
            pokaz_dane_kontrahenta_unikalne(txtLogin);
        }

       
        public void zerowanie_danych(TextBox pole_danej, NumericUpDown priorytet)
        {
            pole_danej.Text = "";
            priorytet.Value = 1;
        }

        public void dodaj_dane_kontrahenta_procedura(TextBox pole_danej, int unikalne, NumericUpDown priorytet)
        {
            int dane = 0;
            int.TryParse(txtId.Text, out int id_obiektu);
            int.TryParse(pole_danej.Tag.ToString(), out int typ_danej);
            int priorytet_wpisu;



            if (pole_danej.Text != "")
            {
                try

                {
                    if (unikalne == 0)
                    {
                        priorytet_wpisu = decimal.ToInt32(priorytet.Value);
                        dane = baza.Dodaj_Dane_Obiektu_Tekst(id_obiektu, typ_danej, pole_danej.Text.Trim(), priorytet_wpisu, 1);
                    }
                    else
                    {
                        dane = baza.Dodaj_Dane_Obiektu_Tekst(id_obiektu, typ_danej, pole_danej.Text.Trim(), 1, 1);
                    }

                }

                catch (DataException problem)
                {

                    rtxKomunikatDane.Text = "Ta informacja już istnieje. Zrestartuj aplikację i wprowadź inne dane";
                    problem.GetBaseException();
                    problem.InnerException.Data.Clear();
                    problem.Data.Clear();

                    System.Data.SqlClient.SqlConnection.ClearAllPools();


                }
                catch (Exception ex)
                {
                    rtxKomunikatDane.Text = ex.ToString();
                    ex.Data.Clear();

                }



            }
        }


        public void popraw_dane_kontrahenta_procedura(TextBox pole_danej, int unikalne, NumericUpDown priorytet)
        {
            int dane = 0;
            int.TryParse(txtId.Text, out int id_obiektu);
            int.TryParse(pole_danej.Tag.ToString(), out int typ_danej);
            int priorytet_wpisu;



            if (pole_danej.Text != "")
            {
                try

                {
                    if (unikalne == 0)
                    {
                        priorytet_wpisu = decimal.ToInt32(priorytet.Value);
                        dane = baza.Edycja_Danych_Kontrahenta(pole_danej.Text.Trim(), id_obiektu, typ_danej, priorytet_wpisu);
                    }
                    else
                    {
                        dane = baza.Edycja_Danych_Kontrahenta(pole_danej.Text.Trim(), id_obiektu, typ_danej, 1);
                    }
                    rtxKomunikatDane.Text = "parametry edycji: wartość: " + pole_danej.Text +
                       " kontrahent id: " + id_obiektu + " typ danej id: " + typ_danej;
                }

                catch (DataException problem)
                {

                    rtxKomunikatDane.Text = "Ta informacja już istnieje. Zrestartuj aplikację i wprowadź inne dane";
                    problem.GetBaseException();
                    problem.InnerException.Data.Clear();
                    problem.Data.Clear();

                    System.Data.SqlClient.SqlConnection.ClearAllPools();


                }
                catch (Exception ex)
                {
                    rtxKomunikatDane.Text = ex.ToString();
                    ex.Data.Clear();

                }



            }
        }



        private void btnZapiszDaneKh_Click_1(object sender, EventArgs e)
        {

            dodaj_dane_kontrahenta_procedura(txtAdres, 0, numPriorityAdres);
            dodaj_dane_kontrahenta_procedura(txtNazwa, 0, numPriorityNazwisko);
            dodaj_dane_kontrahenta_procedura(txtImie, 0, numPriorityImie);
            dodaj_dane_kontrahenta_procedura(txtFirma, 0, numPriorityFirma);
            dodaj_dane_kontrahenta_procedura(txtTelefon, 0, numPriorityTelefon);
            dodaj_dane_kontrahenta_procedura(txtEmail, 0, numPriorityEmail);
            dodaj_dane_kontrahenta_procedura(txtWWW, 0, numPriorityWWW);
            dodaj_dane_kontrahenta_procedura(txtKod, 0, numPriorityKod);
            dodaj_dane_kontrahenta_procedura(txtMiasto, 0, numPriorityMiasto);
            dodaj_dane_kontrahenta_procedura(txtSkype, 0, numPrioritySkype);


        }

        private void btnWyczyscDaneKh_Click(object sender, EventArgs e)
        {
            zerowanie_danych(txtAdres, numPriorityAdres);
            zerowanie_danych(txtNazwa, numPriorityNazwisko);
            zerowanie_danych(txtImie, numPriorityImie);
            zerowanie_danych(txtFirma, numPriorityFirma);
            zerowanie_danych(txtTelefon, numPriorityTelefon);
            zerowanie_danych(txtEmail, numPriorityEmail);
            zerowanie_danych(txtSkype, numPrioritySkype);
            zerowanie_danych(txtWWW, numPriorityWWW);
            zerowanie_danych(txtMiasto, numPriorityMiasto);
            zerowanie_danych(txtKod, numPriorityKod);

        }

        private void btnZamknijDaneKh_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnPoprawImie_Click(object sender, EventArgs e)
        {
            popraw_dane_kontrahenta_procedura(txtImie, 0, numPriorityImie);
        }

        private void btnPoprawNazwisko_Click(object sender, EventArgs e)
        {
            popraw_dane_kontrahenta_procedura(txtNazwa, 0, numPriorityNazwisko);
        }

        private void btnPoprawTelefon_Click(object sender, EventArgs e)
        {
            popraw_dane_kontrahenta_procedura(txtTelefon, 0, numPriorityTelefon);
        }

        private void btnPoprawEmail_Click(object sender, EventArgs e)
        {
            popraw_dane_kontrahenta_procedura(txtEmail, 0, numPriorityEmail);
        }

        private void btnPoprawFirma_Click(object sender, EventArgs e)
        {
            popraw_dane_kontrahenta_procedura(txtFirma, 0, numPriorityFirma);
        }

        private void btnPokazDaneKh_Click(object sender, EventArgs e)
        {
            pokaz_wszystkie_dane();
        }

        private void btnPoprawWWW_Click(object sender, EventArgs e)
        {
            popraw_dane_kontrahenta_procedura(txtWWW, 0, numPriorityWWW);
        }

        private void txtId_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnZamknijDaneKh_Click_1(object sender, EventArgs e)
        {
            Close();
        }

        private void btnPoprawSkype_Click(object sender, EventArgs e)
        {
            popraw_dane_kontrahenta_procedura(txtSkype, 0, numPrioritySkype);
        }

        private void btnPoprawKod_Click(object sender, EventArgs e)
        {
            popraw_dane_kontrahenta_procedura(txtKod, 0, numPriorityKod);
        }

        private void btnPoprawMiasto_Click(object sender, EventArgs e)
        {
            popraw_dane_kontrahenta_procedura(txtMiasto, 0, numPriorityMiasto);
        }

        private void btnPoprawAdres_Click(object sender, EventArgs e)
        {
            popraw_dane_kontrahenta_procedura(txtAdres, 0, numPriorityAdres);
        }
    }
}
