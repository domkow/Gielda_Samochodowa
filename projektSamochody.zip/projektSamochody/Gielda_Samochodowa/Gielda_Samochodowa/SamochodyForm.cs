﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Gielda_Samochodowa
{
    public partial class SamochodyForm : Form
    {
        public SamochodyForm()
        {
            InitializeComponent();
            txtKomunikat.Text = "Witamy na Auto Giełdzie ! Transakcje tylko dla zalogowanych";
            mtxHaslo.Show();
            mtxHasloPowtorz.Hide();
            btnDodajAuto.Hide();
            ukryj_obiekty_admin();
            btnWyLogowanie.Hide();
           
            btnDaneAuta.Hide();
            btnWylogujAdmina.Hide();
            pokaz_auta();
            pokaz_sprzedaz();
            pokaz_kontehentow();
            btnSzczegolySprzedazy.Hide();
            btnPokazMojeTransakcje.Hide();
            btnSzczegolyTransakcji.Hide();

        }
        string admin_haslo = "";
        string admin_login = "";
        bool administracja = false;
        int wybrany_kh_id = 0;
        
        string wybrane_auto_rejestracja;
        int wybrane_auto_id = 0;

        DBSamochodyEntities baza = new DBSamochodyEntities();
        
        int zalogowany_kh_id = 0;
        int zalogowany_kh_typ = 0;

        public int zalogowany_kontrahent(string haslo, string nazwa, int parametr)
        {
            int moj_parametr = 0;
            Kontrahenci zalogowany_kontrahent = new Kontrahenci();

            var zalogowany = baza.Kontrahenci.Where(znajdz => znajdz.haslo == haslo && znajdz.nazwa == nazwa);
            foreach (Kontrahenci wiersz in zalogowany)
            {
                switch (parametr)
                {
                    case 1:
                        moj_parametr = wiersz.id;
                        break;
                    case 2:
                        moj_parametr = wiersz.typ;
                        break;
                }

            }
            return moj_parametr;
        }
        public string typ_kontrahenta(int id)
        {
            string typ_kh = "";
            Typ_Obiektu typ = new Typ_Obiektu();
            var typ_obiektu = baza.Typ_Obiektu.Where(znajdz => znajdz.id == id);

            return typ_kh;
        }

        public void logowanie(string haslo, string nazwa)
        {
            try
            {
                if (haslo.Length > 0)
                {
                    zalogowany_kh_id = zalogowany_kontrahent(haslo, nazwa, 1);

                    
                    if (zalogowany_kh_id > 0)
                    {
                        zalogowany_kh_typ = zalogowany_kontrahent(haslo, nazwa, 2);
                        Kontrahenci kontrahent = new Kontrahenci();
                        string moja_nazwa = "";
                        var zalogowany = baza.Kontrahenci.Where(znajdz => znajdz.id == zalogowany_kh_id);
                        foreach (Kontrahenci wiersz in zalogowany)
                        {
                            moja_nazwa = wiersz.nazwa;
                            txtZalogowanyNazwa.Text = moja_nazwa;
                        }
                        if (zalogowany_kh_typ == 2)
                        {
                            btnDodajAuto.Show();
                        }
                        lbHaslo.Hide();
                        mtxHaslo.Hide();
                        lbHaslo.Hide();
                        txtUzytkownik.Hide();
                        txtUzytkownik.Text = "";
                        txtKomunikat.Text = "siema " + moja_nazwa + "! Witamy na auto giełdzie!";
                        btnWyLogowanie.Show();
                        btnLogowanie.Hide();
                        pokaz_moje_transakcje();
                    }
                }
                else
                {
                    MessageBox.Show("Jeśli jesteś zarajestrowany w pole hasła wpisz swoje hasło i kliknij zaloguj" +
                 "Jeśli nie jesteś zarejestrowany, zarejestruj się");
                }
            }
            catch (Exception ex)
            {
                rtxKomunikat.Text = ex.ToString();
            }

        }


        public void wylogowanie()
        {
            zalogowany_kh_id = 0;
            zalogowany_kh_typ = 0;
            txtKomunikat.Text = "Witamy na Auto Giełdzie ! Transakcje tylko dla zalogowanych";
            mtxHaslo.Text = "";
            mtxHasloPowtorz.Text = "";
            mtxHaslo.Show();
           
            lbHaslo.Show();
            
            btnDodajAuto.Hide();
            btnWyLogowanie.Hide();
            btnLogowanie.Show();
            
            txtUzytkownik.Show();
        }

        public void logowanie_admin(string haslo, string nazwa)
        {
            try
            {
                if (haslo.Length > 0)
                {
                    if (zalogowany_kh_id > 0)
                    {
                        Kontrahenci kontrahent = new Kontrahenci();
                        string moja_nazwa = "";
                        var zalogowany = baza.Kontrahenci.Where(znajdz => znajdz.id == 73);
                        foreach (Kontrahenci wiersz in zalogowany)
                        {
                            moja_nazwa = wiersz.nazwa;
                           txtAdmin.Text = moja_nazwa;
                        }
                        lbAdminHaslo.Hide();
                        mtxAdmin.Hide();
                        odkryj_obiekty_admin();
                    }
                    else
                    {
                        txtAdmin.Text = "";
                    }
                }
                else
                {
                    txtAdmin.Text = "";
                    ukryj_obiekty_admin();
                }
                
            }
            catch (Exception ex)
            {
                rtxKomunikat.Text = ex.ToString();
                txtAdmin.Text = "";
            }

        }
        public void wylogowanie_admin()
        {
            txtAdmin.Text = "";
            mtxAdmin.Text = "";
            txtAdmin.Show();
            mtxAdmin.Show();
            ukryj_obiekty_admin();
        }

        public void odkryj_obiekty_admin()
        {
            txtDlugoscRejestracji.Show();
            txtIdWybranegoAuta.Show();
            txtWybranaRejestracja.Show();
            lbDlugoscRejestracji.Show();
            lbWybranaRejestracja.Show();
            lbZalogowany.Show();
            lbKopiujHaslo.Show();
            lbIdAuta.Show();
            txt_wybrany_kh.Show();
            txt_wybrany_kh_dlugosc.Show();
            lbWybranyKhId.Show();
            lbWybranyKh.Show();
            txt_wybrany_kh_dlugosc.Show();
            lbWybranyKhDlugosc.Show();
            txt_wybrany_kh_id.Show();
            txtZnak.Show();
            lbZnak.Show();
            rtxKomunikat.Show();
            txtZalogowanyNazwa.Show();
        }

        public void ukryj_obiekty_admin()
        {
            txtDlugoscRejestracji.Hide();
            txtIdWybranegoAuta.Hide();
            txtWybranaRejestracja.Hide();
            lbDlugoscRejestracji.Hide();
            lbWybranaRejestracja.Hide();
            lbZalogowany.Hide();
            lbKopiujHaslo.Hide();
            lbIdAuta.Hide();
            txt_wybrany_kh.Hide();
            txt_wybrany_kh_dlugosc.Hide();
            lbWybranyKh.Hide();
            lbWybranyKhId.Hide();
            txt_wybrany_kh_dlugosc.Hide();
            lbWybranyKhDlugosc.Hide();
            txt_wybrany_kh_id.Hide();
            txtZnak.Hide();
            lbZnak.Hide();
            rtxKomunikat.Hide();
            txtZalogowanyNazwa.Hide();
        }



        public int definiuj_swoj_typ(string typ)
        {

            int moj_typ = 0;
            Typ_Obiektu wybrany_typ_kontrahenta = new Typ_Obiektu();
            var wybrany_typ = baza.Typ_Obiektu.Where(znajdz => znajdz.nazwa == typ);
            foreach (Typ_Obiektu wiersz in wybrany_typ)
            {
                moj_typ = wiersz.id;
            }
            return moj_typ;
        }

        public void nowe_auto()
        {
            Auta samochod = new Auta();
            {
                samochod.rejestracja = txtRejestracja.Text.Trim();
                samochod.wlasciciel = zalogowany_kh_id;
                float.TryParse(txtPrzebieg.Text, out float przebieg);
                samochod.przebieg = przebieg;
                int.TryParse(txtRok.Text, out int rok_produkcji);
                samochod.rok_produkcji = rok_produkcji;
            };
            rtxKomunikat.Text = "";
            if (samochod.rejestracja == "")
            {
                rtxKomunikat.Text = "Wpisz w pola tekstowe dane rejestrowanego auta i kliknij w dodaj auto";
            }
            else
            {
                try

                {
                    baza.Auta.Add(samochod);
                    baza.SaveChanges();
                }

                catch (DataException problem)
                {

                    rtxKomunikat.Text = "Taki numer rejestracyjny już istnieje w serwisie. Zrestartuj aplikację i wprowadź inne dane";
                    problem.GetBaseException();
                    problem.InnerException.Data.Clear();
                    problem.Data.Clear();
                    System.Data.SqlClient.SqlConnection.ClearAllPools();
                }
                catch (Exception ex)
                {
                    rtxKomunikat.Text = ex.ToString();
                    ex.Data.Clear();

                }

            }

        }



        public void pokaz_auta()
        {
            
            lista_aut samochod = new lista_aut();
            var wyniki_szukania = baza.lista_aut.Where(znajdz => znajdz.rejestracja != "");
          
            dgvListaAut.DataSource = wyniki_szukania.ToArray().ToList();
            dgvMojeTransakcje.Update();
        }

        public void pokaz_moje_transakcje()
        { 
           transakcje_kontrahenci_auta transakcje = new transakcje_kontrahenci_auta();
             var wyniki_szukania = baza.transakcje_kontrahenci_auta.Where(znajdz => znajdz.id_kontrahent ==zalogowany_kh_id);
            dgvMojeTransakcje.DataSource = wyniki_szukania.ToArray().ToList();
        }


        public void pokaz_kontehentow()
        {
      
            rejestr_kontrahentow dealer = new rejestr_kontrahentow();
            var lista_dealerow = baza.rejestr_kontrahentow.Where(znajdz => znajdz.id > 0);
            dgvKontrahenci.DataSource = lista_dealerow.ToArray().ToList();
            dgvKontrahenci.Update();

        }

        public void pokaz_sprzedaz()
        {
            
            sprzedane_auta samochod = new sprzedane_auta();
            var wyniki_szukania = baza.sprzedane_auta.Where(znajdz => znajdz.rejestracja != "");
            dgvSprzedaz.DataSource = wyniki_szukania.ToArray().ToList();
            dgvSprzedaz.Update();
        }

        private void Kontrahenci_Click(object sender, EventArgs e)
        {

        }

        private void btnPokazKontrahentow_Click(object sender, EventArgs e)
        {
            pokaz_kontehentow();
        }

        private void btnDodajAuto_Click(object sender, EventArgs e)
        {
            int wybrane_auto_id = 0;
            float wybrane_auto_cena = 0;
            int edycja = 1, dodawanie = 1, licytacja = 1, czy_kontrahent_ostatniej_transakcji = 1;
            string status_auta = "";
         if (txtAdmin.Text == "Administrator")
            {
                administracja = true;
            }
         else
            {
                administracja = false;
            }
            DaneSamochodu pokaz = new DaneSamochodu(wybrane_auto_id, wybrane_auto_cena, zalogowany_kh_id, edycja, dodawanie, licytacja, status_auta, czy_kontrahent_ostatniej_transakcji, administracja);
            pokaz.ShowDialog();

        }

       

        private void btnZamknij_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnLogowanie_Click(object sender, EventArgs e)
        {
            string haslo = mtxHaslo.Text;
            string uzytkownik = txtUzytkownik.Text;
            logowanie(haslo, uzytkownik);
            btnDaneAuta.Show();
            //pokaz_moje_transakcje();
            btnSzczegolySprzedazy.Show();
            btnPokazMojeTransakcje.Show();
            btnSzczegolyTransakcji.Show();
        }

        private void mtxHaslo_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void btnWyLogowanie_Click(object sender, EventArgs e)
        {
            wylogowanie();
        }

        private void btnListaAut_Click(object sender, EventArgs e)
        {

            pokaz_auta();
        }


        public int id_wybranego_kh()
        {
            if(dgvKontrahenci.SelectedRows.Count==0)
            {
                dgvKontrahenci.Rows[0].Selected = true;
            }

            Kontrahenci wybrany_kontrahent = new Kontrahenci();
            int.TryParse(dgvKontrahenci.SelectedRows[0].Cells[0].Value.ToString(), out wybrany_kh_id);
           
            return wybrany_kh_id;
        }


        public int czy_to_wlasciciel_auta(int id_auta, int id_kontrahent)
        {
            int wynik = 0;

            var wybrane_auto = baza.Auta.Where(znajdz => znajdz.id == id_auta);
            foreach (Auta autko in wybrane_auto)
            {
                if (autko.wlasciciel == id_kontrahent)
                {
                    wynik = 1;
                }
            }
            return wynik;
        }


        private void btnUzupelnijDaneKH_Click(object sender, EventArgs e)
        {
            if (dgvKontrahenci.Rows.Count > 0)
            {
                wybrany_kh_id = id_wybranego_kh();
                int edycja = 0;
                txt_wybrany_kh_id.Text = wybrany_kh_id.ToString();
                if (wybrany_kh_id == zalogowany_kh_id)
                {
                    edycja = 1;
                }
                if (txtAdmin.Text == "Administrator")
                {
                    administracja = true;
                }
                else
                {
                    administracja = false;
                }
                FormDaneKontrahenta pokaz = new FormDaneKontrahenta(wybrany_kh_id, edycja, administracja);
                pokaz.ShowDialog();
            }
        }

        private void lboxKontrahenci_SelectedIndexChanged(object sender, EventArgs e)
        {
        }

        private void SamochodyForm_Load(object sender, EventArgs e)
        {
            pokaz_auta();
            if(dgvListaAut.Rows.Count>0)
            {
                dgvListaAut.Rows[0].Selected = true;
            }
        }

        private void btnUzupelnijDane_Click(object sender, EventArgs e)
        {
            wybrany_kh_id = zalogowany_kh_id;
            int edycja = 1;
            txt_wybrany_kh_id.Text = wybrany_kh_id.ToString();
            FormDaneKontrahenta pokaz = new FormDaneKontrahenta(wybrany_kh_id, edycja,administracja);
            pokaz.ShowDialog();
        }

        public int id_wybranego_auta()
        {
          
            wybrane_auto_rejestracja = dgvListaAut.SelectedRows[0].Cells[1].Value.ToString();
            wybrane_auto_rejestracja = wybrane_auto_rejestracja.TrimEnd();

            int.TryParse(dgvListaAut.SelectedRows[0].Cells[0].Value.ToString(), out wybrane_auto_id);

            
            return wybrane_auto_id;
        }

        private void btnDaneAuta_Click(object sender, EventArgs e)
        {

            wybrane_auto_id = id_wybranego_auta();
            double wybrane_auto_cena = 0;
            int edycja = 0;
            int dodawanie = 0;
            int licytacja = 0;
            int czy_kontrahent_ostatniej_transakcji = 0;
            string status_auta = aktualny_status_auta(wybrane_auto_id);
            txtIdWybranegoAuta.Text = wybrane_auto_id.ToString();
            edycja = czy_to_wlasciciel_auta(wybrane_auto_id, zalogowany_kh_id);
            if (txtAdmin.Text == "Administrator")
            {
                administracja = true;
            }
            else
            {
                administracja = false;
            }
            lista_aut samochod = new lista_aut();

            var wybrane_auto = baza.lista_aut.Where(znajdz => znajdz.id == wybrane_auto_id);
            foreach (lista_aut autko in wybrane_auto)
            {
                wybrane_auto_cena = autko.ostatnia_cena;
            }

            if (kontrahent_ostatniej_transakcji(wybrane_auto_id) == zalogowany_kh_id)
            {
                czy_kontrahent_ostatniej_transakcji = 1;
            }


            if (zalogowany_kh_typ == 1)
            {
                licytacja = 1;
            }
            if (zalogowany_kh_typ == 2)
            {
                dodawanie = 1;
                if (edycja == 1)
                { licytacja = 1; }
            }
            DaneSamochodu pokaz = new DaneSamochodu(wybrane_auto_id, wybrane_auto_cena, zalogowany_kh_id, edycja, dodawanie, licytacja, status_auta, czy_kontrahent_ostatniej_transakcji, administracja);
            pokaz.ShowDialog();
        }

        public string text_from_box(TextBox tekstbox, string wartosc_domyslna)
        {
            string tekst = wartosc_domyslna;
            if (tekstbox.Text.Length > 0)
            {
                tekst = tekstbox.Text;
            }
            return tekst;
        }

        public string aktualny_status_auta(int auto_id)
        {
            string status_auta = "licytacja";
            var statusy = baza.auta_ostatnie_transakcje_statusy.Where(znajdz => znajdz.id_auto == wybrane_auto_id);
            foreach (auta_ostatnie_transakcje_statusy aktualne_statusy in statusy)
            {
                status_auta = aktualne_statusy.nazwa;
            }
            return status_auta;
        }

        public int kontrahent_ostatniej_transakcji(int auto_id)
        {
            int kontrahent = 0;
            var statusy = baza.auta_ostatnie_transakcje_statusy.Where(znajdz => znajdz.id_auto == wybrane_auto_id);
            foreach (auta_ostatnie_transakcje_statusy aktualne_statusy in statusy)
            {
                kontrahent = aktualne_statusy.id_kontrahent;
            }
            return kontrahent;
        }


        public int text_from_box_int(TextBox tekstbox, int wartosc_domyslna)
        {
            int tekst = wartosc_domyslna;
            if (tekstbox.Text.Length > 0)
            {
                int.TryParse(tekstbox.Text, out tekst); ;
            }
            return tekst;
        }

        public float text_from_box_float(TextBox tekstbox, float wartosc_domyslna)
        {
            float tekst = wartosc_domyslna;
            if (tekstbox.Text.Length > 0)
            {
                float.TryParse(tekstbox.Text, out tekst); ;
            }
            return tekst;
        }



        public void znajdz_auto()
        {
            string wlasciciel, marka, silnik, kolor, rejestracja;
            int rok_od, rok_do;
            float przebieg_od, przebieg_do, cena_od, cena_do;
            marka = text_from_box(txtMarka, "");
            silnik = text_from_box(txtSilnik, "");
            kolor = text_from_box(txtKolor, "");
            wlasciciel = text_from_box(txtWlasciciel, "");
            rejestracja = text_from_box(txtRejestracja, "");
            przebieg_od = text_from_box_float(txtPrzebieg, 0);
            przebieg_do = text_from_box_float(txtPrzebiegDo, 999999999);
            cena_od = text_from_box_float(txtCenaMin, 0);
            cena_do = text_from_box_float(txtCena, 999999999);
            rok_od = text_from_box_int(txtRok, 1900);
            rok_do = text_from_box_int(txtRokDo, 2022);
            rtxKomunikat.Text = marka + " " + przebieg_od + " " + cena_do + " " + rejestracja + " " + rok_do + " " + wlasciciel + " " + rejestracja;
            lista_aut samochod = new lista_aut();
           
            var wyniki_szukania =
              from lista_aut in baza.lista_aut
              where lista_aut.rejestracja.Contains(rejestracja)
              && lista_aut.właściciel.Contains(wlasciciel)
              && lista_aut.kolor.Contains(kolor)
              && lista_aut.silnik.Contains(silnik)
               && lista_aut.marka.Contains(marka)
               && lista_aut.rok_produkcji >= rok_od && lista_aut.rok_produkcji <= rok_do
              && lista_aut.przebieg >= przebieg_od && lista_aut.przebieg <= przebieg_do
            && lista_aut.ostatnia_cena >= cena_od && lista_aut.ostatnia_cena <= cena_do
              select lista_aut;

            dgvListaAut.DataSource = wyniki_szukania.ToArray().ToList();
            dgvListaAut.Update();
            if(dgvListaAut.Rows.Count>0)
            {
                dgvListaAut.Rows[0].Selected = true;
                wybrane_auto_id = id_wybranego_auta();
            }
            
        }

        private void lboxSamochody_SelectedIndexChanged(object sender, EventArgs e)
        {
          //  wybrane_auto_id = id_wybranego_auta();
        }

        private void mtxHasloPowtorz_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {
            if (mtxHaslo.Text != mtxHasloPowtorz.Text)
                rtxKomunikat.Text = "hasła nie są identyczne";
        }

        private void btnSzukajAuta_Click(object sender, EventArgs e)
        {
            znajdz_auto();
        }

        private void Samochody_Click(object sender, EventArgs e)
        {

        }

        private void btnZarejestruj_Click(object sender, EventArgs e)
        {
            RejestracjaUzytkownika pokaz = new RejestracjaUzytkownika();
            pokaz.ShowDialog();
        }

        private void btnPokazSprzedaz_Click(object sender, EventArgs e)
        {
            pokaz_sprzedaz();
        }

        private void lboxSprzedaz_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

 

        private void btnZarządzaj_Click_1(object sender, EventArgs e)
        {
            admin_haslo = mtxAdmin.Text;
            admin_login = txtAdmin.Text;
          logowanie_admin(admin_haslo, admin_login);
            btnWylogujAdmina.Show();
            btnZarządzaj.Hide();
        }

        private void btnWylogujAdmina_Click(object sender, EventArgs e)
        {
            wylogowanie_admin();
            btnWylogujAdmina.Hide();
            btnZarządzaj.Show();
        }



        public void znajdz_sprzedawce()
        {
            string nazwisko, imie, nazwa, firma, kod, email, miasto, skype,  www, telefon;
            
            nazwisko = text_from_box(txtNazwisko, "");
            nazwa = text_from_box(txtNazwa, "");
            imie = text_from_box(txtImie, "");
            //login = text_from_box(txtLogin, "");
            kod = text_from_box(txtKod, "");
            firma = text_from_box(txtFirma, "");
            www = text_from_box(txtWWW, "");
            email = text_from_box(txtEmail, "");
            miasto = text_from_box(txtMiasto, "");
            skype = text_from_box(txtSkype, "");
            telefon = text_from_box(txtTelefon, "");
            rtxKomunikat.Text = nazwa + " " + nazwisko + " " + imie + " " + firma + " " + email + " " + skype + " " + telefon + " " + miasto;
            rejestr_kontrahentow dealer = new rejestr_kontrahentow();
            var wyniki_szukania =
              from rejestr_kontrahentow in baza.rejestr_kontrahentow
              where rejestr_kontrahentow.nazwisko.Contains(nazwisko)
              && rejestr_kontrahentow.imie.Contains(imie)
               && rejestr_kontrahentow.nazwa.Contains(nazwa)
              && rejestr_kontrahentow.firma.Contains(firma)
              && rejestr_kontrahentow.email.Contains(email)
               && rejestr_kontrahentow.skype.Contains(skype)
               && rejestr_kontrahentow.miasto.Contains(miasto)
                && rejestr_kontrahentow.miasto.Contains(telefon)
            && rejestr_kontrahentow.www.Contains(www)
              select rejestr_kontrahentow;

            
            dgvKontrahenci.DataSource = wyniki_szukania.ToArray().ToList();
            dgvKontrahenci.Update();
           if(dgvKontrahenci.Rows.Count>0)
            {
                wybrany_kh_id = id_wybranego_kh();
            }
            

            
        }

        private void btnZnajdzDealera_Click(object sender, EventArgs e)
        {
            znajdz_sprzedawce();
        }

        private void btnPokazMojeTransakcje_Click(object sender, EventArgs e)
        {
            pokaz_moje_transakcje();
        }

        private void btnSzczegolyTransakcji_Click(object sender, EventArgs e)
        {
            wybrane_auto_id = id_wybranego_auta_moje_transakcje();
            double wybrane_auto_cena = 0;
            int edycja = 0;
            int dodawanie = 0;
            int licytacja = 0;
            int czy_kontrahent_ostatniej_transakcji = 0;
            string status_auta = aktualny_status_auta(wybrane_auto_id);
            txtIdWybranegoAuta.Text = wybrane_auto_id.ToString();
            edycja = czy_to_wlasciciel_auta(wybrane_auto_id, zalogowany_kh_id);
            if (txtAdmin.Text == "Administrator")
            {
                administracja = true;
            }
            else
            {
                administracja = false;
            }
          

            var wybrane_auto = baza.lista_wszystkich_aut.Where(znajdz => znajdz.id == wybrane_auto_id);
            foreach (lista_wszystkich_aut autko in wybrane_auto)
            {
                wybrane_auto_cena = autko.ostatnia_cena;
            }

            if (kontrahent_ostatniej_transakcji(wybrane_auto_id) == zalogowany_kh_id)
            {
                czy_kontrahent_ostatniej_transakcji = 1;
            }


            if (zalogowany_kh_typ == 1)
            {
                licytacja = 1;
            }
            if (zalogowany_kh_typ == 2)
            {
                dodawanie = 1;
                if (edycja == 1)
                { licytacja = 1; }
            }
            DaneSamochodu pokaz = new DaneSamochodu(wybrane_auto_id, wybrane_auto_cena, zalogowany_kh_id, edycja, dodawanie, licytacja, status_auta, czy_kontrahent_ostatniej_transakcji, administracja);
            pokaz.ShowDialog();
        }



        public int id_wybranego_auta_moje_transakcje()
        {
            if(dgvMojeTransakcje.SelectedRows.Count==0 && dgvMojeTransakcje.Rows.Count>0)
            {
                dgvMojeTransakcje.Rows[0].Selected = true;
            }
            if (dgvMojeTransakcje.Rows.Count > 0 && dgvMojeTransakcje.SelectedRows.Count> 0)
            {
                wybrane_auto_rejestracja = dgvMojeTransakcje.SelectedRows[0].Cells[5].Value.ToString();
                int.TryParse(dgvMojeTransakcje.SelectedRows[0].Cells[1].Value.ToString(), out wybrane_auto_id);
            }

            return wybrane_auto_id;
        }


        public int id_wybranego_auta_sprzedaz()
        {
            if(dgvSprzedaz.SelectedRows.Count==0)
            {
                dgvSprzedaz.Rows[0].Selected = true;
            }
            int.TryParse(dgvSprzedaz.SelectedRows[0].Cells[0].Value.ToString(), out wybrane_auto_id);
       
            wybrane_auto_rejestracja = dgvSprzedaz.SelectedRows[0].Cells[1].Value.ToString();
        
            return wybrane_auto_id;
        }

        private void btnSzczegolySprzedazy_Click(object sender, EventArgs e)
        {
            wybrane_auto_id = id_wybranego_auta_sprzedaz();
            double wybrane_auto_cena = 0;
            int edycja = 0;
            int dodawanie = 0;
            int licytacja = 0;
            int czy_kontrahent_ostatniej_transakcji = 0;
            string status_auta = aktualny_status_auta(wybrane_auto_id);
            txtIdWybranegoAuta.Text = wybrane_auto_id.ToString();
            edycja = czy_to_wlasciciel_auta(wybrane_auto_id, zalogowany_kh_id);
            if (txtAdmin.Text == "Administrator")
            {
                administracja = true;
            }
            else
            {
                administracja = false;
            }


            var wybrane_auto = baza.lista_wszystkich_aut.Where(znajdz => znajdz.id == wybrane_auto_id);
            foreach (lista_wszystkich_aut autko in wybrane_auto)
            {
                wybrane_auto_cena = autko.ostatnia_cena;
            }

            if (kontrahent_ostatniej_transakcji(wybrane_auto_id) == zalogowany_kh_id)
            {
                czy_kontrahent_ostatniej_transakcji = 1;
            }


            if (zalogowany_kh_typ == 1)
            {
                licytacja = 1;
            }
            if (zalogowany_kh_typ == 2)
            {
                dodawanie = 1;
                if (edycja == 1)
                { licytacja = 1; }
            }
            DaneSamochodu pokaz = new DaneSamochodu(wybrane_auto_id, wybrane_auto_cena, zalogowany_kh_id, edycja, dodawanie, licytacja, status_auta, czy_kontrahent_ostatniej_transakcji, administracja);
            pokaz.ShowDialog();
        }

        private void dgvListaAut_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            wybrane_auto_id = id_wybranego_auta();
        }

        private void dgvMojeTransakcje_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            wybrane_auto_id = id_wybranego_auta_moje_transakcje();

        }
    }
}
