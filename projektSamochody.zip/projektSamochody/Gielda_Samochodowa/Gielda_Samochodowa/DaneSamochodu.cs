﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Gielda_Samochodowa
{
    public partial class DaneSamochodu : Form
    {
        public DaneSamochodu(int wybrane_auto_id, double wybrane_auto_cena,
            int zalogowany_id, int edycja, int dodawanie, int licytacja, 
            string status, int czy_kh_ostatniej_transakcji, bool administracja)
        {
            InitializeComponent();
            txtIdAuta.Text = wybrane_auto_id.ToString();
            textZalogowany.Text = zalogowany_id.ToString();
            txtCena.Text = wybrane_auto_cena.ToString();
            txtAktualnyStatus.Text = status;
            txtCenaWyjsciowa.Text = wybrane_auto_cena.ToString();
            txtCzyKhOstatniejTransakcji.Text = czy_kh_ostatniej_transakcji.ToString();
            btnZaakceptuj.Hide();
            btnRezygnacja.Hide();
            if (edycja == 1 && dodawanie == 1)
            {
                txtTypZalogowanego.Text = "wlasciel";
            }
            if (edycja == 0)
            {
                btnKolor.Hide();
                btnMarka.Hide();
                btnSilnik.Hide();
                btnPrzebieg.Hide();
                btnRok.Hide();
                btnKolor.Hide();
                btnRejestracja.Hide();
                btnSprzedaj.Hide();
            }
            if (administracja == true)
            {
                txtAdministracja.Text = "Administrator";
            }
            else
            {
                txtAdministracja.Text = "";
            }
            if (status != "licytacja")
            { btnSprzedaj.Hide(); }
            if (status == "sprzedaz" || status == "zgoda wlasciciela")
            { btnCena.Hide(); }
            if (czy_kh_ostatniej_transakcji == 1 && status == "zgoda wlasciciela")
            {
                btnZaakceptuj.Show();
                btnRezygnacja.Show();
            }

            if (dodawanie == 0)
            { btnDodajAuto.Hide();
                btnDodajKolor.Hide();
                btnDodajMarke.Hide();
                btnDodajSilnik.Hide();
                txtDodajMarke.Hide();
                txtDodajSilnik.Hide();
                txtDodajKolor.Hide();
                lbDodajKolor.Hide();
                lbDodajMarke.Hide();
                lbDodajSilnik.Hide();
            }
            if (licytacja == 0)
            {
                btnCena.Hide();
                // btnTransakcja.Hide();
                btnSprzedaj.Hide();
                btnZaakceptuj.Hide();
                btnRezygnacja.Hide();
            }
            if (wybrane_auto_id == 0 && wybrane_auto_cena == 0 && dodawanie == 1 && edycja == 1 && licytacja == 1)
            {
                Kontrahenci kontrahent = new Kontrahenci();
                string moja_nazwa = "";
                var zalogowany = baza.Kontrahenci.Where(znajdz => znajdz.id == zalogowany_id);
                foreach (Kontrahenci wiersz in zalogowany)
                {
                    moja_nazwa = wiersz.nazwa;
                    txtWlasciciel.Text = moja_nazwa;

                }

            }

        }
        DBSamochodyEntities baza = new DBSamochodyEntities();
        string wybrana_marka_auta;
        string wybrany_silnik_auta;
        string wybrany_kolor_auta;
        int wybrana_marka_auta_id = 0;
        int wybrany_silnik_auta_id = 0;
        int wybrany_kolor_auta_id = 0;
        int ostatnia_transakcja_id = 0;

        //bool administracja = false;
        //administracja = administracja_status();

        public void administracja_status()
        {
            if (txtAdministracja.Text == "Administrator")
            {
                odkryj_obiekty_admin();
            }
            else
            {
                ukryj_obiekty_admin();
            }
        }

        public void odkryj_obiekty_admin()
        {
            txtIdKtoWycenil.Show();
            txtIdAuta.Show();
            txtIdKolor.Show();
            txtIdSilnik.Show();
            txtIdTransakcja.Show();
            txtIdWlasciciel.Show();
            txtTypZalogowanego.Show();
            txtCzyKhOstatniejTransakcji.Show();
            lbAdministracja.Show();
            lbAutoId.Show();
            lbIdWyceniajacego.Show();
            lbKhTransakcji.Show();
            lbKolorId.Show();
            lbMarkaId.Show();
            lbSilnikId.Show();
            lbTransakcjaId.Show();
            lbTyp.Show();
            lbWlascicielId.Show();
            lbZalogowanyId.Show();
            txtAdministracja.Show();
            txtIdMarka.Show();
            textZalogowany.Show();
            btnPoprawjKolor.Show();
            btnPoprawMarke.Show();
            btnPoprawSilnik.Show();
            txtDodajMarke.Show();
            txtDodajSilnik.Show();
            txtDodajKolor.Show();
            lbDodajKolor.Show();
            lbDodajMarke.Show();
            lbDodajSilnik.Show();
        }



        public void ukryj_obiekty_admin()
        {
            txtIdKtoWycenil.Hide();
            txtIdAuta.Hide();
            txtIdKolor.Hide();
            txtIdSilnik.Hide();
            txtIdTransakcja.Hide();
            txtIdWlasciciel.Hide();
            txtTypZalogowanego.Hide();
            txtCzyKhOstatniejTransakcji.Hide();
            lbAdministracja.Hide();
            lbAutoId.Hide();
            lbIdWyceniajacego.Hide();
            lbKhTransakcji.Hide();
            lbKolorId.Hide();
            lbMarkaId.Hide();
            lbSilnikId.Hide();
            lbTransakcjaId.Hide();
            lbTyp.Hide();
            lbWlascicielId.Hide();
            lbZalogowanyId.Hide();
            txtAdministracja.Hide();
            txtIdMarka.Hide();
            textZalogowany.Hide();
            btnPoprawjKolor.Hide();
            btnPoprawMarke.Hide();
            btnPoprawSilnik.Hide();
        }
        // float moja_ostatnia_cena = 0;

        //  int.TryParse(txtIdAuta.Text, out int wybrane_auto_id);
        // int.TryParse(baza.id_ostatniej_transakcji(wybrane_auto_id).ToString(), out int ostatnia_transakcja);

        private void DaneSamochodu_Load(object sender, EventArgs e)
        {
            pokaz_marki();
            pokaz_kolory();
            pokaz_silniki();
            administracja_status();
           
            int.TryParse(txtIdAuta.Text, out int wybrane_auto_id);
            int.TryParse(textZalogowany.Text, out int zalogowany_id);
            //   int.TryParse(baza.id_ostatniej_transakcji(wybrane_auto_id).ToString(), out int ostatnia_transakcja);
            //  float.TryParse(baza.Dane_ostatniej_transakcji(wybrane_auto_id).ToString(), out float moja_ostatnia_cena);
            //  txtCena.Text = moja_ostatnia_cena.ToString();
            if (wybrane_auto_id > 0)
            {
                pokaz_dane_auta_teksty(wybrane_auto_id);
                moja_ostatnia_cena(wybrane_auto_id, zalogowany_id);
                ostatnia_cena_nie_wlasciciela(wybrane_auto_id);
                ostatnia_cena_wlasciciela(wybrane_auto_id);
            }
        }

        public void wyczysc_tekst(TextBox tekscik)
        {
            tekscik.Text = "";
        }


        public void pokaz_dane_auta_teksty(int wybrane_auto_id)
        {
            var wszystkie_auta = baza.Auta.Where(znajdz => znajdz.id == wybrane_auto_id);

            foreach (Auta autko in wszystkie_auta)
            {
                try
                {
                    txtIdMarka.Text = autko.marka.ToString();
                    txtIdSilnik.Text = autko.silnik.ToString();
                    txtIdKolor.Text = autko.kolor.ToString();
                    txtPrzebieg.Text = autko.przebieg.ToString();
                    txtRok.Text = autko.rok_produkcji.ToString();
                    txtRejestracja.Text = autko.rejestracja.ToString();
                    int.TryParse(txtIdAuta.Text, out int id_auto);
                    int.TryParse(textZalogowany.Text, out int zalogowany);

                    if (txtIdMarka.Text.Length > 0)
                    {
                        var wszystkie_marki = baza.Marka.Where(znajdz => znajdz.id == autko.marka);
                        foreach (Marka marka_auta in wszystkie_marki)
                        {
                            txtMarka.Text = marka_auta.nazwa.ToString();
                        }
                    }

                    if (txtIdSilnik.Text.Length > 0)
                    {
                        var wszystkie_silniki = baza.Silnik.Where(znajdz => znajdz.id == autko.silnik);
                        foreach (Silnik silnik_auta in wszystkie_silniki)
                        {
                            txtSilnik.Text = silnik_auta.nazwa.ToString();
                        }
                    }

                    if (txtIdKolor.Text.Length > 0)
                    {
                        var wszystkie_kolory = baza.Kolor.Where(znajdz => znajdz.id == autko.kolor);
                        foreach (Kolor kolor_auta in wszystkie_kolory)
                        {
                            txtKolor.Text = kolor_auta.nazwa.ToString();
                        }
                    }

                    if (autko.wlasciciel > 0)
                    {
                        var wszyscy_dealerzy = baza.Kontrahenci.Where(znajdz => znajdz.id == autko.wlasciciel);
                        foreach (Kontrahenci wlasciciel_auta in wszyscy_dealerzy)
                        {
                            txtWlasciciel.Text = wlasciciel_auta.nazwa.ToString();
                        }
                    }

                    if (textZalogowany.Text.Length > 0 && txtIdAuta.Text.Length > 0)
                    {
                        var transakcje = baza.Transakcja.Where(znajdz => znajdz.id_auto == id_auto && znajdz.id_kontrahent == zalogowany);
                        foreach (Transakcja ostatnia_cena in transakcje)
                        {
                            txtCena.Text = ostatnia_cena.cena.ToString();
                        }
                    }

                    if (txtIdAuta.Text.Length > 0)
                    {
                        var lista_aut = baza.lista_aut.Where(znajdz => znajdz.rejestracja == autko.rejestracja.ToString());
                        foreach (lista_aut cena_auta in lista_aut)
                        {
                            txtCena.Text = cena_auta.ostatnia_cena.ToString();

                        }
                    }

                }
                catch (DataException problem)
                {

                    problem.GetBaseException();
                    problem.InnerException.Data.Clear();
                    problem.Data.Clear();
                    System.Data.SqlClient.SqlConnection.ClearAllPools();
                }
                catch (Exception ex)
                {
                    rtxKomunikaty.Text = ex.ToString();
                    ex.Data.Clear();
                }
            }
        }

        public void nowy_wlasciciel_procedura(int id_auto, int id_nowy_wlasciciel)
        {
            baza.Nowy_Wlasciciel_Auta(id_auto, id_nowy_wlasciciel);

        }

        public void moja_ostatnia_cena(int id_auto, int id_kontrahent)
        {
            
            var transakcje_auta = baza.ostatnie_transakcje_kontrahentow_aut.Where(znajdz => znajdz.id_auto == id_auto &&
            znajdz.id_kontrahent == id_kontrahent);

            foreach (ostatnie_transakcje_kontrahentow_aut moja_ostatnia_transakcja in transakcje_auta)
            {
                txtMojaCena.Text = moja_ostatnia_transakcja.cena.ToString();
            }
            
        }

        public void ostatnia_cena_wlasciciela(int id_auto)
        {

            var transakcje_auta = baza.ostatnie_statusy_wlasciciela_auta.Where(znajdz => znajdz.id_auto == id_auto);

            foreach (ostatnie_statusy_wlasciciela_auta ostatnia_transakcja in transakcje_auta)
            {
                txtOstatniaCenaWlasciciela.Text = ostatnia_transakcja.cena.ToString();
            }

        }

        public void ostatnia_cena_nie_wlasciciela(int id_auto)
        {

            var transakcje_auta = baza.ostatnie_statusy_niewlasciciela_auta.Where(znajdz => znajdz.id_auto == id_auto);

            foreach (ostatnie_statusy_niewlasciciela_auta ostatnia_transakcja in transakcje_auta)
            {
                txtOstatniaCenaNieWlasciciela.Text = ostatnia_transakcja.cena.ToString();
                txtOferent.Text = ostatnia_transakcja.kontrahent.ToString();
            }

        }

        public void dodaj_auto_procedura()
        {
            //float samochodzik = 0;
            int.TryParse(textZalogowany.Text, out int wlasiciel_id);
            int.TryParse(txtRok.Text, out int rok_produkcji);
            float.TryParse(txtPrzebieg.Text, out float przebieg_auta);
            float.TryParse(txtCena.Text, out float cena_auta);
            int.TryParse(txtIdSilnik.Text, out int wybrany_silnik_auta_id);
            int.TryParse(txtIdMarka.Text, out int wybrana_marka_auta_id);
            int.TryParse(txtIdKolor.Text, out int wybrany_kolor_auta_id);

            if (textZalogowany.Text != "")
            {
                try

                {

                    baza.Dodaj_Auto(wybrana_marka_auta_id, wybrany_silnik_auta_id,
                        wybrany_kolor_auta_id,
                        przebieg_auta, rok_produkcji,
                          wlasiciel_id, txtRejestracja.Text);
                    var dodane_auta = baza.Auta.Where(znajdz => znajdz.rejestracja == txtRejestracja.Text);
                    foreach (Auta dodane_autko in dodane_auta)
                    {
                        txtIdAuta.Text = dodane_autko.id.ToString();

                    }
                    var wszyscy_dealerzy = baza.Kontrahenci.Where(znajdz => znajdz.id == wlasiciel_id);
                    foreach (Kontrahenci wlasciciel_auta in wszyscy_dealerzy)
                    {
                        txtWlasciciel.Text = wlasciciel_auta.nazwa.ToString();
                    }

                    if (txtTypZalogowanego.Text == "wlasciel" && txtCena.Text != "0")
                    {
                        dodaj_cene_auta_procedura(1);
                        nowa_transakcja_procedura();
                        nowy_status_transakcji_procedura("licytacja");
                    }

                }
                catch (DataException problem)
                {
                    rtxKomunikaty.Text = problem.ToString();
                    problem.GetBaseException();
                    problem.InnerException.Data.Clear();
                    problem.Data.Clear();

                    System.Data.SqlClient.SqlConnection.ClearAllPools();

                }
                catch (Exception ex)
                {
                    rtxKomunikaty.Text = ex.ToString();
                    ex.Data.Clear();

                }

            }
        }


        public void pokaz_marki()
        {
            if (lboxMarka.SelectedIndex == 0)
            { lboxMarka.SelectedIndex = 1; }
            lboxMarka.Items.Clear();
            Marka marka_auta = new Marka();
            var lista_marek = baza.Marka.Where(znajdz => znajdz.id > 0);

            lboxMarka.Items.Add("Nazwa");
            foreach (var marka_wybranego_auta in lista_marek)
            {
                lboxMarka.Items.Add(marka_wybranego_auta.nazwa);
            }
        }
        public void pokaz_silniki()
        {
            if (lboxSilnik.SelectedIndex == 0)
            { lboxSilnik.SelectedIndex = 1; }
            lboxSilnik.Items.Clear();
            Silnik silnik_auta = new Silnik();
            var lista_silnikow = baza.Silnik.Where(znajdz => znajdz.id > 0);

            lboxSilnik.Items.Add("Nazwa");
            foreach (var silnik_wybranego_auta in lista_silnikow)
            {
                lboxSilnik.Items.Add(silnik_wybranego_auta.nazwa);
            }
        }

        public void pokaz_kolory()
        {
            if (lboxKolor.SelectedIndex == 0)
            { lboxKolor.SelectedIndex = 1; }
            lboxKolor.Items.Clear();
            Kolor silnik_auta = new Kolor();
            var lista_kolorow = baza.Kolor.Where(znajdz => znajdz.id > 0);

            lboxKolor.Items.Add("Nazwa");
            foreach (var kolor_wybranego_auta in lista_kolorow)
            {
                lboxKolor.Items.Add(kolor_wybranego_auta.nazwa);
            }
        }


        public int wybrana_marka()
        {
            int pozycja_znaku = 0;
            int dlugosc = 0;
            if (lboxMarka.SelectedIndex == 0)
            { lboxMarka.SelectedIndex = 1; }
            //Marka wybrana_marka = new Marka();
            char znak;
            znak = (char)9;
            wybrana_marka_auta = lboxMarka.GetItemText(lboxMarka.SelectedItem);
            dlugosc = wybrana_marka_auta.Length;
            wybrana_marka_auta = wybrana_marka_auta.TrimEnd();

            if (wybrana_marka_auta.Contains(znak))
            {
                pozycja_znaku = wybrana_marka_auta.IndexOf(znak);
                dlugosc = dlugosc - pozycja_znaku;
                wybrana_marka_auta = wybrana_marka_auta.Remove(pozycja_znaku);
            }
            txtMarka.Text = wybrana_marka_auta;
            var wybrane_marki = baza.Marka.Where(znajdz => znajdz.nazwa == wybrana_marka_auta);
            foreach (Marka marka_auta in wybrane_marki)
            {
                wybrana_marka_auta_id = marka_auta.id;
            }
            txtIdMarka.Text = wybrana_marka_auta_id.ToString();
            return wybrana_marka_auta_id;
        }

        public int wybrany_silnik()
        {
            int pozycja_znaku = 0;
            int dlugosc = 0;
            if (lboxSilnik.SelectedIndex == 0)
            { lboxSilnik.SelectedIndex = 1; }
            Silnik wybranawybrany_silnik_auta = new Silnik();
            char znak;
            znak = (char)9;
            wybrany_silnik_auta = lboxSilnik.GetItemText(lboxSilnik.SelectedItem);
            dlugosc = wybrany_silnik_auta.Length;
            wybrany_silnik_auta = wybrany_silnik_auta.TrimEnd();

            if (wybrany_silnik_auta.Contains(znak))
            {
                pozycja_znaku = wybrany_silnik_auta.IndexOf(znak);
                dlugosc = dlugosc - pozycja_znaku;
                wybrany_silnik_auta = wybrany_silnik_auta.Remove(pozycja_znaku);
            }
            txtSilnik.Text = wybrany_silnik_auta;
            var wybrane_silniki = baza.Silnik.Where(znajdz => znajdz.nazwa == wybrany_silnik_auta);
            foreach (Silnik silnik_auta in wybrane_silniki)
            {
                wybrany_silnik_auta_id = silnik_auta.id;
            }
            txtIdSilnik.Text = wybrany_silnik_auta_id.ToString();
            return wybrany_silnik_auta_id;
        }

        public int wybrany_kolor()
        {
            int pozycja_znaku = 0;
            int dlugosc = 0;
            if (lboxKolor.SelectedIndex == 0)
            { lboxKolor.SelectedIndex = 1; }
            Kolor wybranawybrany_kolor_auta = new Kolor();
            char znak;
            znak = (char)9;
            wybrany_kolor_auta = lboxKolor.GetItemText(lboxKolor.SelectedItem);
            dlugosc = wybrany_kolor_auta.Length;
            wybrany_kolor_auta = wybrany_kolor_auta.TrimEnd();

            if (wybrany_kolor_auta.Contains(znak))
            {
                pozycja_znaku = wybrany_kolor_auta.IndexOf(znak);
                dlugosc = dlugosc - pozycja_znaku;
                wybrany_kolor_auta = wybrany_kolor_auta.Remove(pozycja_znaku);
            }
            txtKolor.Text = wybrany_kolor_auta;
            var wybrane_kolory = baza.Kolor.Where(znajdz => znajdz.nazwa == wybrany_kolor_auta);
            foreach (Kolor kolor_auta in wybrane_kolory)
            {
                wybrany_kolor_auta_id = kolor_auta.id;
            }
            txtIdKolor.Text = wybrany_kolor_auta_id.ToString();
            return wybrany_kolor_auta_id;
        }


        public int nowa_transakcja_procedura()
        {
            //float samochodzik = 0;
            int.TryParse(textZalogowany.Text, out int id_kontrahent);
            int.TryParse(txtIdAuta.Text, out int auto_id);
            float.TryParse(txtCena.Text, out float cena);
            float.TryParse(txtCenaWyjsciowa.Text, out float cena_wyjsciowa);
            string typ_zalogowanego = txtTypZalogowanego.Text;
           
            if (txtCena.Text != "")
            {
                try

                {

                    if (cena > cena_wyjsciowa || typ_zalogowanego == "wlasciel")
                    {
                        baza.Dodaj_Transakcje(auto_id, id_kontrahent, cena);
                        //  int.TryParse(baza.id_ostatniej_transakcji(id_auto).ToString(), out int ostatnia_transakcja);
                        int ostatnia_transakcja = 0;

                        var transakcje_auta = baza.ostatnie_transakcje.Where(znajdz => znajdz.id_auto == auto_id);

                        foreach (ostatnie_transakcje aktualne_transakcje in transakcje_auta)
                        {
                            ostatnia_transakcja = aktualne_transakcje.id_transakcja.Value;
                        }



                        var nowa_transakcja = baza.Transakcja.Where(znajdz => znajdz.id == ostatnia_transakcja);

                        foreach (Transakcja transakcja_cenowa in nowa_transakcja)
                        {
                            txtCena.Text = transakcja_cenowa.cena.ToString();
                            txtIdTransakcja.Text = transakcja_cenowa.id.ToString();
                        }
                        return ostatnia_transakcja_id;
                    }
                    else
                    { rtxKomunikaty.Text = "Cena przypisywana musi być wyższa od wyjściowej"; }
                }

                catch (DataException problem)
                {
                    if (problem.ToString().Contains("duplicate"))
                    {
                        rtxKomunikaty.Text = "Ta cena została już zadeklarowana. Wprowadź inną cenę";
                    }
                    else
                    {
                        rtxKomunikaty.Text = problem.ToString();
                    }
                    //rtxKomunikaty.Text = "Ta informacja już istnieje. Zrestartuj aplikację i wprowadź inne dane";

                    problem.GetBaseException();
                    problem.InnerException.Data.Clear();
                    problem.Data.Clear();

                    System.Data.SqlClient.SqlConnection.ClearAllPools();
                    return 0;

                }
                catch (Exception ex)
                {
                    rtxKomunikaty.Text = ex.ToString();
                    ex.Data.Clear();
                    return 0;
                }

            }
            else
            { rtxKomunikaty.Text = "Podaj cenę auta"; }
            return 0;
        }

        public void nowy_silnik_procedura()
        {
            string wartosc;
            wartosc = txtDodajSilnik.Text;
            if (wartosc.Length > 2)
            {
                try
                {
                    baza.Dodaj_Silnik(wartosc);
                }
                catch (DataException problem)
                {
                    rtxKomunikaty.Text = problem.ToString();
                    problem.GetBaseException();
                    problem.InnerException.Data.Clear();
                    problem.Data.Clear();
                    System.Data.SqlClient.SqlConnection.ClearAllPools();
                }
                catch (Exception ex)
                {
                    rtxKomunikaty.Text = ex.ToString();
                    ex.Data.Clear();
                }
            }
            else
            { rtxKomunikaty.Text = "wpisz w pole silnik pod listą prawidłową wartość"; }
        }

        public void nowy_kolor_procedura()
        {
            string wartosc;
            wartosc = txtDodajKolor.Text;
            if (wartosc.Length > 2)
            {
                try
                {
                    baza.Dodaj_Kolor(wartosc);
                }
                catch (DataException problem)
                {
                    rtxKomunikaty.Text = problem.ToString();
                    problem.GetBaseException();
                    problem.InnerException.Data.Clear();
                    problem.Data.Clear();
                    System.Data.SqlClient.SqlConnection.ClearAllPools();
                }
                catch (Exception ex)
                {
                    rtxKomunikaty.Text = ex.ToString();
                    ex.Data.Clear();
                }
            }
            else
            { rtxKomunikaty.Text = "wpisz w pole kolor pod listą prawidłową wartość"; }
        }



        public void nowa_marka_procedura()
        {
            string wartosc;
            wartosc = txtDodajMarke.Text;
            if (wartosc.Length > 2)
            {
                try
                {
                    baza.Dodaj_Marke(wartosc);
                }
                catch (DataException problem)
                {
                    rtxKomunikaty.Text = problem.ToString();
                    problem.GetBaseException();
                    problem.InnerException.Data.Clear();
                    problem.Data.Clear();
                    System.Data.SqlClient.SqlConnection.ClearAllPools();
                }
                catch (Exception ex)
                {
                    rtxKomunikaty.Text = ex.ToString();
                    ex.Data.Clear();
                }
            }
            else
            { rtxKomunikaty.Text = "wpisz w pole marka pod listą prawidłową wartość"; }
        }

        public void popraw_marke_procedura()
        {
            string wartosc;
            wartosc = txtDodajMarke.Text;
            int.TryParse(txtIdMarka.Text, out int id_poprawiane);
   
            if (wartosc.Length > 2 && id_poprawiane > 0)
            {
                try
                {
                    baza.Edycja_Marka(wartosc, id_poprawiane);
                }
                catch (DataException problem)
                {
                    rtxKomunikaty.Text = problem.ToString();
                    problem.GetBaseException();
                    problem.InnerException.Data.Clear();
                    problem.Data.Clear();
                    System.Data.SqlClient.SqlConnection.ClearAllPools();
                }
                catch (Exception ex)
                {
                    rtxKomunikaty.Text = ex.ToString();
                    ex.Data.Clear();
                }
            }
            else
            { rtxKomunikaty.Text = "wpisz w pole marka pod listą prawidłową wartość"; }
        }

        public void popraw_silnik_procedura()
        {
            string wartosc;
            wartosc = txtDodajSilnik.Text;
            int.TryParse(txtIdSilnik.Text, out int id_poprawiane);

            if (wartosc.Length > 2 && id_poprawiane > 0)
            {
                try
                {
                    baza.Edycja_Silnik(wartosc, id_poprawiane);
                }
                catch (DataException problem)
                {
                    rtxKomunikaty.Text = problem.ToString();
                    problem.GetBaseException();
                    problem.InnerException.Data.Clear();
                    problem.Data.Clear();
                    System.Data.SqlClient.SqlConnection.ClearAllPools();
                }
                catch (Exception ex)
                {
                    rtxKomunikaty.Text = ex.ToString();
                    ex.Data.Clear();
                }
            }
            else
            { rtxKomunikaty.Text = "wpisz w pole silnik pod listą prawidłową wartość"; }
        }

        public void popraw_kolor_procedura()
        {
            string wartosc;
            wartosc = txtDodajKolor.Text;
            int.TryParse(txtIdKolor.Text, out int id_poprawiane);

            if (wartosc.Length > 2 && id_poprawiane > 0)
            {
                try
                {
                    baza.Edycja_Kolor(wartosc, id_poprawiane);
                }
                catch (DataException problem)
                {
                    rtxKomunikaty.Text = problem.ToString();
                    problem.GetBaseException();
                    problem.InnerException.Data.Clear();
                    problem.Data.Clear();
                    System.Data.SqlClient.SqlConnection.ClearAllPools();
                }
                catch (Exception ex)
                {
                    rtxKomunikaty.Text = ex.ToString();
                    ex.Data.Clear();
                }
            }
            else
            { rtxKomunikaty.Text = "wpisz w pole kolor pod listą prawidłową wartość"; }
        }



        public void nowa_cena_procedura()
        {
            int.TryParse(textZalogowany.Text, out int id_kontrahent);
            int.TryParse(txtIdAuta.Text, out int id_auto);
            float.TryParse(txtCena.Text, out float cena);
            int wlasciciel_auta = 0;
            var wyceniane_auto = baza.Auta.Where(znajdz => znajdz.id == id_auto);
            foreach (Auta auto in wyceniane_auto)
            {
                wlasciciel_auta = auto.wlasciciel;
            }
            if (txtCena.Text != "")
            {
                try
                {
                    var nowa_transakcja = baza.Transakcja.Where(znajdz => znajdz.id_auto == id_auto
                    && (znajdz.id_kontrahent == id_kontrahent || znajdz.id_kontrahent == wlasciciel_auta));
                    foreach (Transakcja transakcja_cenowa in nowa_transakcja)
                    {
                        txtIdTransakcja.Text = transakcja_cenowa.id.ToString();
                        txtIdKtoWycenil.Text = transakcja_cenowa.id_kontrahent.ToString();

                    }
                    baza.Nowa_Cena_Transakcji(id_auto, id_kontrahent, cena);
                }

                catch (DataException problem)
                {
                    rtxKomunikaty.Text = problem.ToString();
                    problem.GetBaseException();
                    problem.InnerException.Data.Clear();
                    problem.Data.Clear();
                    System.Data.SqlClient.SqlConnection.ClearAllPools();
                }
                catch (Exception ex)
                {
                    rtxKomunikaty.Text = ex.ToString();
                    ex.Data.Clear();
                }

            }
            else
            { rtxKomunikaty.Text = "Podaj cenę auta"; }
        }

        public void sprzedaj_zamknij_pozostale_transakcje()
        {
            int.TryParse(textZalogowany.Text, out int id_kontrahent);
            int.TryParse(txtIdAuta.Text, out int id_auto);
            int.TryParse(txtIdKtoWycenil.Text, out int kto_wycenil);


            int id_transakcja_pomin = 0;

            var transakcje_auta = baza.ostatnie_transakcje.Where(znajdz => znajdz.id_auto == id_auto);

            foreach (ostatnie_transakcje aktualne_transakcje in transakcje_auta)
            {
                id_transakcja_pomin = aktualne_transakcje.id_transakcja.Value;
            }


            txtIdTransakcja.Text = id_transakcja_pomin.ToString();
            int.TryParse(txtIdTransakcja.Text, out id_transakcja_pomin);



            if (id_transakcja_pomin > 0)
            {
                try
                {
                    baza.Zamknij_Transakcje(id_transakcja_pomin, id_auto);
                    //  baza.Edycja_Wlasciciel_Auta_Po_Id(kto_wycenil, id_auto);
                }
                catch (DataException problem)
                {

                    //rtxKomunikaty.Text = "Ta informacja już istnieje. Zrestartuj aplikację i wprowadź inne dane";
                    rtxKomunikaty.Text = problem.ToString();
                    problem.GetBaseException();
                    problem.InnerException.Data.Clear();
                    problem.Data.Clear();

                    System.Data.SqlClient.SqlConnection.ClearAllPools();

                }
                catch (Exception ex)
                {
                    rtxKomunikaty.Text = ex.ToString();
                    ex.Data.Clear();

                }


            }

        }




        public int nowy_status_transakcji_procedura(string status)
        {
            //float samochodzik = 0;
            int.TryParse(textZalogowany.Text, out int id_kontrahent);
            int.TryParse(txtIdAuta.Text, out int auto_id);
            // int id_transakcja = 0;
            int id_status = 0;

            if (txtIdAuta.Text != "" && textZalogowany.Text != "")
            {
                try

                {
                    int ostatnia_transakcja = 0;

                    var transakcje_auta = baza.ostatnie_transakcje.Where(znajdz => znajdz.id_auto == auto_id);

                    foreach (ostatnie_transakcje aktualne_transakcje in transakcje_auta)
                    {
                        ostatnia_transakcja = aktualne_transakcje.id_transakcja.Value;
                    }


                    txtIdTransakcja.Text = ostatnia_transakcja.ToString();

                    if (ostatnia_transakcja == 0)
                    { ostatnia_transakcja = nowa_transakcja_procedura(); }

                    var statusy = baza.Status.Where(znajdz => znajdz.nazwa == status);
                    foreach (Status nowy_status in statusy)
                    {
                        id_status = nowy_status.id;
                    }

                    baza.Dodaj_Status_Transakcji(ostatnia_transakcja, id_status, id_kontrahent);

                    return ostatnia_transakcja;
                }

                catch (DataException problem)
                {

                    //rtxKomunikaty.Text = "Ta informacja już istnieje. Zrestartuj aplikację i wprowadź inne dane";
                    rtxKomunikaty.Text = problem.ToString();
                    problem.GetBaseException();
                    problem.InnerException.Data.Clear();
                    problem.Data.Clear();

                    System.Data.SqlClient.SqlConnection.ClearAllPools();
                    return 0;
                }
                catch (Exception ex)
                {
                    rtxKomunikaty.Text = ex.ToString();
                    ex.Data.Clear();
                    return 0;
                }

            }
            else
            {
                rtxKomunikaty.Text = "Podaj cenę auta";
                return 0;
            }

        }




        public void dodaj_cene_auta_procedura(int typ)
        {
            //float samochodzik = 0;
            //int.TryParse(textZalogowany.Text, out int id_kontrahent);
            int.TryParse(txtIdAuta.Text, out int id_auto);
            float.TryParse(txtCena.Text, out float cena_auta);
            //int id_transakcja = 0;
            //int id_status = 0;

            if (txtIdAuta.Text != "")
            {
                try
                {
                    baza.Dodaj_Cene_Auta(id_auto, typ, cena_auta);
                }

                catch (DataException problem)
                {
                    rtxKomunikaty.Text = problem.ToString();
                    problem.GetBaseException();
                    problem.InnerException.Data.Clear();
                    problem.Data.Clear();

                    System.Data.SqlClient.SqlConnection.ClearAllPools();

                }
                catch (Exception ex)
                {
                    rtxKomunikaty.Text = ex.ToString();
                    ex.Data.Clear();
                }

            }
            else
            { rtxKomunikaty.Text = "Podaj cenę auta"; }
        }

        public void zmien_cene_auta_procedura(int typ)
        {

            int.TryParse(txtIdAuta.Text, out int id_auto);
            float.TryParse(txtCena.Text, out float cena_auta);


            if (txtIdAuta.Text != "")
            {
                try
                {
                    baza.Nowa_Cena_Auta(id_auto, typ, cena_auta);
                }

                catch (DataException problem)
                {
                    rtxKomunikaty.Text = problem.ToString();
                    problem.GetBaseException();
                    problem.InnerException.Data.Clear();
                    problem.Data.Clear();

                    System.Data.SqlClient.SqlConnection.ClearAllPools();

                }
                catch (Exception ex)
                {
                    rtxKomunikaty.Text = ex.ToString();
                    ex.Data.Clear();
                }

            }
            else
            { rtxKomunikaty.Text = "Podaj cenę auta"; }
        }





        public void popraw_dane_auta_procedura(TextBox pole_danej, string parametr)
        {
            int dane = 0;
            int.TryParse(txtIdAuta.Text, out int id_auta);
            string wartosc = pole_danej.Text;
            if (pole_danej.Text != "")
            {
                try
                {
                    switch (parametr)
                    {
                        case "marka":
                            dane = baza.Edycja_Marka_Auta(wartosc, id_auta);
                            break;
                        case "silnik":
                            dane = baza.Edycja_Silnik_Auta(wartosc, id_auta);
                            break;
                        case "kolor":
                            dane = baza.Edycja_Kolor_Auta(wartosc, id_auta);
                            break;
                        case "wlasciciel":
                            int.TryParse(wartosc, out int id_wlasciciela);
                            dane = baza.Edycja_Wlasciciel_Auta_Po_Id(id_wlasciciela, id_auta);
                            break;
                        case "przebieg":
                            float.TryParse(wartosc, out float przebieg);
                            dane = baza.Edycja_Przebieg_Auta(przebieg, id_auta);
                            break;
                        case "rok":
                            int.TryParse(wartosc, out int rok_auta);
                            dane = baza.Edycja_Rok_Auta(rok_auta, id_auta);
                            break;
                        case "rejestracja":
                            dane = baza.Edycja_Rejestracja_Auta(wartosc, id_auta);
                            break;
                    }
                }
                catch (DataException problem)
                {
                    rtxKomunikaty.Text = problem.ToString();
                    problem.GetBaseException();
                    problem.InnerException.Data.Clear();
                    problem.Data.Clear();

                    System.Data.SqlClient.SqlConnection.ClearAllPools();


                }
                catch (Exception ex)
                {
                    rtxKomunikaty.Text = ex.ToString();
                    ex.Data.Clear();

                }



            }
        }




        private void lboxMarka_SelectedIndexChanged(object sender, EventArgs e)
        {

            if (txtTypZalogowanego.Text == "wlasciel")
            {
                wybrana_marka();
            }

        }

        private void lboxSilnik_SelectedIndexChanged(object sender, EventArgs e)
        {

            if (txtTypZalogowanego.Text == "wlasciel")
            {
                wybrany_silnik();
            }


        }

        private void lboxKolor_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (txtTypZalogowanego.Text == "wlasciel")
            {
                wybrany_kolor();
            }



        }

        private void btnRejestracja_Click(object sender, EventArgs e)
        {
            popraw_dane_auta_procedura(txtRejestracja, "rejestracja");
        }

        private void btnDodajAuto_Click(object sender, EventArgs e)
        {
            dodaj_auto_procedura();
        }

        private void btnZamknijDaneAuta_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnWyczyscDaneAuta_Click(object sender, EventArgs e)
        {
            wyczysc_tekst(txtIdAuta);
            wyczysc_tekst(txtMarka);
            wyczysc_tekst(txtKolor);
            wyczysc_tekst(txtPrzebieg);
            wyczysc_tekst(txtRejestracja);
            wyczysc_tekst(txtRok);
            wyczysc_tekst(txtSilnik);
            wyczysc_tekst(txtCena);
            wyczysc_tekst(txtWlasciciel);
            wyczysc_tekst(txtAktualnyStatus);
            wyczysc_tekst(txtOstatniaCenaNieWlasciciela);
            wyczysc_tekst(txtOstatniaCenaWlasciciela);
            wyczysc_tekst(txtMojaCena);
                }

        private void btnMarka_Click(object sender, EventArgs e)
        {
            rtxKomunikaty.Text = "";
            popraw_dane_auta_procedura(txtMarka, "marka");
        }

        private void btnSilnik_Click(object sender, EventArgs e)
        {
            rtxKomunikaty.Text = "";
            popraw_dane_auta_procedura(txtSilnik, "silnik");
        }

        private void btnRok_Click(object sender, EventArgs e)
        {
            rtxKomunikaty.Text = "";
            popraw_dane_auta_procedura(txtRok, "rok");
        }

        private void btnPrzebieg_Click(object sender, EventArgs e)
        {
            rtxKomunikaty.Text = "";
            popraw_dane_auta_procedura(txtPrzebieg, "przebieg");
        }

        private void btnKolor_Click(object sender, EventArgs e)
        {
            rtxKomunikaty.Text = "";
            popraw_dane_auta_procedura(txtKolor, "kolor");
        }

        private void btnPokazAuto_Click(object sender, EventArgs e)
        {

        }

        public void zapisz_wlasciciela()
        {
            int.TryParse(txtIdAuta.Text, out int id_auto);
            int id_wlasciciel = 0;
            var szukane_auta = baza.Auta.Where(znajdz => znajdz.id == id_auto);
            foreach (Auta sprzedane_auto in szukane_auta)
            {
                id_wlasciciel = sprzedane_auto.wlasciciel;
            }

            baza.Zapisz_poprzedniego_wlasciciela(id_auto, id_wlasciciel);

        }


        private void btnCena_Click(object sender, EventArgs e)
        {
            rtxKomunikaty.Text = "";

            if (txtTypZalogowanego.Text == "wlasciel" && txtCenaWyjsciowa.Text == "0" && txtCena.Text != "0")
            {
                dodaj_cene_auta_procedura(1);

            }
            nowa_transakcja_procedura();
            nowy_status_transakcji_procedura("licytacja");

        }

        private void btnZaakceptuj_Click(object sender, EventArgs e)
        {
            rtxKomunikaty.Text = "";
            int.TryParse(txtIdAuta.Text, out int id_auto);
            int.TryParse(textZalogowany.Text, out int id_nowy_wlasciciel);

            nowy_status_transakcji_procedura("sprzedaz");
            zapisz_wlasciciela();
            dodaj_cene_auta_procedura(2);
            nowy_wlasciciel_procedura(id_auto, id_nowy_wlasciciel);
        }

        private void btnSprzedaj_Click(object sender, EventArgs e)
        {
            //nowy_status_transakcji_procedura("sprzedaz");
            rtxKomunikaty.Text = "";

            sprzedaj_zamknij_pozostale_transakcje();
            nowy_status_transakcji_procedura("zgoda wlasciciela");
        }

        private void btnRezygnacja_Click(object sender, EventArgs e)
        {
            rtxKomunikaty.Text = "";
            nowy_status_transakcji_procedura("rezygnacja");
        }

        private void txtIdTransakcja_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnDodajMarke_Click(object sender, EventArgs e)
        {
            nowa_marka_procedura();
        }

        private void btnDodajSilnik_Click(object sender, EventArgs e)
        {
            nowy_silnik_procedura();
        }

        private void btnDodajKolor_Click(object sender, EventArgs e)
        {
            nowy_kolor_procedura();
        }

        private void btnPoprawMarke_Click(object sender, EventArgs e)
        {
            popraw_marke_procedura();
        }

        private void btnPoprawSilnik_Click(object sender, EventArgs e)
        {
            popraw_silnik_procedura();
        }

        private void btnPoprawjKolor_Click(object sender, EventArgs e)
        {
            popraw_kolor_procedura();
        }
    }
}
