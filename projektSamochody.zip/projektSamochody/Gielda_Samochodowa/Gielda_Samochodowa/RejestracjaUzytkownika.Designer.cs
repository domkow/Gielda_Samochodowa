﻿namespace Gielda_Samochodowa
{
    partial class RejestracjaUzytkownika
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnZamknij = new System.Windows.Forms.Button();
            this.rtxKomunikatRejestracji = new System.Windows.Forms.RichTextBox();
            this.mtxPowtorzHaslo = new System.Windows.Forms.MaskedTextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.mtxHaslo = new System.Windows.Forms.MaskedTextBox();
            this.btnRejestracjaDealera = new System.Windows.Forms.Button();
            this.btnRejestracjaKlienta = new System.Windows.Forms.Button();
            this.lbNazwisko = new System.Windows.Forms.Label();
            this.txtUzytkownik = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // btnZamknij
            // 
            this.btnZamknij.AccessibleName = "btnZamknij";
            this.btnZamknij.BackColor = System.Drawing.Color.DarkTurquoise;
            this.btnZamknij.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnZamknij.Location = new System.Drawing.Point(26, 370);
            this.btnZamknij.Name = "btnZamknij";
            this.btnZamknij.Size = new System.Drawing.Size(128, 23);
            this.btnZamknij.TabIndex = 77;
            this.btnZamknij.Text = "zamknij";
            this.btnZamknij.UseVisualStyleBackColor = false;
            this.btnZamknij.Click += new System.EventHandler(this.btnZamknij_Click);
            // 
            // rtxKomunikatRejestracji
            // 
            this.rtxKomunikatRejestracji.AccessibleName = "rtxKomunikatRejestracji";
            this.rtxKomunikatRejestracji.Location = new System.Drawing.Point(26, 254);
            this.rtxKomunikatRejestracji.Name = "rtxKomunikatRejestracji";
            this.rtxKomunikatRejestracji.Size = new System.Drawing.Size(267, 82);
            this.rtxKomunikatRejestracji.TabIndex = 76;
            this.rtxKomunikatRejestracji.Text = "";
            // 
            // mtxPowtorzHaslo
            // 
            this.mtxPowtorzHaslo.AccessibleName = "mtxPowtorzHaslo";
            this.mtxPowtorzHaslo.Location = new System.Drawing.Point(26, 143);
            this.mtxPowtorzHaslo.Name = "mtxPowtorzHaslo";
            this.mtxPowtorzHaslo.Size = new System.Drawing.Size(270, 22);
            this.mtxPowtorzHaslo.TabIndex = 75;
            // 
            // label3
            // 
            this.label3.AccessibleName = "lbNazwisko";
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(26, 123);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(95, 17);
            this.label3.TabIndex = 74;
            this.label3.Text = "powtórz hasło";
            // 
            // label2
            // 
            this.label2.AccessibleName = "lbNazwisko";
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(26, 63);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(42, 17);
            this.label2.TabIndex = 73;
            this.label2.Text = "hasło";
            // 
            // mtxHaslo
            // 
            this.mtxHaslo.AccessibleName = "mtxHaslo";
            this.mtxHaslo.Location = new System.Drawing.Point(26, 83);
            this.mtxHaslo.Name = "mtxHaslo";
            this.mtxHaslo.Size = new System.Drawing.Size(270, 22);
            this.mtxHaslo.TabIndex = 72;
            // 
            // btnRejestracjaDealera
            // 
            this.btnRejestracjaDealera.AccessibleName = "btnRejestracjaDealera";
            this.btnRejestracjaDealera.BackColor = System.Drawing.Color.DarkTurquoise;
            this.btnRejestracjaDealera.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnRejestracjaDealera.Location = new System.Drawing.Point(168, 195);
            this.btnRejestracjaDealera.Name = "btnRejestracjaDealera";
            this.btnRejestracjaDealera.Size = new System.Drawing.Size(128, 23);
            this.btnRejestracjaDealera.TabIndex = 71;
            this.btnRejestracjaDealera.Text = "dodaj dealera";
            this.btnRejestracjaDealera.UseVisualStyleBackColor = false;
            this.btnRejestracjaDealera.Click += new System.EventHandler(this.btnRejestracjaDealera_Click);
            // 
            // btnRejestracjaKlienta
            // 
            this.btnRejestracjaKlienta.AccessibleName = "btnRejestracjaKlienta";
            this.btnRejestracjaKlienta.BackColor = System.Drawing.Color.DarkTurquoise;
            this.btnRejestracjaKlienta.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnRejestracjaKlienta.Location = new System.Drawing.Point(26, 195);
            this.btnRejestracjaKlienta.Name = "btnRejestracjaKlienta";
            this.btnRejestracjaKlienta.Size = new System.Drawing.Size(128, 23);
            this.btnRejestracjaKlienta.TabIndex = 70;
            this.btnRejestracjaKlienta.Text = "dodaj klienta";
            this.btnRejestracjaKlienta.UseVisualStyleBackColor = false;
            this.btnRejestracjaKlienta.Click += new System.EventHandler(this.btnRejestracjaKlienta_Click);
            // 
            // lbNazwisko
            // 
            this.lbNazwisko.AccessibleName = "lbNazwisko";
            this.lbNazwisko.AutoSize = true;
            this.lbNazwisko.Location = new System.Drawing.Point(26, 9);
            this.lbNazwisko.Name = "lbNazwisko";
            this.lbNazwisko.Size = new System.Drawing.Size(128, 17);
            this.lbNazwisko.TabIndex = 69;
            this.lbNazwisko.Text = "nazwa użytkownika";
            // 
            // txtUzytkownik
            // 
            this.txtUzytkownik.AccessibleDescription = "txtUzytkownik";
            this.txtUzytkownik.Location = new System.Drawing.Point(26, 29);
            this.txtUzytkownik.Name = "txtUzytkownik";
            this.txtUzytkownik.Size = new System.Drawing.Size(270, 22);
            this.txtUzytkownik.TabIndex = 68;
            this.txtUzytkownik.Tag = "9";
            // 
            // RejestracjaUzytkownika
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(394, 450);
            this.Controls.Add(this.btnZamknij);
            this.Controls.Add(this.rtxKomunikatRejestracji);
            this.Controls.Add(this.mtxPowtorzHaslo);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.mtxHaslo);
            this.Controls.Add(this.btnRejestracjaDealera);
            this.Controls.Add(this.btnRejestracjaKlienta);
            this.Controls.Add(this.lbNazwisko);
            this.Controls.Add(this.txtUzytkownik);
            this.Name = "RejestracjaUzytkownika";
            this.Text = "RejestracjaUzytkownika";
            this.Load += new System.EventHandler(this.RejestracjaUzytkownika_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnZamknij;
        private System.Windows.Forms.RichTextBox rtxKomunikatRejestracji;
        private System.Windows.Forms.MaskedTextBox mtxPowtorzHaslo;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.MaskedTextBox mtxHaslo;
        private System.Windows.Forms.Button btnRejestracjaDealera;
        private System.Windows.Forms.Button btnRejestracjaKlienta;
        private System.Windows.Forms.Label lbNazwisko;
        private System.Windows.Forms.TextBox txtUzytkownik;
    }
}